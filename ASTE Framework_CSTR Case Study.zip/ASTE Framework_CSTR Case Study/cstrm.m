function [sys,x0,str,tss]=cstr1(t,x,u,flag,Param,X_ss)

global d cp V CAin DH1 DH2 UA k01 k02 EA1 EA2 Tin F Tu CDin PA PB PC PD PHEAT PCHANGE y0 r X0;

%
% An s-function to model a simple CSTR with first order kinetics and the following
% reaction ( A + D --> B) and ( A --> C) with a variable height well mixed vessel.  The equations that describe
% the system are:
% dV/dt  = F_in_liq + F_in_gas - F_out_liq - F-out_gas
% R1     = k1*Cb*Cc
% dCa/dt = F_in_gas/V*Ca_in-F_out_gas/V*Ca
% dCb/dt = F_in_gas/V*Cb_in-F_out_gas/V*Cb-R1
% dCc/dt = F_in_liq/V*Cc_in-F_out_liq/V*Cc-R1
% dCd/dt = F_in_liq/V*Cd_in-F_out_liq/V*Cd+R1
% dT /dt = - T/V*(F_in - F) + 1/V *(F_in*T_in - F*T) + 1/d/Cp*(-DH1)*R1+ 1/d/Cp*(-DH2)*R2 + 1/V/d/Cp*U*A*(Tc - T)

%================================================================================

switch flag,

case 0,	% Initialize the states and sizes
   [sys,x0,str,tss] = mdlInitialSizes(t,x,u,X_ss);
   
        % ****************
  	%  Outputs
  	% ****************   
     
case 3,   % Calculate the outputs
   
   sys = mdlOutputs(t,x,u,Param);
   
   % ****************
   % Update
   % ****************
case 1,	% Obtain derivatives of states
   
   sys = mdlDerivatives(t,x,u,Param);

otherwise,
   sys = [];
end

% ******************************************
% Sub-routines or Functions
% ******************************************

% ******************************************
% Initialization
% ******************************************
function [sys,x0,str,tss] = mdlInitialSizes(t,x,u,X_ss);

global d cp V CAin DH1 DH2 UA k01 k02 EA1 EA2 Tin F Tu CDin PA PB PC PD PHEAT PCHANGE y0 r X0;

% This handles initialization of the function.
% Call simsize of a sizes structure.
sizes = simsizes;
sizes.NumContStates  = 6;     % continuous states
sizes.NumDiscStates  = 0;     % discrete states
sizes.NumOutputs     = 9;     % outputs of model (manipulated variables)
sizes.NumInputs      = 20;    % inputs of model [r;Y;Ud]
sizes.DirFeedthrough = 1;     % System is not causal, there is explicit dependence of outputs on inputs.
sizes.NumSampleTimes = 1;     %
sys = simsizes(sizes);        %
x0  = X_ss;                   % Initialize the discrete states (inputs).
str = [];	                  % set str to an empty matrix.
tss = [0,0];	              % sample time: [period, offset].

% ******************************************
%  Outputs
% ******************************************
function sys = mdlOutputs(t,x,u,Param);

global d cp V CAin DH1 DH2 UA k01 k02 EA1 EA2 Tin F Tu CDin PA PB PC PD PHEAT PCHANGE y0 r X0;


SWITCH = Param(1);
% entering flow A, D
F_in = u(1);
% exiting volumetric flow A, B, C, D
F_out = u(7);

% Prices
PA=u(15);
PB=u(16);
PC=u(17);
PD=u(18);
PHEAT=u(19);
PCHANGE=u(20);

% outputs:
sys(1) = x(1);
sys(2) = F_out;
sys(3) = x(2);
sys(4) = x(3);
sys(5) = x(4);
sys(6) = x(5);
sys(7) = x(6);
sys(8) = F_in;
%sys(9) = PA;
sys(9) = (PB*F_out*x(3)+PC*F_out*x(5)-PA*F_in*(u(2)+1)-PD*F_in*(u(8)+1)-PHEAT*(UA*((u(4)+200)-x(4))))-PCHANGE;


% ******************************************
% Derivatives
% ******************************************
function sys = mdlDerivatives(t,x,u,Param)

global d cp V CAin DH1 DH2 UA k01 k02 EA1 EA2 Tin F Tu CDin PA PB PC PD PHEAT PCHANGE y0 r X0;

% External Parameters:
% [0;1;-1000;1;1;25;21500;10;-1000;91500],

SWITCH = Param(1);
k01    = u(9)*1;        % Pre-exponential factor (1/sec) --> k01 is a disturbance (e.g., agitator failure)
DH1    = Param(3);      % Heat of reaction for (J/mol) --> can be varied (from -1000 to -1500)
d      = Param(4);      % Diameter of reactor (m) or Cross-sectional area
Cp     = Param(5);      % Heat capacity of the mixture (J/kg-K)
UA     = Param(6);      % U - Overall Heat Transfer Coefficient (W/m^2-K) / A - Area - this value is specific for the U calculation (m^2) --> can be varied
EA1    = Param(7);      % E - Activation energy in the Arrhenius Equation (J/mol)
k02    = Param(8)*u(9); % Pre-exponential factor (1/sec)
DH2    = Param(9);      % Heat of reaction for (J/mol) --> can be varied (from -1000 to -1500)
EA2    = Param(10);     % E - Activation energy in the Arrhenius Equation (J/mol)

% Inputs (Disturbances): anbd 
% entering flow
F_in = u(1);
% Entering concentration of A:
Ca   = u(2)+1;
% Entering concentration of B: 
Cb   = u(3);
% Coolant Temperature in Jacket:
Tc   = u(4)+200;
% Entering concentration of C:
Cc   = u(5);


% exiting emergency flow
F_out_safe = u(10);
% Coolant Temperature in Spare Jacket:
Tc_safe = u(11)+200;
% Safety Valve 1 on/off
SV_1 = u(12);
% Safety Valve 2 on/off
SV_2 = u(13);
% Safety Valve 4 on/off
SV_4 = u(14);


% Inputs (Manipulated Variables):
% exiting volumetric flow
F_out    = u(7);
% Feed Temperature
T_in = u(6)+140;

% Entering Concentration of D
Cd = u(8)+1;


% Derivatives:
V = x(1);                                       % Volume of the reactor corresponds to the level, because the surface is 1m^2
k1 = k01 * exp (-EA1/8.314/(1.8*x(4)+1000));    % R - Universal Gas Constant = 8.31451 J/mol-K    
k2 = k02 * exp (-EA2/8.314/(2.8*x(4)+1000));    
R1 = k1*x(6)*x(2);                              
R2 = k2*x(2);
sys(1) = F_in*SV_1 - F_out*SV_2 - F_out_safe;   % Overall mass balance --> Is this not affecting the formula, because F_in has not the same C as F_out
sys(2) = F_in*SV_1/V*(Ca-x(2))-R1-R2;           % Concentration of A
sys(3) = F_in*SV_1/V*(Cb-x(3))+R1;              % Concenration of B
sys(4) = - x(4)/V*(F_in*SV_1 - F_out*SV_2) + 1/V *(F_in*T_in - F_out*SV_2*x(4)) + 1/d/Cp*(-DH1)*R1 + 1/d/Cp*(-DH2)*R2 + 1/V/d/Cp*UA*(Tc - x(4)) + 1/V/d/Cp*UA*(Tc_safe - x(4))*SV_4;
sys(5) = F_in*SV_1/V*(Cc-x(5))+R2;              % Concentration of C
sys(6) = F_in*SV_1/V*(Cd-x(6))-R1;              % Concetrantion of D
% reaction ( A + D --> B) and ( A --> C) with a variable height well mixed vessel.  The equations that describe
