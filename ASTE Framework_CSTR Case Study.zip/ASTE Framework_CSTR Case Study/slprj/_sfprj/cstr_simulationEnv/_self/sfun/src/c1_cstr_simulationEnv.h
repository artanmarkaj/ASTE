#ifndef __c1_cstr_simulationEnv_h__
#define __c1_cstr_simulationEnv_h__
#ifdef __has_include
#if __has_include(<time.h>)
#include <time.h>
#else
#error Cannot find header file <time.h> for imported type time_t.\
 Supply the missing header file or turn on Simulation Target -> Generate typedefs\
 for imported bus and enumeration types.
#endif

#else
#include <time.h>
#endif

/* Forward Declarations */
#ifndef typedef_c1_sxaDueAh1f53T9ESYg9Uc4E
#define typedef_c1_sxaDueAh1f53T9ESYg9Uc4E

typedef struct c1_tag_sxaDueAh1f53T9ESYg9Uc4E c1_sxaDueAh1f53T9ESYg9Uc4E;

#endif                                 /* typedef_c1_sxaDueAh1f53T9ESYg9Uc4E */

#ifndef typedef_c1_cell_0
#define typedef_c1_cell_0

typedef struct c1_tag_n3SDPft8LycMqfcEsfJVBB c1_cell_0;

#endif                                 /* typedef_c1_cell_0 */

#ifndef typedef_c1_s_wvzWMLKjXp7EJVnnMvwbTC
#define typedef_c1_s_wvzWMLKjXp7EJVnnMvwbTC

typedef struct c1_tag_wvzWMLKjXp7EJVnnMvwbTC c1_s_wvzWMLKjXp7EJVnnMvwbTC;

#endif                                 /* typedef_c1_s_wvzWMLKjXp7EJVnnMvwbTC */

/* Type Definitions */
#ifndef struct_c1_tag_sxaDueAh1f53T9ESYg9Uc4E
#define struct_c1_tag_sxaDueAh1f53T9ESYg9Uc4E

struct c1_tag_sxaDueAh1f53T9ESYg9Uc4E
{
  real_T tm_min;
  real_T tm_sec;
  real_T tm_hour;
  real_T tm_mday;
  real_T tm_mon;
  real_T tm_year;
};

#endif                                 /* struct_c1_tag_sxaDueAh1f53T9ESYg9Uc4E */

#ifndef typedef_c1_sxaDueAh1f53T9ESYg9Uc4E
#define typedef_c1_sxaDueAh1f53T9ESYg9Uc4E

typedef struct c1_tag_sxaDueAh1f53T9ESYg9Uc4E c1_sxaDueAh1f53T9ESYg9Uc4E;

#endif                                 /* typedef_c1_sxaDueAh1f53T9ESYg9Uc4E */

#ifndef struct_c1_tag_n3SDPft8LycMqfcEsfJVBB
#define struct_c1_tag_n3SDPft8LycMqfcEsfJVBB

struct c1_tag_n3SDPft8LycMqfcEsfJVBB
{
  char_T f1[6];
  char_T f2[6];
  char_T f3[7];
  char_T f4[7];
  char_T f5[6];
  char_T f6[7];
};

#endif                                 /* struct_c1_tag_n3SDPft8LycMqfcEsfJVBB */

#ifndef typedef_c1_cell_0
#define typedef_c1_cell_0

typedef struct c1_tag_n3SDPft8LycMqfcEsfJVBB c1_cell_0;

#endif                                 /* typedef_c1_cell_0 */

#ifndef struct_c1_tag_wvzWMLKjXp7EJVnnMvwbTC
#define struct_c1_tag_wvzWMLKjXp7EJVnnMvwbTC

struct c1_tag_wvzWMLKjXp7EJVnnMvwbTC
{
  c1_cell_0 _data;
};

#endif                                 /* struct_c1_tag_wvzWMLKjXp7EJVnnMvwbTC */

#ifndef typedef_c1_s_wvzWMLKjXp7EJVnnMvwbTC
#define typedef_c1_s_wvzWMLKjXp7EJVnnMvwbTC

typedef struct c1_tag_wvzWMLKjXp7EJVnnMvwbTC c1_s_wvzWMLKjXp7EJVnnMvwbTC;

#endif                                 /* typedef_c1_s_wvzWMLKjXp7EJVnnMvwbTC */

#ifndef typedef_SFc1_cstr_simulationEnvInstanceStruct
#define typedef_SFc1_cstr_simulationEnvInstanceStruct

typedef struct {
  uint32_T c1_is_c1_cstr_simulationEnv;
  uint32_T c1_is_Failure_2;
  uint32_T c1_is_Operation_1;
  uint32_T c1_is_Operation_2;
  uint32_T c1_is_Failure_3;
  uint32_T c1_b_is_Operation_1;
  uint32_T c1_is_Failure_1;
  uint32_T c1_c_is_Operation_1;
  uint32_T c1_b_is_Operation_2;
  real_T c1_DecisionPoint;
  real_T c1_Slow_shut_down_Inlet_Flow;
  SimStruct *S;
  ChartInfoStruct chartInfo;
  int32_T c1_sfEvent;
  uint8_T c1_is_active_c1_cstr_simulationEnv;
  uint8_T c1_JITStateAnimation[41];
  uint8_T c1_JITTransitionAnimation[46];
  int32_T c1_IsDebuggerActive;
  int32_T c1_IsSequenceViewerPresent;
  int32_T c1_SequenceViewerOptimization;
  int32_T c1_IsHeatMapPresent;
  void *c1_RuntimeVar;
  uint32_T c1_seed;
  boolean_T c1_seed_not_empty;
  uint32_T c1_method;
  boolean_T c1_method_not_empty;
  uint32_T c1_state[625];
  boolean_T c1_state_not_empty;
  uint32_T c1_b_state[2];
  boolean_T c1_b_state_not_empty;
  uint32_T c1_c_state;
  boolean_T c1_c_state_not_empty;
  uint32_T c1_temporalCounter_i1;
  boolean_T c1_dataWrittenToVector[2];
  uint8_T c1_doSetSimStateSideEffects;
  const mxArray *c1_setSimStateSideEffectsInfo;
  uint32_T c1_mlFcnLineNumber;
  CovrtStateflowInstance *c1_covrtInstance;
  void *c1_fEmlrtCtx;
  boolean_T *c1_Failure1;
  boolean_T *c1_Shut_down_Agitator;
  boolean_T *c1_Shut_down_Outlet_Flow;
  boolean_T *c1_Open_Safety_Valve3;
  boolean_T *c1_Reset_Failure1;
  real_T *c1_F_out;
  real_T *c1_Slow_shut_down_Outlet_Flow;
  boolean_T *c1_Failure2;
  boolean_T *c1_Reset_Failure2;
  boolean_T *c1_Shut_down_Inlet_Flow;
  real_T *c1_Inlet_Flow_CurrentValue;
  boolean_T *c1_Failure3;
  boolean_T *c1_Open_Safety_Valve4;
  boolean_T *c1_Reset_Failure3;
} SFc1_cstr_simulationEnvInstanceStruct;

#endif                                 /* typedef_SFc1_cstr_simulationEnvInstanceStruct */

/* Named Constants */

/* Variable Declarations */

/* Variable Definitions */

/* Function Declarations */
extern const mxArray *sf_c1_cstr_simulationEnv_get_eml_resolved_functions_info
  (void);
extern mxArray *sf_c1_cstr_simulationEnv_getDebuggerHoverDataFor
  (SFc1_cstr_simulationEnvInstanceStruct *chartInstance, uint32_T c1_u);

/* Function Definitions */
extern void sf_c1_cstr_simulationEnv_get_check_sum(mxArray *plhs[]);
extern void c1_cstr_simulationEnv_method_dispatcher(SimStruct *S, int_T method,
  void *data);

#endif
