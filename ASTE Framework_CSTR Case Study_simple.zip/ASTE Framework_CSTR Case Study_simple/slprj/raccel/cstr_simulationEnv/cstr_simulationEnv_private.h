#ifndef RTW_HEADER_cstr_simulationEnv_private_h_
#define RTW_HEADER_cstr_simulationEnv_private_h_
#include "rtwtypes.h"
#include "builtin_typeid_types.h"
#include "multiword_types.h"
#include "cstr_simulationEnv.h"
#include "cstr_simulationEnv_types.h"
#if !defined(rt_VALIDATE_MEMORY)
#define rt_VALIDATE_MEMORY(S, ptr)     if(!(ptr)) {\
    ssSetErrorStatus(rtS, RT_MEMORY_ALLOCATION_ERROR);\
    }
#endif
#if !defined(rt_FREE)
#if !defined(_WIN32)
#define rt_FREE(ptr)     if((ptr) != (NULL)) {\
    free((ptr));\
    (ptr) = (NULL);\
    }
#else
#define rt_FREE(ptr)     if((ptr) != (NULL)) {\
    free((void *)(ptr));\
    (ptr) = (NULL);\
    }
#endif
#endif
#ifndef rtInterpolate
#define rtInterpolate(v1,v2,f1,f2)     (((v1)==(v2))?((double)(v1)):    (((f1)*((double)(v1)))+((f2)*((double)(v2)))))
#endif
#ifndef rtRound
#define rtRound(v) ( ((v) >= 0) ?     muDoubleScalarFloor((v) + 0.5) :     muDoubleScalarCeil((v) - 0.5) )
#endif
extern real_T rt_urand_Upu32_Yd_f_pw_snf ( uint32_T * u ) ; extern void cstrm
( SimStruct * rts ) ; extern void euommxokvy ( mwig44svkj * localB ,
ew3azour0i * localP ) ; extern void lvdmxslirz ( real_T puydwci5lo ,
mwig44svkj * localB , jumuk3fap1 * localDW , ew3azour0i * localP ) ; extern
void dnd2bzvthx ( l0lgrgqbys * localB , gecy0xyg43 * localP ) ; extern void
lsul0j3thv ( real_T hshllgsvvq , l0lgrgqbys * localB , o2f542nfiy * localDW ,
gecy0xyg43 * localP ) ; extern void b2ou3bzaum ( dunstow1lc * localB ,
n2j2mlro55 * localP ) ; extern void o0l0tlmums ( real_T hbjpklwfg3 ,
dunstow1lc * localB , arhl1fqxuk * localDW , n2j2mlro55 * localP ) ; extern
void cbl0gm11na ( eoztiauie0 * localB , krn1dj51s1 * localP ) ; extern void
e5i1gkys05 ( real_T azbafjvsk2 , eoztiauie0 * localB , hzamdoniux * localDW ,
krn1dj51s1 * localP ) ;
#if defined(MULTITASKING)
#error Model (cstr_simulationEnv) was built in \SingleTasking solver mode, however the MULTITASKING define is \present. If you have multitasking (e.g. -DMT or -DMULTITASKING) \defined on the Code Generation page of Simulation parameter dialog, please \remove it and on the Solver page, select solver mode \MultiTasking. If the Simulation parameter dialog is configured \correctly, please verify that your template makefile is \configured correctly.
#endif
#endif
