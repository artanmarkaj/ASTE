import matlab.engine
import h5py

# Start the MATLAB engine
eng = matlab.engine.start_matlab()

# Load the .mat files
eng.load('init_data.mat', nargout=0)    # Load init_data.mat
eng.load('out_data.mat', nargout=0)     # Load out_data.mat

# Set prices for products
eng.workspace['PA'] = 5             # Set price for product A
eng.workspace['PB'] = 12            # Set price for product B
eng.workspace['PC'] = 19            # Set price for product C
eng.workspace['PD'] = 2             # Set price for product D
eng.workspace['PHEAT'] = 0.001      # Set price for heat (heating costs)
eng.workspace['PCHANGE'] = 0.00001  # Set price for actuator changes (maintenance costs)

# Activate safety system
eng.workspace['SIF_activation'] = 1  # Activate safety system

# Activate operator control
eng.workspace['operator_control_activation'] = 1  # Activate operator control

# Activate faults
eng.workspace['fault1'] = 0  # Activate fault 1 ('No Inlet Flow')
eng.workspace['fault2'] = 0  # Activate fault 2 ('No Outlet Flow')
eng.workspace['fault3'] = 0  # Activate fault 3 ('No Cooling')

# Set initial inlet flow and feed temperature values
eng.workspace['inlet_flow_in'] = 0.0              # Set starting inlet flow value
eng.workspace['inlet_flow_out'] = 5.0             # Set desired inlet flow value
eng.workspace['feed_temperature_in'] = 20.0       # Set starting feed temperature value
eng.workspace['feed_temperature_out'] = 140.0     # Set desired feed temperature value

# Set controllable parameters
eng.workspace['Shut_down_Inlet_Flow'] = 'false'     # Shut down inlet flow
eng.workspace['Shut_down_Outlet_Flow'] = 'false'    # Shut down outlet flow
eng.workspace['Shut_down_Agitator'] = 'false'       # Shut down agitator
eng.workspace['Shut_down_Pump1'] = 'false'          # Shut down pump 1 (inlet flow)

eng.workspace['Open_Safety_Valve3'] = 'false'       # Open safety valve 3 (additional outlet flow)
eng.workspace['Open_Safety_Valve4'] = 'false'       # Open safety valve 4 (cooling)
eng.workspace['Close_Safety_Valve1'] = 'false'      # Close safety valve 1 (inlet flow)
eng.workspace['Close_Safety_Valve2'] = 'false'      # Close safety valve 2 (outlet flow)

eng.workspace['Reset_Failure1'] = 'false'   # Reset failure 1
eng.workspace['Reset_Failure2'] = 'false'   # Reset failure 2
eng.workspace['Reset_Failure3'] = 'false'   # Reset failure 3

# Specify the Simulink model name (without the .slx extension)
sim_model = "cstr_simulationEnv.slx"

# Run the Simulink model
eng.sim(sim_model, nargout=0)  # Execute the Simulink model

# Save the updated `out_data.mat` to ensure latest data is written
out_data_path = 'out_data.mat'

# Use h5py to read MATLAB v7.3 .mat files
# print("Simulation Output Data:")
# with h5py.File(out_data_path, 'r') as mat_data:
    # Explore all keys
    # print("Keys in out_data.mat:", list(mat_data.keys()))
    
    # Access specific data (example)
    # Assuming the file contains a dataset named 'output_signal'
    # if 'output_signal' in mat_data:
    #     output_signal = mat_data['output_signal'][:]
    #     print("Output Signal:", output_signal)

# Run the "cstr_plot.m" script
eng.cstr_plot(nargout=0)  # Execute the cstr_plot.m script

# Stop the MATLAB engine
eng.quit()

print("Simulation and plotting completed.")
