#include "rtw_capi.h"
#ifdef HOST_CAPI_BUILD
#include "cstr_simulationEnv_capi_host.h"
#define sizeof(s) ((size_t)(0xFFFF))
#undef rt_offsetof
#define rt_offsetof(s,el) ((uint16_T)(0xFFFF))
#define TARGET_CONST
#define TARGET_STRING(s) (s)
#ifndef SS_UINT64
#define SS_UINT64 17
#endif
#ifndef SS_INT64
#define SS_INT64 18
#endif
#else
#include "builtin_typeid_types.h"
#include "cstr_simulationEnv.h"
#include "cstr_simulationEnv_capi.h"
#include "cstr_simulationEnv_private.h"
#ifdef LIGHT_WEIGHT_CAPI
#define TARGET_CONST
#define TARGET_STRING(s)               ((NULL))
#else
#define TARGET_CONST                   const
#define TARGET_STRING(s)               (s)
#endif
#endif
static const rtwCAPI_Signals rtBlockSignals [ ] = { { 0 , 6 , TARGET_STRING (
"cstr_simulationEnv/Operator Control" ) , TARGET_STRING ( "" ) , 0 , 0 , 0 ,
0 , 0 } , { 1 , 6 , TARGET_STRING ( "cstr_simulationEnv/Operator Control" ) ,
TARGET_STRING ( "" ) , 1 , 0 , 0 , 0 , 0 } , { 2 , 6 , TARGET_STRING (
"cstr_simulationEnv/Operator Control" ) , TARGET_STRING ( "" ) , 2 , 0 , 0 ,
0 , 0 } , { 3 , 6 , TARGET_STRING ( "cstr_simulationEnv/Operator Control" ) ,
TARGET_STRING ( "" ) , 3 , 0 , 0 , 0 , 0 } , { 4 , 6 , TARGET_STRING (
"cstr_simulationEnv/Operator Control" ) , TARGET_STRING ( "" ) , 4 , 0 , 0 ,
0 , 0 } , { 5 , 6 , TARGET_STRING ( "cstr_simulationEnv/Operator Control" ) ,
TARGET_STRING ( "" ) , 5 , 0 , 0 , 0 , 0 } , { 6 , 6 , TARGET_STRING (
"cstr_simulationEnv/Operator Control" ) , TARGET_STRING ( "" ) , 6 , 0 , 0 ,
0 , 0 } , { 7 , 6 , TARGET_STRING ( "cstr_simulationEnv/Operator Control" ) ,
TARGET_STRING ( "" ) , 7 , 0 , 0 , 0 , 0 } , { 8 , 0 , TARGET_STRING (
"cstr_simulationEnv/Operator Control/is_c1_cstr_simulationEnv" ) ,
TARGET_STRING ( "is_c1_cstr_simulationEnv" ) , 0 , 1 , 0 , 0 , 0 } , { 9 , 0
, TARGET_STRING (
"cstr_simulationEnv/Operator Control/Failure_1.is_Failure_1" ) ,
TARGET_STRING ( "is_Failure_1" ) , 0 , 1 , 0 , 0 , 0 } , { 10 , 0 ,
TARGET_STRING (
"cstr_simulationEnv/Operator Control/Failure_1.Operation_1.is_Operation_1" )
, TARGET_STRING ( "is_Operation_1" ) , 0 , 1 , 0 , 0 , 0 } , { 11 , 0 ,
TARGET_STRING ( "cstr_simulationEnv/Operator Control/Failure_2.is_Failure_2"
) , TARGET_STRING ( "is_Failure_2" ) , 0 , 1 , 0 , 0 , 0 } , { 12 , 0 ,
TARGET_STRING (
"cstr_simulationEnv/Operator Control/Failure_2.Operation_1.is_Operation_1" )
, TARGET_STRING ( "is_Operation_1" ) , 0 , 1 , 0 , 0 , 0 } , { 13 , 0 ,
TARGET_STRING ( "cstr_simulationEnv/Operator Control/Failure_3.is_Failure_3"
) , TARGET_STRING ( "is_Failure_3" ) , 0 , 1 , 0 , 0 , 0 } , { 14 , 0 ,
TARGET_STRING (
"cstr_simulationEnv/Operator Control/Failure_3.Operation_1.is_Operation_1" )
, TARGET_STRING ( "is_Operation_1" ) , 0 , 1 , 0 , 0 , 0 } , { 15 , 0 ,
TARGET_STRING (
"cstr_simulationEnv/Operator Control/is_active_c1_cstr_simulationEnv" ) ,
TARGET_STRING ( "is_active_c1_cstr_simulationEnv" ) , 0 , 2 , 0 , 0 , 0 } , {
16 , 11 , TARGET_STRING ( "cstr_simulationEnv/State-based Control System" ) ,
TARGET_STRING ( "" ) , 0 , 3 , 0 , 0 , 0 } , { 17 , 11 , TARGET_STRING (
"cstr_simulationEnv/State-based Control System" ) , TARGET_STRING ( "" ) , 1
, 3 , 0 , 0 , 0 } , { 18 , 11 , TARGET_STRING (
"cstr_simulationEnv/State-based Control System" ) , TARGET_STRING ( "" ) , 2
, 0 , 0 , 0 , 0 } , { 19 , 11 , TARGET_STRING (
"cstr_simulationEnv/State-based Control System" ) , TARGET_STRING ( "" ) , 3
, 0 , 0 , 0 , 0 } , { 20 , 11 , TARGET_STRING (
"cstr_simulationEnv/State-based Control System" ) , TARGET_STRING ( "" ) , 4
, 0 , 0 , 0 , 0 } , { 21 , 0 , TARGET_STRING (
"cstr_simulationEnv/State-based Control System/is_c3_cstr_simulationEnv" ) ,
TARGET_STRING ( "is_c3_cstr_simulationEnv" ) , 0 , 1 , 0 , 0 , 0 } , { 22 , 0
, TARGET_STRING (
"cstr_simulationEnv/State-based Control System/Automatic.is_Automatic" ) ,
TARGET_STRING ( "is_Automatic" ) , 0 , 1 , 0 , 0 , 0 } , { 23 , 0 ,
TARGET_STRING (
"cstr_simulationEnv/State-based Control System/Automatic.Stopped.is_Stopped"
) , TARGET_STRING ( "is_Stopped" ) , 0 , 1 , 0 , 0 , 0 } , { 24 , 0 ,
TARGET_STRING (
"cstr_simulationEnv/State-based Control System/Automatic.Failure.is_Failure"
) , TARGET_STRING ( "is_Failure" ) , 0 , 1 , 0 , 0 , 0 } , { 25 , 0 ,
TARGET_STRING (
"cstr_simulationEnv/State-based Control System/is_active_c3_cstr_simulationEnv"
) , TARGET_STRING ( "is_active_c3_cstr_simulationEnv" ) , 0 , 2 , 0 , 0 , 0 }
, { 26 , 0 , TARGET_STRING (
 "cstr_simulationEnv/State-based Control System/Automatic.Shut_Down.Inlet_Flow_Ramp_SD.is_active_Inlet_Flow_Ramp_SD"
) , TARGET_STRING ( "is_active_Inlet_Flow_Ramp_SD" ) , 0 , 2 , 0 , 0 , 0 } ,
{ 27 , 0 , TARGET_STRING (
 "cstr_simulationEnv/State-based Control System/Automatic.Shut_Down.Feed_Temperature_Ramp_SD.is_active_Feed_Temperature_Ramp_SD"
) , TARGET_STRING ( "is_active_Feed_Temperature_Ramp_SD" ) , 0 , 2 , 0 , 0 ,
0 } , { 28 , 0 , TARGET_STRING (
 "cstr_simulationEnv/State-based Control System/Automatic.Start_Up.Inlet_Flow_Ramp_SU.is_active_Inlet_Flow_Ramp_SU"
) , TARGET_STRING ( "is_active_Inlet_Flow_Ramp_SU" ) , 0 , 2 , 0 , 0 , 0 } ,
{ 29 , 0 , TARGET_STRING (
 "cstr_simulationEnv/State-based Control System/Automatic.Start_Up.Feed_Temperature_Ramp_SU.is_active_Feed_Temperature_Ramp_SU"
) , TARGET_STRING ( "is_active_Feed_Temperature_Ramp_SU" ) , 0 , 2 , 0 , 0 ,
0 } , { 30 , 0 , TARGET_STRING ( "cstr_simulationEnv/Feed_Temperature_In" ) ,
TARGET_STRING ( "" ) , 0 , 3 , 0 , 0 , 1 } , { 31 , 0 , TARGET_STRING (
"cstr_simulationEnv/Feed_Temperature_Out" ) , TARGET_STRING ( "" ) , 0 , 3 ,
0 , 0 , 1 } , { 32 , 0 , TARGET_STRING ( "cstr_simulationEnv/Inlet_Flow_In" )
, TARGET_STRING ( "" ) , 0 , 3 , 0 , 0 , 1 } , { 33 , 0 , TARGET_STRING (
"cstr_simulationEnv/Inlet_Flow_Out" ) , TARGET_STRING ( "" ) , 0 , 3 , 0 , 0
, 1 } , { 34 , 0 , TARGET_STRING ( "cstr_simulationEnv/Unit Delay1" ) ,
TARGET_STRING ( "" ) , 0 , 3 , 0 , 0 , 0 } , { 35 , 0 , TARGET_STRING (
"cstr_simulationEnv/Unit Delay10" ) , TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 ,
0 } , { 36 , 0 , TARGET_STRING ( "cstr_simulationEnv/Unit Delay11" ) ,
TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0 } , { 37 , 0 , TARGET_STRING (
"cstr_simulationEnv/Unit Delay2" ) , TARGET_STRING ( "" ) , 0 , 3 , 0 , 0 , 0
} , { 38 , 0 , TARGET_STRING ( "cstr_simulationEnv/Unit Delay6" ) ,
TARGET_STRING ( "" ) , 0 , 3 , 0 , 0 , 0 } , { 39 , 0 , TARGET_STRING (
"cstr_simulationEnv/Unit Delay7" ) , TARGET_STRING ( "" ) , 0 , 3 , 0 , 0 , 0
} , { 40 , 0 , TARGET_STRING ( "cstr_simulationEnv/Unit Delay8" ) ,
TARGET_STRING ( "" ) , 0 , 3 , 0 , 0 , 0 } , { 41 , 0 , TARGET_STRING (
"cstr_simulationEnv/Unit Delay9" ) , TARGET_STRING ( "" ) , 0 , 0 , 0 , 0 , 0
} , { 42 , 0 , TARGET_STRING (
"cstr_simulationEnv/CSTR_1 Simulation Model + Regulatory Control/Gain" ) ,
TARGET_STRING ( "" ) , 0 , 3 , 0 , 0 , 2 } , { 43 , 0 , TARGET_STRING (
"cstr_simulationEnv/CSTR_1 Simulation Model + Regulatory Control/Gain1" ) ,
TARGET_STRING ( "" ) , 0 , 3 , 0 , 0 , 2 } , { 44 , 0 , TARGET_STRING (
"cstr_simulationEnv/CSTR_1 Simulation Model + Regulatory Control/Gain2" ) ,
TARGET_STRING ( "" ) , 0 , 3 , 0 , 0 , 2 } , { 45 , 0 , TARGET_STRING (
"cstr_simulationEnv/CSTR_1 Simulation Model + Regulatory Control/Integrator"
) , TARGET_STRING ( "" ) , 0 , 3 , 0 , 0 , 2 } , { 46 , 0 , TARGET_STRING (
"cstr_simulationEnv/CSTR_1 Simulation Model + Regulatory Control/Product5" )
, TARGET_STRING ( "" ) , 0 , 3 , 0 , 0 , 2 } , { 47 , 0 , TARGET_STRING (
"cstr_simulationEnv/CSTR_1 Simulation Model + Regulatory Control/Product6" )
, TARGET_STRING ( "" ) , 0 , 3 , 0 , 0 , 2 } , { 48 , 0 , TARGET_STRING (
"cstr_simulationEnv/CSTR_1 Simulation Model + Regulatory Control/m file" ) ,
TARGET_STRING ( "" ) , 0 , 3 , 1 , 0 , 2 } , { 49 , 0 , TARGET_STRING (
"cstr_simulationEnv/CSTR_1 Simulation Model + Regulatory Control/Add" ) ,
TARGET_STRING ( "" ) , 0 , 3 , 0 , 0 , 0 } , { 50 , 0 , TARGET_STRING (
"cstr_simulationEnv/CSTR_1 Simulation Model + Regulatory Control/Sum2" ) ,
TARGET_STRING ( "" ) , 0 , 3 , 0 , 0 , 3 } , { 51 , 0 , TARGET_STRING (
"cstr_simulationEnv/CSTR_1 Simulation Model + Regulatory Control/Sum3" ) ,
TARGET_STRING ( "" ) , 0 , 3 , 0 , 0 , 3 } , { 52 , 0 , TARGET_STRING (
"cstr_simulationEnv/CSTR_1 Simulation Model + Regulatory Control/Sum4" ) ,
TARGET_STRING ( "" ) , 0 , 3 , 0 , 0 , 3 } , { 53 , 0 , TARGET_STRING (
"cstr_simulationEnv/CSTR_1 Simulation Model + Regulatory Control/Sum5" ) ,
TARGET_STRING ( "" ) , 0 , 3 , 0 , 0 , 3 } , { 54 , 0 , TARGET_STRING (
"cstr_simulationEnv/CSTR_1 Simulation Model + Regulatory Control/Sum6" ) ,
TARGET_STRING ( "" ) , 0 , 3 , 0 , 0 , 3 } , { 55 , 0 , TARGET_STRING (
"cstr_simulationEnv/CSTR_1 Simulation Model + Regulatory Control/Sum7" ) ,
TARGET_STRING ( "" ) , 0 , 3 , 0 , 0 , 0 } , { 56 , 0 , TARGET_STRING (
"cstr_simulationEnv/CSTR_1 Simulation Model + Regulatory Control/Switch" ) ,
TARGET_STRING ( "" ) , 0 , 3 , 0 , 0 , 2 } , { 57 , 0 , TARGET_STRING (
"cstr_simulationEnv/CSTR_1 Simulation Model + Regulatory Control/Switch1" ) ,
TARGET_STRING ( "" ) , 0 , 3 , 0 , 0 , 0 } , { 58 , 0 , TARGET_STRING (
"cstr_simulationEnv/CSTR_1 Simulation Model + Regulatory Control/Switch10" )
, TARGET_STRING ( "" ) , 0 , 3 , 0 , 0 , 0 } , { 59 , 0 , TARGET_STRING (
"cstr_simulationEnv/CSTR_1 Simulation Model + Regulatory Control/Switch11" )
, TARGET_STRING ( "" ) , 0 , 3 , 0 , 0 , 0 } , { 60 , 0 , TARGET_STRING (
"cstr_simulationEnv/CSTR_1 Simulation Model + Regulatory Control/Switch4" ) ,
TARGET_STRING ( "" ) , 0 , 3 , 0 , 0 , 0 } , { 61 , 0 , TARGET_STRING (
"cstr_simulationEnv/CSTR_1 Simulation Model + Regulatory Control/Switch5" ) ,
TARGET_STRING ( "" ) , 0 , 3 , 0 , 0 , 0 } , { 62 , 0 , TARGET_STRING (
"cstr_simulationEnv/CSTR_1 Simulation Model + Regulatory Control/Switch6" ) ,
TARGET_STRING ( "" ) , 0 , 3 , 0 , 0 , 0 } , { 63 , 0 , TARGET_STRING (
"cstr_simulationEnv/CSTR_1 Simulation Model + Regulatory Control/Switch7" ) ,
TARGET_STRING ( "" ) , 0 , 3 , 0 , 0 , 0 } , { 64 , 0 , TARGET_STRING (
"cstr_simulationEnv/CSTR_1 Simulation Model + Regulatory Control/Switch9" ) ,
TARGET_STRING ( "" ) , 0 , 3 , 0 , 0 , 0 } , { 65 , 0 , TARGET_STRING (
"cstr_simulationEnv/CSTR_1 Simulation Model + Regulatory Control/Unit Delay1"
) , TARGET_STRING ( "" ) , 0 , 3 , 0 , 0 , 0 } , { 66 , 0 , TARGET_STRING (
"cstr_simulationEnv/CSTR_1 Simulation Model + Regulatory Control/Unit Delay2"
) , TARGET_STRING ( "" ) , 0 , 3 , 0 , 0 , 0 } , { 67 , 0 , TARGET_STRING (
"cstr_simulationEnv/CSTR_1 Simulation Model + Regulatory Control/Unit Delay6"
) , TARGET_STRING ( "" ) , 0 , 3 , 0 , 0 , 0 } , { 68 , 0 , TARGET_STRING (
"cstr_simulationEnv/Fault Engine/Saturation" ) , TARGET_STRING ( "" ) , 0 , 3
, 0 , 0 , 2 } , { 69 , 0 , TARGET_STRING (
"cstr_simulationEnv/Fault Engine/Switch13" ) , TARGET_STRING ( "" ) , 0 , 3 ,
0 , 0 , 0 } , { 70 , 0 , TARGET_STRING (
"cstr_simulationEnv/Fault Engine/Switch14" ) , TARGET_STRING ( "" ) , 0 , 3 ,
0 , 0 , 0 } , { 71 , 0 , TARGET_STRING (
"cstr_simulationEnv/Fault Engine/Switch22" ) , TARGET_STRING ( "" ) , 0 , 3 ,
0 , 0 , 0 } , { 72 , 0 , TARGET_STRING (
"cstr_simulationEnv/Fault Engine/Switch23" ) , TARGET_STRING ( "" ) , 0 , 3 ,
0 , 0 , 0 } , { 73 , 0 , TARGET_STRING (
"cstr_simulationEnv/Fault Engine/Switch4" ) , TARGET_STRING ( "" ) , 0 , 3 ,
0 , 0 , 0 } , { 74 , 0 , TARGET_STRING (
"cstr_simulationEnv/Fault Engine/Uniform Random Number10" ) , TARGET_STRING (
"" ) , 0 , 3 , 0 , 0 , 4 } , { 75 , 0 , TARGET_STRING (
"cstr_simulationEnv/Fault Engine/Uniform Random Number2" ) , TARGET_STRING (
"" ) , 0 , 3 , 0 , 0 , 4 } , { 76 , 0 , TARGET_STRING (
"cstr_simulationEnv/Fault Engine/Uniform Random Number6" ) , TARGET_STRING (
"" ) , 0 , 3 , 0 , 0 , 4 } , { 77 , 7 , TARGET_STRING (
 "cstr_simulationEnv/State-based Control System/Automatic.Shut_Down.Feed_Temperature_Ramp_SD.Feed_Temperature_Ramp_SD"
) , TARGET_STRING ( "" ) , 0 , 3 , 0 , 0 , 5 } , { 78 , 8 , TARGET_STRING (
 "cstr_simulationEnv/State-based Control System/Automatic.Shut_Down.Inlet_Flow_Ramp_SD.Inlet_Flow_Ramp_SD"
) , TARGET_STRING ( "" ) , 0 , 3 , 0 , 0 , 5 } , { 79 , 9 , TARGET_STRING (
 "cstr_simulationEnv/State-based Control System/Automatic.Start_Up.Feed_Temperature_Ramp_SU.Feed_Temperature_Ramp_SU"
) , TARGET_STRING ( "" ) , 0 , 3 , 0 , 0 , 5 } , { 80 , 10 , TARGET_STRING (
 "cstr_simulationEnv/State-based Control System/Automatic.Start_Up.Inlet_Flow_Ramp_SU.Inlet_Flow_Ramp_SU"
) , TARGET_STRING ( "" ) , 0 , 3 , 0 , 0 , 5 } , { 81 , 7 , TARGET_STRING (
 "cstr_simulationEnv/State-based Control System/Automatic.Shut_Down.Feed_Temperature_Ramp_SD.Feed_Temperature_Ramp_SD/Saturation"
) , TARGET_STRING ( "" ) , 0 , 3 , 0 , 0 , 5 } , { 82 , 8 , TARGET_STRING (
 "cstr_simulationEnv/State-based Control System/Automatic.Shut_Down.Inlet_Flow_Ramp_SD.Inlet_Flow_Ramp_SD/Saturation"
) , TARGET_STRING ( "" ) , 0 , 3 , 0 , 0 , 5 } , { 83 , 9 , TARGET_STRING (
 "cstr_simulationEnv/State-based Control System/Automatic.Start_Up.Feed_Temperature_Ramp_SU.Feed_Temperature_Ramp_SU/Saturation"
) , TARGET_STRING ( "" ) , 0 , 3 , 0 , 0 , 5 } , { 84 , 10 , TARGET_STRING (
 "cstr_simulationEnv/State-based Control System/Automatic.Start_Up.Inlet_Flow_Ramp_SU.Inlet_Flow_Ramp_SU/Saturation"
) , TARGET_STRING ( "" ) , 0 , 3 , 0 , 0 , 5 } , { 85 , 0 , TARGET_STRING (
 "cstr_simulationEnv/CSTR_1 Simulation Model + Regulatory Control/PID Controller/I Gain/Internal Parameters/Integral Gain"
) , TARGET_STRING ( "" ) , 0 , 3 , 0 , 0 , 2 } , { 86 , 0 , TARGET_STRING (
 "cstr_simulationEnv/CSTR_1 Simulation Model + Regulatory Control/PID Controller/N Gain/Internal Parameters/Filter Coefficient"
) , TARGET_STRING ( "" ) , 0 , 3 , 0 , 0 , 2 } , { 87 , 0 , TARGET_STRING (
 "cstr_simulationEnv/CSTR_1 Simulation Model + Regulatory Control/PID Controller/Sum/Sum_PID/Sum"
) , TARGET_STRING ( "" ) , 0 , 3 , 0 , 0 , 2 } , { 88 , 0 , TARGET_STRING (
 "cstr_simulationEnv/CSTR_1 Simulation Model + Regulatory Control/PID Controller1/I Gain/Internal Parameters/Integral Gain"
) , TARGET_STRING ( "" ) , 0 , 3 , 0 , 0 , 2 } , { 89 , 0 , TARGET_STRING (
 "cstr_simulationEnv/CSTR_1 Simulation Model + Regulatory Control/PID Controller1/N Gain/Internal Parameters/Filter Coefficient"
) , TARGET_STRING ( "" ) , 0 , 3 , 0 , 0 , 2 } , { 0 , 0 , ( NULL ) , ( NULL
) , 0 , 0 , 0 , 0 , 0 } } ; static const rtwCAPI_BlockParameters
rtBlockParameters [ ] = { { 90 , TARGET_STRING (
"cstr_simulationEnv/Feed_Temperature_In" ) , TARGET_STRING ( "Value" ) , 3 ,
0 , 0 } , { 91 , TARGET_STRING ( "cstr_simulationEnv/Feed_Temperature_Out" )
, TARGET_STRING ( "Value" ) , 3 , 0 , 0 } , { 92 , TARGET_STRING (
"cstr_simulationEnv/Inlet_Flow_In" ) , TARGET_STRING ( "Value" ) , 3 , 0 , 0
} , { 93 , TARGET_STRING ( "cstr_simulationEnv/Inlet_Flow_Out" ) ,
TARGET_STRING ( "Value" ) , 3 , 0 , 0 } , { 94 , TARGET_STRING (
"cstr_simulationEnv/Unit Delay1" ) , TARGET_STRING ( "InitialCondition" ) , 3
, 0 , 0 } , { 95 , TARGET_STRING ( "cstr_simulationEnv/Unit Delay10" ) ,
TARGET_STRING ( "InitialCondition" ) , 0 , 0 , 0 } , { 96 , TARGET_STRING (
"cstr_simulationEnv/Unit Delay11" ) , TARGET_STRING ( "InitialCondition" ) ,
0 , 0 , 0 } , { 97 , TARGET_STRING ( "cstr_simulationEnv/Unit Delay2" ) ,
TARGET_STRING ( "InitialCondition" ) , 3 , 0 , 0 } , { 98 , TARGET_STRING (
"cstr_simulationEnv/Unit Delay6" ) , TARGET_STRING ( "InitialCondition" ) , 3
, 0 , 0 } , { 99 , TARGET_STRING ( "cstr_simulationEnv/Unit Delay7" ) ,
TARGET_STRING ( "InitialCondition" ) , 3 , 0 , 0 } , { 100 , TARGET_STRING (
"cstr_simulationEnv/Unit Delay8" ) , TARGET_STRING ( "InitialCondition" ) , 3
, 0 , 0 } , { 101 , TARGET_STRING ( "cstr_simulationEnv/Unit Delay9" ) ,
TARGET_STRING ( "InitialCondition" ) , 0 , 0 , 0 } , { 102 , TARGET_STRING (
"cstr_simulationEnv/CSTR_1 Simulation Model + Regulatory Control/Difference"
) , TARGET_STRING ( "ICPrevInput" ) , 3 , 0 , 0 } , { 103 , TARGET_STRING (
"cstr_simulationEnv/CSTR_1 Simulation Model + Regulatory Control/Difference1"
) , TARGET_STRING ( "ICPrevInput" ) , 3 , 0 , 0 } , { 104 , TARGET_STRING (
"cstr_simulationEnv/CSTR_1 Simulation Model + Regulatory Control/PID Controller"
) , TARGET_STRING ( "P" ) , 3 , 0 , 0 } , { 105 , TARGET_STRING (
"cstr_simulationEnv/CSTR_1 Simulation Model + Regulatory Control/PID Controller"
) , TARGET_STRING ( "I" ) , 3 , 0 , 0 } , { 106 , TARGET_STRING (
"cstr_simulationEnv/CSTR_1 Simulation Model + Regulatory Control/PID Controller"
) , TARGET_STRING ( "D" ) , 3 , 0 , 0 } , { 107 , TARGET_STRING (
"cstr_simulationEnv/CSTR_1 Simulation Model + Regulatory Control/PID Controller"
) , TARGET_STRING ( "N" ) , 3 , 0 , 0 } , { 108 , TARGET_STRING (
"cstr_simulationEnv/CSTR_1 Simulation Model + Regulatory Control/PID Controller"
) , TARGET_STRING ( "InitialConditionForIntegrator" ) , 3 , 0 , 0 } , { 109 ,
TARGET_STRING (
"cstr_simulationEnv/CSTR_1 Simulation Model + Regulatory Control/PID Controller"
) , TARGET_STRING ( "InitialConditionForFilter" ) , 3 , 0 , 0 } , { 110 ,
TARGET_STRING (
 "cstr_simulationEnv/CSTR_1 Simulation Model + Regulatory Control/PID Controller1"
) , TARGET_STRING ( "P" ) , 3 , 0 , 0 } , { 111 , TARGET_STRING (
 "cstr_simulationEnv/CSTR_1 Simulation Model + Regulatory Control/PID Controller1"
) , TARGET_STRING ( "I" ) , 3 , 0 , 0 } , { 112 , TARGET_STRING (
 "cstr_simulationEnv/CSTR_1 Simulation Model + Regulatory Control/PID Controller1"
) , TARGET_STRING ( "D" ) , 3 , 0 , 0 } , { 113 , TARGET_STRING (
 "cstr_simulationEnv/CSTR_1 Simulation Model + Regulatory Control/PID Controller1"
) , TARGET_STRING ( "N" ) , 3 , 0 , 0 } , { 114 , TARGET_STRING (
 "cstr_simulationEnv/CSTR_1 Simulation Model + Regulatory Control/PID Controller1"
) , TARGET_STRING ( "InitialConditionForIntegrator" ) , 3 , 0 , 0 } , { 115 ,
TARGET_STRING (
 "cstr_simulationEnv/CSTR_1 Simulation Model + Regulatory Control/PID Controller1"
) , TARGET_STRING ( "InitialConditionForFilter" ) , 3 , 0 , 0 } , { 116 ,
TARGET_STRING (
"cstr_simulationEnv/CSTR_1 Simulation Model + Regulatory Control/C_Bin" ) ,
TARGET_STRING ( "Value" ) , 3 , 0 , 0 } , { 117 , TARGET_STRING (
"cstr_simulationEnv/CSTR_1 Simulation Model + Regulatory Control/C_Cin" ) ,
TARGET_STRING ( "Value" ) , 3 , 0 , 0 } , { 118 , TARGET_STRING (
"cstr_simulationEnv/CSTR_1 Simulation Model + Regulatory Control/Constant" )
, TARGET_STRING ( "Value" ) , 3 , 0 , 0 } , { 119 , TARGET_STRING (
"cstr_simulationEnv/CSTR_1 Simulation Model + Regulatory Control/Constant1" )
, TARGET_STRING ( "Value" ) , 3 , 0 , 0 } , { 120 , TARGET_STRING (
"cstr_simulationEnv/CSTR_1 Simulation Model + Regulatory Control/Constant10"
) , TARGET_STRING ( "Value" ) , 3 , 0 , 0 } , { 121 , TARGET_STRING (
"cstr_simulationEnv/CSTR_1 Simulation Model + Regulatory Control/Constant11"
) , TARGET_STRING ( "Value" ) , 3 , 0 , 0 } , { 122 , TARGET_STRING (
"cstr_simulationEnv/CSTR_1 Simulation Model + Regulatory Control/Constant12"
) , TARGET_STRING ( "Value" ) , 3 , 0 , 0 } , { 123 , TARGET_STRING (
"cstr_simulationEnv/CSTR_1 Simulation Model + Regulatory Control/Constant13"
) , TARGET_STRING ( "Value" ) , 3 , 0 , 0 } , { 124 , TARGET_STRING (
"cstr_simulationEnv/CSTR_1 Simulation Model + Regulatory Control/Constant14"
) , TARGET_STRING ( "Value" ) , 3 , 0 , 0 } , { 125 , TARGET_STRING (
"cstr_simulationEnv/CSTR_1 Simulation Model + Regulatory Control/Constant15"
) , TARGET_STRING ( "Value" ) , 3 , 0 , 0 } , { 126 , TARGET_STRING (
"cstr_simulationEnv/CSTR_1 Simulation Model + Regulatory Control/Constant16"
) , TARGET_STRING ( "Value" ) , 3 , 0 , 0 } , { 127 , TARGET_STRING (
"cstr_simulationEnv/CSTR_1 Simulation Model + Regulatory Control/Constant2" )
, TARGET_STRING ( "Value" ) , 3 , 0 , 0 } , { 128 , TARGET_STRING (
"cstr_simulationEnv/CSTR_1 Simulation Model + Regulatory Control/Constant3" )
, TARGET_STRING ( "Value" ) , 3 , 0 , 0 } , { 129 , TARGET_STRING (
"cstr_simulationEnv/CSTR_1 Simulation Model + Regulatory Control/Constant4" )
, TARGET_STRING ( "Value" ) , 3 , 0 , 0 } , { 130 , TARGET_STRING (
"cstr_simulationEnv/CSTR_1 Simulation Model + Regulatory Control/Constant5" )
, TARGET_STRING ( "Value" ) , 3 , 0 , 0 } , { 131 , TARGET_STRING (
"cstr_simulationEnv/CSTR_1 Simulation Model + Regulatory Control/Constant6" )
, TARGET_STRING ( "Value" ) , 3 , 0 , 0 } , { 132 , TARGET_STRING (
"cstr_simulationEnv/CSTR_1 Simulation Model + Regulatory Control/Constant7" )
, TARGET_STRING ( "Value" ) , 3 , 0 , 0 } , { 133 , TARGET_STRING (
"cstr_simulationEnv/CSTR_1 Simulation Model + Regulatory Control/Constant8" )
, TARGET_STRING ( "Value" ) , 3 , 0 , 0 } , { 134 , TARGET_STRING (
"cstr_simulationEnv/CSTR_1 Simulation Model + Regulatory Control/Constant9" )
, TARGET_STRING ( "Value" ) , 3 , 0 , 0 } , { 135 , TARGET_STRING (
"cstr_simulationEnv/CSTR_1 Simulation Model + Regulatory Control/LevelSet" )
, TARGET_STRING ( "Value" ) , 3 , 0 , 0 } , { 136 , TARGET_STRING (
"cstr_simulationEnv/CSTR_1 Simulation Model + Regulatory Control/PA" ) ,
TARGET_STRING ( "Value" ) , 3 , 0 , 0 } , { 137 , TARGET_STRING (
"cstr_simulationEnv/CSTR_1 Simulation Model + Regulatory Control/PB" ) ,
TARGET_STRING ( "Value" ) , 3 , 0 , 0 } , { 138 , TARGET_STRING (
"cstr_simulationEnv/CSTR_1 Simulation Model + Regulatory Control/PC" ) ,
TARGET_STRING ( "Value" ) , 3 , 0 , 0 } , { 139 , TARGET_STRING (
"cstr_simulationEnv/CSTR_1 Simulation Model + Regulatory Control/PCHANGE" ) ,
TARGET_STRING ( "Value" ) , 3 , 0 , 0 } , { 140 , TARGET_STRING (
"cstr_simulationEnv/CSTR_1 Simulation Model + Regulatory Control/PD" ) ,
TARGET_STRING ( "Value" ) , 3 , 0 , 0 } , { 141 , TARGET_STRING (
"cstr_simulationEnv/CSTR_1 Simulation Model + Regulatory Control/PHEAT" ) ,
TARGET_STRING ( "Value" ) , 3 , 0 , 0 } , { 142 , TARGET_STRING (
"cstr_simulationEnv/CSTR_1 Simulation Model + Regulatory Control/Rate3" ) ,
TARGET_STRING ( "Value" ) , 3 , 0 , 0 } , { 143 , TARGET_STRING (
"cstr_simulationEnv/CSTR_1 Simulation Model + Regulatory Control/T_outSet" )
, TARGET_STRING ( "Value" ) , 3 , 0 , 0 } , { 144 , TARGET_STRING (
"cstr_simulationEnv/CSTR_1 Simulation Model + Regulatory Control/From Workspace"
) , TARGET_STRING ( "Time0" ) , 3 , 2 , 0 } , { 145 , TARGET_STRING (
"cstr_simulationEnv/CSTR_1 Simulation Model + Regulatory Control/From Workspace"
) , TARGET_STRING ( "Data0" ) , 3 , 2 , 0 } , { 146 , TARGET_STRING (
 "cstr_simulationEnv/CSTR_1 Simulation Model + Regulatory Control/From Workspace1"
) , TARGET_STRING ( "Time0" ) , 3 , 2 , 0 } , { 147 , TARGET_STRING (
 "cstr_simulationEnv/CSTR_1 Simulation Model + Regulatory Control/From Workspace1"
) , TARGET_STRING ( "Data0" ) , 3 , 2 , 0 } , { 148 , TARGET_STRING (
"cstr_simulationEnv/CSTR_1 Simulation Model + Regulatory Control/Gain" ) ,
TARGET_STRING ( "Gain" ) , 3 , 0 , 0 } , { 149 , TARGET_STRING (
"cstr_simulationEnv/CSTR_1 Simulation Model + Regulatory Control/Gain1" ) ,
TARGET_STRING ( "Gain" ) , 3 , 0 , 0 } , { 150 , TARGET_STRING (
"cstr_simulationEnv/CSTR_1 Simulation Model + Regulatory Control/Gain2" ) ,
TARGET_STRING ( "Gain" ) , 3 , 0 , 0 } , { 151 , TARGET_STRING (
"cstr_simulationEnv/CSTR_1 Simulation Model + Regulatory Control/Integrator"
) , TARGET_STRING ( "InitialCondition" ) , 3 , 0 , 0 } , { 152 ,
TARGET_STRING (
"cstr_simulationEnv/CSTR_1 Simulation Model + Regulatory Control/m file" ) ,
TARGET_STRING ( "P1" ) , 3 , 3 , 0 } , { 153 , TARGET_STRING (
"cstr_simulationEnv/CSTR_1 Simulation Model + Regulatory Control/Switch" ) ,
TARGET_STRING ( "Threshold" ) , 3 , 0 , 0 } , { 154 , TARGET_STRING (
"cstr_simulationEnv/CSTR_1 Simulation Model + Regulatory Control/Switch1" ) ,
TARGET_STRING ( "Threshold" ) , 3 , 0 , 0 } , { 155 , TARGET_STRING (
"cstr_simulationEnv/CSTR_1 Simulation Model + Regulatory Control/Switch10" )
, TARGET_STRING ( "Threshold" ) , 3 , 0 , 0 } , { 156 , TARGET_STRING (
"cstr_simulationEnv/CSTR_1 Simulation Model + Regulatory Control/Switch4" ) ,
TARGET_STRING ( "Threshold" ) , 3 , 0 , 0 } , { 157 , TARGET_STRING (
"cstr_simulationEnv/CSTR_1 Simulation Model + Regulatory Control/Switch6" ) ,
TARGET_STRING ( "Threshold" ) , 3 , 0 , 0 } , { 158 , TARGET_STRING (
 "cstr_simulationEnv/CSTR_1 Simulation Model + Regulatory Control/Uniform Random Number"
) , TARGET_STRING ( "Minimum" ) , 3 , 0 , 0 } , { 159 , TARGET_STRING (
 "cstr_simulationEnv/CSTR_1 Simulation Model + Regulatory Control/Uniform Random Number"
) , TARGET_STRING ( "Maximum" ) , 3 , 0 , 0 } , { 160 , TARGET_STRING (
 "cstr_simulationEnv/CSTR_1 Simulation Model + Regulatory Control/Uniform Random Number"
) , TARGET_STRING ( "Seed" ) , 3 , 0 , 0 } , { 161 , TARGET_STRING (
 "cstr_simulationEnv/CSTR_1 Simulation Model + Regulatory Control/Uniform Random Number1"
) , TARGET_STRING ( "Minimum" ) , 3 , 0 , 0 } , { 162 , TARGET_STRING (
 "cstr_simulationEnv/CSTR_1 Simulation Model + Regulatory Control/Uniform Random Number1"
) , TARGET_STRING ( "Maximum" ) , 3 , 0 , 0 } , { 163 , TARGET_STRING (
 "cstr_simulationEnv/CSTR_1 Simulation Model + Regulatory Control/Uniform Random Number1"
) , TARGET_STRING ( "Seed" ) , 3 , 0 , 0 } , { 164 , TARGET_STRING (
 "cstr_simulationEnv/CSTR_1 Simulation Model + Regulatory Control/Uniform Random Number2"
) , TARGET_STRING ( "Minimum" ) , 3 , 0 , 0 } , { 165 , TARGET_STRING (
 "cstr_simulationEnv/CSTR_1 Simulation Model + Regulatory Control/Uniform Random Number2"
) , TARGET_STRING ( "Maximum" ) , 3 , 0 , 0 } , { 166 , TARGET_STRING (
 "cstr_simulationEnv/CSTR_1 Simulation Model + Regulatory Control/Uniform Random Number2"
) , TARGET_STRING ( "Seed" ) , 3 , 0 , 0 } , { 167 , TARGET_STRING (
 "cstr_simulationEnv/CSTR_1 Simulation Model + Regulatory Control/Uniform Random Number3"
) , TARGET_STRING ( "Minimum" ) , 3 , 0 , 0 } , { 168 , TARGET_STRING (
 "cstr_simulationEnv/CSTR_1 Simulation Model + Regulatory Control/Uniform Random Number3"
) , TARGET_STRING ( "Maximum" ) , 3 , 0 , 0 } , { 169 , TARGET_STRING (
 "cstr_simulationEnv/CSTR_1 Simulation Model + Regulatory Control/Uniform Random Number3"
) , TARGET_STRING ( "Seed" ) , 3 , 0 , 0 } , { 170 , TARGET_STRING (
 "cstr_simulationEnv/CSTR_1 Simulation Model + Regulatory Control/Uniform Random Number4"
) , TARGET_STRING ( "Minimum" ) , 3 , 0 , 0 } , { 171 , TARGET_STRING (
 "cstr_simulationEnv/CSTR_1 Simulation Model + Regulatory Control/Uniform Random Number4"
) , TARGET_STRING ( "Maximum" ) , 3 , 0 , 0 } , { 172 , TARGET_STRING (
 "cstr_simulationEnv/CSTR_1 Simulation Model + Regulatory Control/Uniform Random Number4"
) , TARGET_STRING ( "Seed" ) , 3 , 0 , 0 } , { 173 , TARGET_STRING (
 "cstr_simulationEnv/CSTR_1 Simulation Model + Regulatory Control/Uniform Random Number5"
) , TARGET_STRING ( "Minimum" ) , 3 , 0 , 0 } , { 174 , TARGET_STRING (
 "cstr_simulationEnv/CSTR_1 Simulation Model + Regulatory Control/Uniform Random Number5"
) , TARGET_STRING ( "Maximum" ) , 3 , 0 , 0 } , { 175 , TARGET_STRING (
 "cstr_simulationEnv/CSTR_1 Simulation Model + Regulatory Control/Uniform Random Number5"
) , TARGET_STRING ( "Seed" ) , 3 , 0 , 0 } , { 176 , TARGET_STRING (
"cstr_simulationEnv/CSTR_1 Simulation Model + Regulatory Control/Unit Delay1"
) , TARGET_STRING ( "InitialCondition" ) , 3 , 0 , 0 } , { 177 ,
TARGET_STRING (
"cstr_simulationEnv/CSTR_1 Simulation Model + Regulatory Control/Unit Delay2"
) , TARGET_STRING ( "InitialCondition" ) , 3 , 0 , 0 } , { 178 ,
TARGET_STRING (
"cstr_simulationEnv/CSTR_1 Simulation Model + Regulatory Control/Unit Delay6"
) , TARGET_STRING ( "InitialCondition" ) , 3 , 0 , 0 } , { 179 ,
TARGET_STRING ( "cstr_simulationEnv/Fault Engine/Ramp" ) , TARGET_STRING (
"slope" ) , 3 , 0 , 0 } , { 180 , TARGET_STRING (
"cstr_simulationEnv/Fault Engine/Ramp" ) , TARGET_STRING ( "start" ) , 3 , 0
, 0 } , { 181 , TARGET_STRING ( "cstr_simulationEnv/Fault Engine/Ramp" ) ,
TARGET_STRING ( "InitialOutput" ) , 3 , 0 , 0 } , { 182 , TARGET_STRING (
"cstr_simulationEnv/Fault Engine/Constant" ) , TARGET_STRING ( "Value" ) , 3
, 0 , 0 } , { 183 , TARGET_STRING (
"cstr_simulationEnv/Fault Engine/Constant11" ) , TARGET_STRING ( "Value" ) ,
3 , 0 , 0 } , { 184 , TARGET_STRING (
"cstr_simulationEnv/Fault Engine/Constant12" ) , TARGET_STRING ( "Value" ) ,
3 , 0 , 0 } , { 185 , TARGET_STRING (
"cstr_simulationEnv/Fault Engine/Constant13" ) , TARGET_STRING ( "Value" ) ,
3 , 0 , 0 } , { 186 , TARGET_STRING (
"cstr_simulationEnv/Fault Engine/Constant29" ) , TARGET_STRING ( "Value" ) ,
3 , 0 , 0 } , { 187 , TARGET_STRING (
"cstr_simulationEnv/Fault Engine/Constant30" ) , TARGET_STRING ( "Value" ) ,
3 , 0 , 0 } , { 188 , TARGET_STRING (
"cstr_simulationEnv/Fault Engine/Constant31" ) , TARGET_STRING ( "Value" ) ,
3 , 0 , 0 } , { 189 , TARGET_STRING (
"cstr_simulationEnv/Fault Engine/Constant32" ) , TARGET_STRING ( "Value" ) ,
3 , 0 , 0 } , { 190 , TARGET_STRING (
"cstr_simulationEnv/Fault Engine/Constant33" ) , TARGET_STRING ( "Value" ) ,
3 , 0 , 0 } , { 191 , TARGET_STRING (
"cstr_simulationEnv/Fault Engine/Constant40" ) , TARGET_STRING ( "Value" ) ,
3 , 0 , 0 } , { 192 , TARGET_STRING (
"cstr_simulationEnv/Fault Engine/Constant41" ) , TARGET_STRING ( "Value" ) ,
3 , 0 , 0 } , { 193 , TARGET_STRING (
"cstr_simulationEnv/Fault Engine/Constant42" ) , TARGET_STRING ( "Value" ) ,
3 , 0 , 0 } , { 194 , TARGET_STRING (
"cstr_simulationEnv/Fault Engine/Constant43" ) , TARGET_STRING ( "Value" ) ,
3 , 0 , 0 } , { 195 , TARGET_STRING (
"cstr_simulationEnv/Fault Engine/Constant44" ) , TARGET_STRING ( "Value" ) ,
3 , 0 , 0 } , { 196 , TARGET_STRING (
"cstr_simulationEnv/Fault Engine/Memory" ) , TARGET_STRING (
"InitialCondition" ) , 3 , 0 , 0 } , { 197 , TARGET_STRING (
"cstr_simulationEnv/Fault Engine/Memory10" ) , TARGET_STRING (
"InitialCondition" ) , 3 , 0 , 0 } , { 198 , TARGET_STRING (
"cstr_simulationEnv/Fault Engine/Memory6" ) , TARGET_STRING (
"InitialCondition" ) , 3 , 0 , 0 } , { 199 , TARGET_STRING (
"cstr_simulationEnv/Fault Engine/Saturation" ) , TARGET_STRING ( "UpperLimit"
) , 3 , 0 , 0 } , { 200 , TARGET_STRING (
"cstr_simulationEnv/Fault Engine/Saturation" ) , TARGET_STRING ( "LowerLimit"
) , 3 , 0 , 0 } , { 201 , TARGET_STRING (
"cstr_simulationEnv/Fault Engine/Switch13" ) , TARGET_STRING ( "Threshold" )
, 3 , 0 , 0 } , { 202 , TARGET_STRING (
"cstr_simulationEnv/Fault Engine/Switch14" ) , TARGET_STRING ( "Threshold" )
, 3 , 0 , 0 } , { 203 , TARGET_STRING (
"cstr_simulationEnv/Fault Engine/Switch22" ) , TARGET_STRING ( "Threshold" )
, 3 , 0 , 0 } , { 204 , TARGET_STRING (
"cstr_simulationEnv/Fault Engine/Switch23" ) , TARGET_STRING ( "Threshold" )
, 3 , 0 , 0 } , { 205 , TARGET_STRING (
"cstr_simulationEnv/Fault Engine/Switch4" ) , TARGET_STRING ( "Threshold" ) ,
3 , 0 , 0 } , { 206 , TARGET_STRING (
"cstr_simulationEnv/Fault Engine/Switch5" ) , TARGET_STRING ( "Threshold" ) ,
3 , 0 , 0 } , { 207 , TARGET_STRING (
"cstr_simulationEnv/Fault Engine/Consider Fault1" ) , TARGET_STRING (
"CurrentSetting" ) , 2 , 0 , 0 } , { 208 , TARGET_STRING (
"cstr_simulationEnv/Fault Engine/Consider Fault11" ) , TARGET_STRING (
"CurrentSetting" ) , 2 , 0 , 0 } , { 209 , TARGET_STRING (
"cstr_simulationEnv/Fault Engine/Consider Fault7" ) , TARGET_STRING (
"CurrentSetting" ) , 2 , 0 , 0 } , { 210 , TARGET_STRING (
"cstr_simulationEnv/Fault Engine/Uniform Random Number10" ) , TARGET_STRING (
"Minimum" ) , 3 , 0 , 0 } , { 211 , TARGET_STRING (
"cstr_simulationEnv/Fault Engine/Uniform Random Number10" ) , TARGET_STRING (
"Maximum" ) , 3 , 0 , 0 } , { 212 , TARGET_STRING (
"cstr_simulationEnv/Fault Engine/Uniform Random Number10" ) , TARGET_STRING (
"Seed" ) , 3 , 0 , 0 } , { 213 , TARGET_STRING (
"cstr_simulationEnv/Fault Engine/Uniform Random Number2" ) , TARGET_STRING (
"Minimum" ) , 3 , 0 , 0 } , { 214 , TARGET_STRING (
"cstr_simulationEnv/Fault Engine/Uniform Random Number2" ) , TARGET_STRING (
"Maximum" ) , 3 , 0 , 0 } , { 215 , TARGET_STRING (
"cstr_simulationEnv/Fault Engine/Uniform Random Number2" ) , TARGET_STRING (
"Seed" ) , 3 , 0 , 0 } , { 216 , TARGET_STRING (
"cstr_simulationEnv/Fault Engine/Uniform Random Number6" ) , TARGET_STRING (
"Minimum" ) , 3 , 0 , 0 } , { 217 , TARGET_STRING (
"cstr_simulationEnv/Fault Engine/Uniform Random Number6" ) , TARGET_STRING (
"Maximum" ) , 3 , 0 , 0 } , { 218 , TARGET_STRING (
"cstr_simulationEnv/Fault Engine/Uniform Random Number6" ) , TARGET_STRING (
"Seed" ) , 3 , 0 , 0 } , { 219 , TARGET_STRING (
"cstr_simulationEnv/SIF/Relay" ) , TARGET_STRING ( "OnSwitchValue" ) , 3 , 0
, 0 } , { 220 , TARGET_STRING ( "cstr_simulationEnv/SIF/Relay" ) ,
TARGET_STRING ( "OffSwitchValue" ) , 3 , 0 , 0 } , { 221 , TARGET_STRING (
"cstr_simulationEnv/SIF/Relay" ) , TARGET_STRING ( "OnOutputValue" ) , 3 , 0
, 0 } , { 222 , TARGET_STRING ( "cstr_simulationEnv/SIF/Relay" ) ,
TARGET_STRING ( "OffOutputValue" ) , 3 , 0 , 0 } , { 223 , TARGET_STRING (
"cstr_simulationEnv/SIF/Relay1" ) , TARGET_STRING ( "OnSwitchValue" ) , 3 , 0
, 0 } , { 224 , TARGET_STRING ( "cstr_simulationEnv/SIF/Relay1" ) ,
TARGET_STRING ( "OffSwitchValue" ) , 3 , 0 , 0 } , { 225 , TARGET_STRING (
"cstr_simulationEnv/SIF/Relay1" ) , TARGET_STRING ( "OnOutputValue" ) , 3 , 0
, 0 } , { 226 , TARGET_STRING ( "cstr_simulationEnv/SIF/Relay1" ) ,
TARGET_STRING ( "OffOutputValue" ) , 3 , 0 , 0 } , { 227 , TARGET_STRING (
"cstr_simulationEnv/SIF/Relay2" ) , TARGET_STRING ( "OnSwitchValue" ) , 3 , 0
, 0 } , { 228 , TARGET_STRING ( "cstr_simulationEnv/SIF/Relay2" ) ,
TARGET_STRING ( "OffSwitchValue" ) , 3 , 0 , 0 } , { 229 , TARGET_STRING (
"cstr_simulationEnv/SIF/Relay2" ) , TARGET_STRING ( "OnOutputValue" ) , 3 , 0
, 0 } , { 230 , TARGET_STRING ( "cstr_simulationEnv/SIF/Relay2" ) ,
TARGET_STRING ( "OffOutputValue" ) , 3 , 0 , 0 } , { 231 , TARGET_STRING (
"cstr_simulationEnv/Fault Engine/Ramp/Step" ) , TARGET_STRING ( "Before" ) ,
3 , 0 , 0 } , { 232 , TARGET_STRING (
 "cstr_simulationEnv/State-based Control System/Automatic.Shut_Down.Feed_Temperature_Ramp_SD.Feed_Temperature_Ramp_SD/Out1"
) , TARGET_STRING ( "InitialOutput" ) , 3 , 0 , 0 } , { 233 , TARGET_STRING (
 "cstr_simulationEnv/State-based Control System/Automatic.Shut_Down.Feed_Temperature_Ramp_SD.Feed_Temperature_Ramp_SD/Constant"
) , TARGET_STRING ( "Value" ) , 3 , 0 , 0 } , { 234 , TARGET_STRING (
 "cstr_simulationEnv/State-based Control System/Automatic.Shut_Down.Feed_Temperature_Ramp_SD.Feed_Temperature_Ramp_SD/Saturation"
) , TARGET_STRING ( "UpperLimit" ) , 3 , 0 , 0 } , { 235 , TARGET_STRING (
 "cstr_simulationEnv/State-based Control System/Automatic.Shut_Down.Feed_Temperature_Ramp_SD.Feed_Temperature_Ramp_SD/Saturation"
) , TARGET_STRING ( "LowerLimit" ) , 3 , 0 , 0 } , { 236 , TARGET_STRING (
 "cstr_simulationEnv/State-based Control System/Automatic.Shut_Down.Inlet_Flow_Ramp_SD.Inlet_Flow_Ramp_SD/Out1"
) , TARGET_STRING ( "InitialOutput" ) , 3 , 0 , 0 } , { 237 , TARGET_STRING (
 "cstr_simulationEnv/State-based Control System/Automatic.Shut_Down.Inlet_Flow_Ramp_SD.Inlet_Flow_Ramp_SD/Constant"
) , TARGET_STRING ( "Value" ) , 3 , 0 , 0 } , { 238 , TARGET_STRING (
 "cstr_simulationEnv/State-based Control System/Automatic.Shut_Down.Inlet_Flow_Ramp_SD.Inlet_Flow_Ramp_SD/Saturation"
) , TARGET_STRING ( "UpperLimit" ) , 3 , 0 , 0 } , { 239 , TARGET_STRING (
 "cstr_simulationEnv/State-based Control System/Automatic.Shut_Down.Inlet_Flow_Ramp_SD.Inlet_Flow_Ramp_SD/Saturation"
) , TARGET_STRING ( "LowerLimit" ) , 3 , 0 , 0 } , { 240 , TARGET_STRING (
 "cstr_simulationEnv/State-based Control System/Automatic.Start_Up.Feed_Temperature_Ramp_SU.Feed_Temperature_Ramp_SU/Out1"
) , TARGET_STRING ( "InitialOutput" ) , 3 , 0 , 0 } , { 241 , TARGET_STRING (
 "cstr_simulationEnv/State-based Control System/Automatic.Start_Up.Feed_Temperature_Ramp_SU.Feed_Temperature_Ramp_SU/Constant"
) , TARGET_STRING ( "Value" ) , 3 , 0 , 0 } , { 242 , TARGET_STRING (
 "cstr_simulationEnv/State-based Control System/Automatic.Start_Up.Feed_Temperature_Ramp_SU.Feed_Temperature_Ramp_SU/Saturation"
) , TARGET_STRING ( "UpperLimit" ) , 3 , 0 , 0 } , { 243 , TARGET_STRING (
 "cstr_simulationEnv/State-based Control System/Automatic.Start_Up.Feed_Temperature_Ramp_SU.Feed_Temperature_Ramp_SU/Saturation"
) , TARGET_STRING ( "LowerLimit" ) , 3 , 0 , 0 } , { 244 , TARGET_STRING (
 "cstr_simulationEnv/State-based Control System/Automatic.Start_Up.Inlet_Flow_Ramp_SU.Inlet_Flow_Ramp_SU/Out1"
) , TARGET_STRING ( "InitialOutput" ) , 3 , 0 , 0 } , { 245 , TARGET_STRING (
 "cstr_simulationEnv/State-based Control System/Automatic.Start_Up.Inlet_Flow_Ramp_SU.Inlet_Flow_Ramp_SU/Constant"
) , TARGET_STRING ( "Value" ) , 3 , 0 , 0 } , { 246 , TARGET_STRING (
 "cstr_simulationEnv/State-based Control System/Automatic.Start_Up.Inlet_Flow_Ramp_SU.Inlet_Flow_Ramp_SU/Saturation"
) , TARGET_STRING ( "UpperLimit" ) , 3 , 0 , 0 } , { 247 , TARGET_STRING (
 "cstr_simulationEnv/State-based Control System/Automatic.Start_Up.Inlet_Flow_Ramp_SU.Inlet_Flow_Ramp_SU/Saturation"
) , TARGET_STRING ( "LowerLimit" ) , 3 , 0 , 0 } , { 0 , ( NULL ) , ( NULL )
, 0 , 0 , 0 } } ; static int_T rt_LoggedStateIdxList [ ] = { - 1 } ; static
const rtwCAPI_Signals rtRootInputs [ ] = { { 0 , 0 , ( NULL ) , ( NULL ) , 0
, 0 , 0 , 0 , 0 } } ; static const rtwCAPI_Signals rtRootOutputs [ ] = { { 0
, 0 , ( NULL ) , ( NULL ) , 0 , 0 , 0 , 0 , 0 } } ; static const
rtwCAPI_ModelParameters rtModelParameters [ ] = { { 248 , TARGET_STRING (
"Xinitial" ) , 3 , 4 , 0 } , { 0 , ( NULL ) , 0 , 0 , 0 } } ;
#ifndef HOST_CAPI_BUILD
static void * rtDataAddrMap [ ] = { & rtB . koa2xwzkqz , & rtB . llcmsauyav ,
& rtB . govtsadkmh , & rtB . gfgfscs3wh , & rtB . hwlkc3gph4 , & rtB .
ipy2o045sf , & rtB . ggozffptrp , & rtB . ln01g2x54f , & rtDW . cnphnmyixz ,
& rtDW . lyrzf3l331 , & rtDW . o5lpscgpim , & rtDW . i33gdokzps , & rtDW .
puvxpdyspy , & rtDW . hvipzkfxby , & rtDW . b2oh0gakei , & rtDW . cuxelkmbzn
, & rtB . gvytu245ky , & rtB . ai311bapfw , & rtB . nr5jzefs11 , & rtB .
g4otcjhaps , & rtB . c50enbqbhd , & rtDW . arjuzvir0v , & rtDW . a3naafic3w ,
& rtDW . g0pte1h22i , & rtDW . ksqmuzqxoq , & rtDW . jraid5zlrs , & rtDW .
hjgrew42b2 , & rtDW . ntbs21hax4 , & rtDW . eyqkltgelg , & rtDW . il0ohwuds5
, & rtB . d5u0rvgiee , & rtB . k3xz1ht2ij , & rtB . iorisswymh , & rtB .
l4lnonwfg2 , & rtB . c1djdqayjj , & rtB . hdnlmp40uy , & rtB . euqxsw55q1 , &
rtB . h1nl0bfw4n , & rtB . oqv2owxgui , & rtB . lrowya24l3 , & rtB .
mdshgnp3xt , & rtB . gnzysggnk4 , & rtB . iu3dgzsmox , & rtB . mpecnpblvq , &
rtB . atjpekwwur , & rtB . ib3grttpul , & rtB . i2sxt22wo1 , & rtB .
bbrn1ou5mh , & rtB . e0gpvxxppp [ 0 ] , & rtB . ggli2ppxyv , & rtB .
kzqd3pbqkr , & rtB . n1f2ld0elb , & rtB . ex4xrkfleq , & rtB . eo3aq2xcix , &
rtB . dv5gz4icu0 , & rtB . jantdzvoeu , & rtB . jxqv3hrimg , & rtB .
dsy5xuerr4 , & rtB . mciogha2ud , & rtB . k3jie4wym5 , & rtB . gs2acg4a1b , &
rtB . b4ykqqwob2 , & rtB . ipwdgvuaap , & rtB . lgnqauvekd , & rtB .
efsjkrykwf , & rtB . pzmuj11ybr , & rtB . fscu2cadee , & rtB . lps2tdsik3 , &
rtB . dztq1uxeww , & rtB . fnykzau3dd , & rtB . bzuganxdf2 , & rtB .
bd3otgosaa , & rtB . mcsqmnaiu3 , & rtB . pwkazhfzxj , & rtB . imj24wyej4 , &
rtB . bano4r405l , & rtB . cx2r4dbgvi , & rtB . e5i1gkys053 . nyju2jnyn3 , &
rtB . o0l0tlmums2 . ebzcxl42h5 , & rtB . lsul0j3thv5 . nzhrh1tkt0 , & rtB .
lvdmxslirzu . ppbrf42mvn , & rtB . e5i1gkys053 . nyju2jnyn3 , & rtB .
o0l0tlmums2 . ebzcxl42h5 , & rtB . lsul0j3thv5 . nzhrh1tkt0 , & rtB .
lvdmxslirzu . ppbrf42mvn , & rtB . owumd2pxxx , & rtB . jkvshhuv25 , & rtB .
ifp2xzx5cj , & rtB . bmollnwf0s , & rtB . czzkhzteyg , & rtP .
Feed_Temperature_In_Value , & rtP . Feed_Temperature_Out_Value , & rtP .
Inlet_Flow_In_Value , & rtP . Inlet_Flow_Out_Value , & rtP .
UnitDelay1_InitialCondition , & rtP . UnitDelay10_InitialCondition , & rtP .
UnitDelay11_InitialCondition , & rtP . UnitDelay2_InitialCondition , & rtP .
UnitDelay6_InitialCondition , & rtP . UnitDelay7_InitialCondition , & rtP .
UnitDelay8_InitialCondition , & rtP . UnitDelay9_InitialCondition , & rtP .
Difference_ICPrevInput , & rtP . Difference1_ICPrevInput , & rtP .
PIDController_P , & rtP . PIDController_I , & rtP . PIDController_D , & rtP .
PIDController_N , & rtP . PIDController_InitialConditionForIntegrator , & rtP
. PIDController_InitialConditionForFilter , & rtP . PIDController1_P , & rtP
. PIDController1_I , & rtP . PIDController1_D , & rtP . PIDController1_N , &
rtP . PIDController1_InitialConditionForIntegrator , & rtP .
PIDController1_InitialConditionForFilter , & rtP . C_Bin_Value , & rtP .
C_Cin_Value , & rtP . Constant_Value , & rtP . Constant1_Value , & rtP .
Constant10_Value , & rtP . Constant11_Value , & rtP . Constant12_Value , &
rtP . Constant13_Value , & rtP . Constant14_Value , & rtP . Constant15_Value
, & rtP . Constant16_Value , & rtP . Constant2_Value , & rtP .
Constant3_Value , & rtP . Constant4_Value , & rtP . Constant5_Value , & rtP .
Constant6_Value , & rtP . Constant7_Value , & rtP . Constant8_Value , & rtP .
Constant9_Value , & rtP . LevelSet_Value , & rtP . PA_Value , & rtP .
PB_Value , & rtP . PC_Value , & rtP . PCHANGE_Value , & rtP . PD_Value , &
rtP . PHEAT_Value , & rtP . Rate3_Value , & rtP . T_outSet_Value , & rtP .
FromWorkspace_Time0 [ 0 ] , & rtP . FromWorkspace_Data0 [ 0 ] , & rtP .
FromWorkspace1_Time0 [ 0 ] , & rtP . FromWorkspace1_Data0 [ 0 ] , & rtP .
Gain_Gain , & rtP . Gain1_Gain , & rtP . Gain2_Gain , & rtP . Integrator_IC ,
& rtP . mfile_P1 [ 0 ] , & rtP . Switch_Threshold , & rtP . Switch1_Threshold
, & rtP . Switch10_Threshold , & rtP . Switch4_Threshold_oqqlidhi4v , & rtP .
Switch6_Threshold , & rtP . UniformRandomNumber_Minimum , & rtP .
UniformRandomNumber_Maximum , & rtP . UniformRandomNumber_Seed , & rtP .
UniformRandomNumber1_Minimum , & rtP . UniformRandomNumber1_Maximum , & rtP .
UniformRandomNumber1_Seed , & rtP . UniformRandomNumber2_Minimum_fx5mnbvdh4 ,
& rtP . UniformRandomNumber2_Maximum_h0hkt0qhvs , & rtP .
UniformRandomNumber2_Seed_l3l21jyov0 , & rtP . UniformRandomNumber3_Minimum ,
& rtP . UniformRandomNumber3_Maximum , & rtP . UniformRandomNumber3_Seed , &
rtP . UniformRandomNumber4_Minimum , & rtP . UniformRandomNumber4_Maximum , &
rtP . UniformRandomNumber4_Seed , & rtP . UniformRandomNumber5_Minimum , &
rtP . UniformRandomNumber5_Maximum , & rtP . UniformRandomNumber5_Seed , &
rtP . UnitDelay1_InitialCondition_fked3caosb , & rtP .
UnitDelay2_InitialCondition_cz3sr01ooy , & rtP .
UnitDelay6_InitialCondition_m0rhsscivj , & rtP . Ramp_slope , & rtP .
Ramp_start , & rtP . Ramp_InitialOutput , & rtP . Constant_Value_lg13tpamfv ,
& rtP . Constant11_Value_jvwwu02wty , & rtP . Constant12_Value_ce5osxgbbp , &
rtP . Constant13_Value_jemti03zwx , & rtP . Constant29_Value , & rtP .
Constant30_Value , & rtP . Constant31_Value , & rtP . Constant32_Value , &
rtP . Constant33_Value , & rtP . Constant40_Value , & rtP . Constant41_Value
, & rtP . Constant42_Value , & rtP . Constant43_Value , & rtP .
Constant44_Value , & rtP . Memory_InitialCondition , & rtP .
Memory10_InitialCondition , & rtP . Memory6_InitialCondition , & rtP .
Saturation_UpperSat , & rtP . Saturation_LowerSat , & rtP .
Switch13_Threshold , & rtP . Switch14_Threshold , & rtP . Switch22_Threshold
, & rtP . Switch23_Threshold , & rtP . Switch4_Threshold , & rtP .
Switch5_Threshold , & rtP . ConsiderFault1_CurrentSetting , & rtP .
ConsiderFault11_CurrentSetting , & rtP . ConsiderFault7_CurrentSetting , &
rtP . UniformRandomNumber10_Minimum , & rtP . UniformRandomNumber10_Maximum ,
& rtP . UniformRandomNumber10_Seed , & rtP . UniformRandomNumber2_Minimum , &
rtP . UniformRandomNumber2_Maximum , & rtP . UniformRandomNumber2_Seed , &
rtP . UniformRandomNumber6_Minimum , & rtP . UniformRandomNumber6_Maximum , &
rtP . UniformRandomNumber6_Seed , & rtP . Relay_OnVal , & rtP . Relay_OffVal
, & rtP . Relay_YOn , & rtP . Relay_YOff , & rtP . Relay1_OnVal , & rtP .
Relay1_OffVal , & rtP . Relay1_YOn , & rtP . Relay1_YOff , & rtP .
Relay2_OnVal , & rtP . Relay2_OffVal , & rtP . Relay2_YOn , & rtP .
Relay2_YOff , & rtP . Step_Y0 , & rtP . e5i1gkys053 . Out1_Y0 , & rtP .
e5i1gkys053 . Constant_Value , & rtP . e5i1gkys053 . Saturation_UpperSat , &
rtP . e5i1gkys053 . Saturation_LowerSat , & rtP . o0l0tlmums2 . Out1_Y0 , &
rtP . o0l0tlmums2 . Constant_Value , & rtP . o0l0tlmums2 .
Saturation_UpperSat , & rtP . o0l0tlmums2 . Saturation_LowerSat , & rtP .
lsul0j3thv5 . Out1_Y0 , & rtP . lsul0j3thv5 . Constant_Value , & rtP .
lsul0j3thv5 . Saturation_UpperSat , & rtP . lsul0j3thv5 . Saturation_LowerSat
, & rtP . lvdmxslirzu . Out1_Y0 , & rtP . lvdmxslirzu . Constant_Value , &
rtP . lvdmxslirzu . Saturation_UpperSat , & rtP . lvdmxslirzu .
Saturation_LowerSat , & rtP . Xinitial [ 0 ] , } ; static int32_T *
rtVarDimsAddrMap [ ] = { ( NULL ) } ;
#endif
static TARGET_CONST rtwCAPI_DataTypeMap rtDataTypeMap [ ] = { {
"unsigned char" , "boolean_T" , 0 , 0 , sizeof ( boolean_T ) , ( uint8_T )
SS_BOOLEAN , 0 , 0 , 0 } , { "unsigned int" , "uint32_T" , 0 , 0 , sizeof (
uint32_T ) , ( uint8_T ) SS_UINT32 , 0 , 0 , 0 } , { "unsigned char" ,
"uint8_T" , 0 , 0 , sizeof ( uint8_T ) , ( uint8_T ) SS_UINT8 , 0 , 0 , 0 } ,
{ "double" , "real_T" , 0 , 0 , sizeof ( real_T ) , ( uint8_T ) SS_DOUBLE , 0
, 0 , 0 } } ;
#ifdef HOST_CAPI_BUILD
#undef sizeof
#endif
static TARGET_CONST rtwCAPI_ElementMap rtElementMap [ ] = { { ( NULL ) , 0 ,
0 , 0 , 0 } , } ; static const rtwCAPI_DimensionMap rtDimensionMap [ ] = { {
rtwCAPI_SCALAR , 0 , 2 , 0 } , { rtwCAPI_VECTOR , 2 , 2 , 0 } , {
rtwCAPI_VECTOR , 4 , 2 , 0 } , { rtwCAPI_VECTOR , 6 , 2 , 0 } , {
rtwCAPI_VECTOR , 8 , 2 , 0 } } ; static const uint_T rtDimensionArray [ ] = {
1 , 1 , 9 , 1 , 5001 , 1 , 10 , 1 , 6 , 1 } ; static const real_T
rtcapiStoredFloats [ ] = { 1.0 , 0.0 , 500.0 , 5.0 } ; static const
rtwCAPI_FixPtMap rtFixPtMap [ ] = { { ( NULL ) , ( NULL ) ,
rtwCAPI_FIX_RESERVED , 0 , 0 , ( boolean_T ) 0 } , } ; static const
rtwCAPI_SampleTimeMap rtSampleTimeMap [ ] = { { ( const void * ) &
rtcapiStoredFloats [ 0 ] , ( const void * ) & rtcapiStoredFloats [ 1 ] , (
int8_T ) 1 , ( uint8_T ) 0 } , { ( NULL ) , ( NULL ) , 4 , 0 } , { ( const
void * ) & rtcapiStoredFloats [ 1 ] , ( const void * ) & rtcapiStoredFloats [
1 ] , ( int8_T ) 0 , ( uint8_T ) 0 } , { ( const void * ) &
rtcapiStoredFloats [ 2 ] , ( const void * ) & rtcapiStoredFloats [ 1 ] , (
int8_T ) 3 , ( uint8_T ) 0 } , { ( const void * ) & rtcapiStoredFloats [ 3 ]
, ( const void * ) & rtcapiStoredFloats [ 1 ] , ( int8_T ) 2 , ( uint8_T ) 0
} , { ( NULL ) , ( NULL ) , - 1 , 0 } } ; static
rtwCAPI_ModelMappingStaticInfo mmiStatic = { { rtBlockSignals , 90 ,
rtRootInputs , 0 , rtRootOutputs , 0 } , { rtBlockParameters , 158 ,
rtModelParameters , 1 } , { ( NULL ) , 0 } , { rtDataTypeMap , rtDimensionMap
, rtFixPtMap , rtElementMap , rtSampleTimeMap , rtDimensionArray } , "float"
, { 4260740495U , 4141272003U , 4182188841U , 2629175771U } , ( NULL ) , 0 ,
( boolean_T ) 0 , rt_LoggedStateIdxList } ; const
rtwCAPI_ModelMappingStaticInfo * cstr_simulationEnv_GetCAPIStaticMap ( void )
{ return & mmiStatic ; }
#ifndef HOST_CAPI_BUILD
void cstr_simulationEnv_InitializeDataMapInfo ( void ) { rtwCAPI_SetVersion (
( * rt_dataMapInfoPtr ) . mmi , 1 ) ; rtwCAPI_SetStaticMap ( ( *
rt_dataMapInfoPtr ) . mmi , & mmiStatic ) ; rtwCAPI_SetLoggingStaticMap ( ( *
rt_dataMapInfoPtr ) . mmi , ( NULL ) ) ; rtwCAPI_SetDataAddressMap ( ( *
rt_dataMapInfoPtr ) . mmi , rtDataAddrMap ) ; rtwCAPI_SetVarDimsAddressMap (
( * rt_dataMapInfoPtr ) . mmi , rtVarDimsAddrMap ) ;
rtwCAPI_SetInstanceLoggingInfo ( ( * rt_dataMapInfoPtr ) . mmi , ( NULL ) ) ;
rtwCAPI_SetChildMMIArray ( ( * rt_dataMapInfoPtr ) . mmi , ( NULL ) ) ;
rtwCAPI_SetChildMMIArrayLen ( ( * rt_dataMapInfoPtr ) . mmi , 0 ) ; }
#else
#ifdef __cplusplus
extern "C" {
#endif
void cstr_simulationEnv_host_InitializeDataMapInfo (
cstr_simulationEnv_host_DataMapInfo_T * dataMap , const char * path ) {
rtwCAPI_SetVersion ( dataMap -> mmi , 1 ) ; rtwCAPI_SetStaticMap ( dataMap ->
mmi , & mmiStatic ) ; rtwCAPI_SetDataAddressMap ( dataMap -> mmi , ( NULL ) )
; rtwCAPI_SetVarDimsAddressMap ( dataMap -> mmi , ( NULL ) ) ;
rtwCAPI_SetPath ( dataMap -> mmi , path ) ; rtwCAPI_SetFullPath ( dataMap ->
mmi , ( NULL ) ) ; rtwCAPI_SetChildMMIArray ( dataMap -> mmi , ( NULL ) ) ;
rtwCAPI_SetChildMMIArrayLen ( dataMap -> mmi , 0 ) ; }
#ifdef __cplusplus
}
#endif
#endif
