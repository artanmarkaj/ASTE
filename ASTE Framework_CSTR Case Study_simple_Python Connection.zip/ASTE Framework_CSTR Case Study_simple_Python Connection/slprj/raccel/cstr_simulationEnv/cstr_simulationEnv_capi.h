#ifndef RTW_HEADER_cstr_simulationEnv_capi_h_
#define RTW_HEADER_cstr_simulationEnv_capi_h_
#include "cstr_simulationEnv.h"
extern void cstr_simulationEnv_InitializeDataMapInfo ( void ) ;
#endif
