#include "ext_types.h"
static DataTypeInfo rtDataTypeInfoTable [ ] = { { "real_T" , 0 , 8 } , {
"real32_T" , 1 , 4 } , { "int8_T" , 2 , 1 } , { "uint8_T" , 3 , 1 } , {
"int16_T" , 4 , 2 } , { "uint16_T" , 5 , 2 } , { "int32_T" , 6 , 4 } , {
"uint32_T" , 7 , 4 } , { "boolean_T" , 8 , 1 } , { "fcn_call_T" , 9 , 0 } , {
"int_T" , 10 , 4 } , { "pointer_T" , 11 , 8 } , { "action_T" , 12 , 8 } , {
"timer_uint32_pair_T" , 13 , 8 } , { "physical_connection" , 14 , 8 } , {
"int64_T" , 15 , 8 } , { "uint64_T" , 16 , 8 } , { "uint64_T" , 17 , 8 } , {
"int64_T" , 18 , 8 } , { "uint_T" , 19 , 32 } , { "char_T" , 20 , 8 } , {
"uchar_T" , 21 , 8 } , { "time_T" , 22 , 8 } } ; static uint_T
rtDataTypeSizes [ ] = { sizeof ( real_T ) , sizeof ( real32_T ) , sizeof (
int8_T ) , sizeof ( uint8_T ) , sizeof ( int16_T ) , sizeof ( uint16_T ) ,
sizeof ( int32_T ) , sizeof ( uint32_T ) , sizeof ( boolean_T ) , sizeof (
fcn_call_T ) , sizeof ( int_T ) , sizeof ( pointer_T ) , sizeof ( action_T )
, 2 * sizeof ( uint32_T ) , sizeof ( int32_T ) , sizeof ( int64_T ) , sizeof
( uint64_T ) , sizeof ( uint64_T ) , sizeof ( int64_T ) , sizeof ( uint_T ) ,
sizeof ( char_T ) , sizeof ( uchar_T ) , sizeof ( time_T ) } ; static const
char_T * rtDataTypeNames [ ] = { "real_T" , "real32_T" , "int8_T" , "uint8_T"
, "int16_T" , "uint16_T" , "int32_T" , "uint32_T" , "boolean_T" ,
"fcn_call_T" , "int_T" , "pointer_T" , "action_T" , "timer_uint32_pair_T" ,
"physical_connection" , "int64_T" , "uint64_T" , "uint64_T" , "int64_T" ,
"uint_T" , "char_T" , "uchar_T" , "time_T" } ; static DataTypeTransition
rtBTransitions [ ] = { { ( char_T * ) ( & rtB . bano4r405l ) , 0 , 0 , 83 } ,
{ ( char_T * ) ( & rtB . gnzysggnk4 ) , 8 , 0 , 14 } , { ( char_T * ) ( & rtB
. e5i1gkys053 . nyju2jnyn3 ) , 0 , 0 , 1 } , { ( char_T * ) ( & rtB .
o0l0tlmums2 . ebzcxl42h5 ) , 0 , 0 , 1 } , { ( char_T * ) ( & rtB .
lsul0j3thv5 . nzhrh1tkt0 ) , 0 , 0 , 1 } , { ( char_T * ) ( & rtB .
lvdmxslirzu . ppbrf42mvn ) , 0 , 0 , 1 } , { ( char_T * ) ( & rtDW .
mz0zdu34tn ) , 0 , 0 , 22 } , { ( char_T * ) ( & rtDW . odihpq11te .
AQHandles ) , 11 , 0 , 64 } , { ( char_T * ) ( & rtDW . dx0psck2g2 ) , 6 , 0
, 2 } , { ( char_T * ) ( & rtDW . bmwah53if2 ) , 7 , 0 , 651 } , { ( char_T *
) ( & rtDW . f4gzzk1cad . PrevIndex ) , 10 , 0 , 3 } , { ( char_T * ) ( &
rtDW . csce1vtaiv ) , 5 , 0 , 1 } , { ( char_T * ) ( & rtDW . i3eqa0qza0 ) ,
8 , 0 , 3 } , { ( char_T * ) ( & rtDW . jraid5zlrs ) , 3 , 0 , 6 } , { (
char_T * ) ( & rtDW . b0xpqic30u ) , 8 , 0 , 8 } , { ( char_T * ) ( & rtDW .
e5i1gkys053 . iaiukld4k4 ) , 2 , 0 , 1 } , { ( char_T * ) ( & rtDW .
o0l0tlmums2 . nmoh1fygpu ) , 2 , 0 , 1 } , { ( char_T * ) ( & rtDW .
lsul0j3thv5 . b0jtmkqrl5 ) , 2 , 0 , 1 } , { ( char_T * ) ( & rtDW .
lvdmxslirzu . ec3xwiqauu ) , 2 , 0 , 1 } } ; static DataTypeTransitionTable
rtBTransTable = { 19U , rtBTransitions } ; static DataTypeTransition
rtPTransitions [ ] = { { ( char_T * ) ( & rtP . mfile_P2_Size [ 0 ] ) , 0 , 0
, 20155 } , { ( char_T * ) ( & rtP . UnitDelay9_InitialCondition ) , 8 , 0 ,
3 } , { ( char_T * ) ( & rtP . ConsiderFault1_CurrentSetting ) , 3 , 0 , 3 }
, { ( char_T * ) ( & rtP . e5i1gkys053 . Out1_Y0 ) , 0 , 0 , 4 } , { ( char_T
* ) ( & rtP . o0l0tlmums2 . Out1_Y0 ) , 0 , 0 , 4 } , { ( char_T * ) ( & rtP
. lsul0j3thv5 . Out1_Y0 ) , 0 , 0 , 4 } , { ( char_T * ) ( & rtP .
lvdmxslirzu . Out1_Y0 ) , 0 , 0 , 4 } } ; static DataTypeTransitionTable
rtPTransTable = { 7U , rtPTransitions } ;
