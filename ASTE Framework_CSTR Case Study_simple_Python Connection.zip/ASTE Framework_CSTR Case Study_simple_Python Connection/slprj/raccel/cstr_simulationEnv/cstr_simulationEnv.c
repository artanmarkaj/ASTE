#include "cstr_simulationEnv.h"
#include "rtwtypes.h"
#include "cstr_simulationEnv_private.h"
#include "mwmathutil.h"
#include <string.h>
#include <time.h>
#include <stddef.h>
#include "rt_logging_mmi.h"
#include "cstr_simulationEnv_capi.h"
#include "cstr_simulationEnv_dt.h"
#include "sfcn_loader_c_api.h"
extern void * CreateDiagnosticAsVoidPtr_wrapper ( const char * id , int nargs
, ... ) ; RTWExtModeInfo * gblRTWExtModeInfo = NULL ; void
raccelForceExtModeShutdown ( boolean_T extModeStartPktReceived ) { if ( !
extModeStartPktReceived ) { boolean_T stopRequested = false ;
rtExtModeWaitForStartPkt ( gblRTWExtModeInfo , 4 , & stopRequested ) ; }
rtExtModeShutdown ( 4 ) ; }
#include "slsv_diagnostic_codegen_c_api.h"
#include "slsa_sim_engine.h"
const int_T gblNumToFiles = 1 ; const int_T gblNumFrFiles = 0 ; const int_T
gblNumFrWksBlocks = 2 ;
#ifdef RSIM_WITH_SOLVER_MULTITASKING
boolean_T gbl_raccel_isMultitasking = 1 ;
#else
boolean_T gbl_raccel_isMultitasking = 0 ;
#endif
boolean_T gbl_raccel_tid01eq = 1 ; int_T gbl_raccel_NumST = 5 ; const char_T
* gbl_raccel_Version = "10.6 (R2022b) 13-May-2022" ; void
raccel_setup_MMIStateLog ( SimStruct * S ) {
#ifdef UseMMIDataLogging
rt_FillStateSigInfoFromMMI ( ssGetRTWLogInfo ( S ) , & ssGetErrorStatus ( S )
) ;
#else
UNUSED_PARAMETER ( S ) ;
#endif
} static DataMapInfo rt_dataMapInfo ; DataMapInfo * rt_dataMapInfoPtr = &
rt_dataMapInfo ; rtwCAPI_ModelMappingInfo * rt_modelMapInfoPtr = & (
rt_dataMapInfo . mmi ) ; const int_T gblNumRootInportBlks = 0 ; const int_T
gblNumModelInputs = 0 ; extern const char * gblInportFileName ; extern
rtInportTUtable * gblInportTUtables ; const int_T gblInportDataTypeIdx [ ] =
{ - 1 } ; const int_T gblInportDims [ ] = { - 1 } ; const int_T
gblInportComplex [ ] = { - 1 } ; const int_T gblInportInterpoFlag [ ] = { - 1
} ; const int_T gblInportContinuous [ ] = { - 1 } ; int_T enableFcnCallFlag [
] = { 1 , 1 , 1 , 1 , 1 } ; const char * raccelLoadInputsAndAperiodicHitTimes
( SimStruct * S , const char * inportFileName , int * matFileFormat ) {
return rt_RAccelReadInportsMatFile ( S , inportFileName , matFileFormat ) ; }
#include "simstruc.h"
#include "fixedpoint.h"
#include "slsa_sim_engine.h"
#include "simtarget/slSimTgtSLExecSimBridge.h"
#define bpmqxywv4s (6U)
#define dqjw2epu13 (4U)
#define ecuq3htc1w (2U)
#define fu5ii0d3lp (5U)
#define ggkjqvtxz1 (4U)
#define h1zo3wxret (2U)
#define hn1hwvtdtn (6U)
#define i00hab4fzi (4U)
#define jh4s05c31l (-1)
#define kluzj30pzp ((uint8_T)0U)
#define l4sas1urex (1U)
#define lgpwfbpmih (2U)
#define mp40lbzaqx (3U)
#define njrbss2svy (3U)
#define nyrhxonrdt (1U)
#define o2nxiy3ufc (3U)
#define p5vaeqbl3t (2U)
#define pnztcweof2 (1U)
#define aodw1v54cb (1U)
#define arhac2lfsx (6U)
#define cjeyefob4c (4U)
#define cjniwsoxiu (1U)
#define djp1q2gbzd (2U)
#define dzcgoxakfb (3U)
#define enqrwwow5y (1U)
#define grkerkr1hy (1U)
#define if0vy5gd2y (2U)
#define jic5t24gfv (5U)
#define mfbquags3t (2U)
#define muyrihtp2b (4U)
#define osk10zz3aw (3U)
B rtB ; X rtX ; DW rtDW ; static SimStruct model_S ; SimStruct * const rtS =
& model_S ; static real_T ns33m02cgf ( void ) ; static real_T cjjy1b2srh (
real_T x ) ; static real_T pswrm4g13c ( void ) ; static real_T gesahh5glk (
void ) ; void euommxokvy ( mwig44svkj * localB , ew3azour0i * localP ) {
localB -> ppbrf42mvn = localP -> Out1_Y0 ; } void lvdmxslirz ( real_T
puydwci5lo , mwig44svkj * localB , jumuk3fap1 * localDW , ew3azour0i * localP
) { real_T u0 ; u0 = puydwci5lo + localP -> Constant_Value ; if ( u0 > localP
-> Saturation_UpperSat ) { localB -> ppbrf42mvn = localP ->
Saturation_UpperSat ; } else if ( u0 < localP -> Saturation_LowerSat ) {
localB -> ppbrf42mvn = localP -> Saturation_LowerSat ; } else { localB ->
ppbrf42mvn = u0 ; } localDW -> ec3xwiqauu = 4 ; } void dnd2bzvthx (
l0lgrgqbys * localB , gecy0xyg43 * localP ) { localB -> nzhrh1tkt0 = localP
-> Out1_Y0 ; } void lsul0j3thv ( real_T hshllgsvvq , l0lgrgqbys * localB ,
o2f542nfiy * localDW , gecy0xyg43 * localP ) { real_T u0 ; u0 = hshllgsvvq +
localP -> Constant_Value ; if ( u0 > localP -> Saturation_UpperSat ) { localB
-> nzhrh1tkt0 = localP -> Saturation_UpperSat ; } else if ( u0 < localP ->
Saturation_LowerSat ) { localB -> nzhrh1tkt0 = localP -> Saturation_LowerSat
; } else { localB -> nzhrh1tkt0 = u0 ; } localDW -> b0jtmkqrl5 = 4 ; } void
b2ou3bzaum ( dunstow1lc * localB , n2j2mlro55 * localP ) { localB ->
ebzcxl42h5 = localP -> Out1_Y0 ; } void o0l0tlmums ( real_T hbjpklwfg3 ,
dunstow1lc * localB , arhl1fqxuk * localDW , n2j2mlro55 * localP ) { real_T
u0 ; u0 = hbjpklwfg3 - localP -> Constant_Value ; if ( u0 > localP ->
Saturation_UpperSat ) { localB -> ebzcxl42h5 = localP -> Saturation_UpperSat
; } else if ( u0 < localP -> Saturation_LowerSat ) { localB -> ebzcxl42h5 =
localP -> Saturation_LowerSat ; } else { localB -> ebzcxl42h5 = u0 ; }
localDW -> nmoh1fygpu = 4 ; } void cbl0gm11na ( eoztiauie0 * localB ,
krn1dj51s1 * localP ) { localB -> nyju2jnyn3 = localP -> Out1_Y0 ; } void
e5i1gkys05 ( real_T azbafjvsk2 , eoztiauie0 * localB , hzamdoniux * localDW ,
krn1dj51s1 * localP ) { real_T u0 ; u0 = azbafjvsk2 - localP ->
Constant_Value ; if ( u0 > localP -> Saturation_UpperSat ) { localB ->
nyju2jnyn3 = localP -> Saturation_UpperSat ; } else if ( u0 < localP ->
Saturation_LowerSat ) { localB -> nyju2jnyn3 = localP -> Saturation_LowerSat
; } else { localB -> nyju2jnyn3 = u0 ; } localDW -> iaiukld4k4 = 4 ; } real_T
rt_urand_Upu32_Yd_f_pw_snf ( uint32_T * u ) { uint32_T hi ; uint32_T lo ; lo
= * u % 127773U * 16807U ; hi = * u / 127773U * 2836U ; if ( lo < hi ) { * u
= 2147483647U - ( hi - lo ) ; } else { * u = lo - hi ; } return ( real_T ) *
u * 4.6566128752457969E-10 ; } static real_T ns33m02cgf ( void ) { time_t
rawtime ; struct tm expl_temp ; real_T dDateNum ; int32_T r ; int16_T
cDaysMonthWise [ 12 ] ; boolean_T guard1 = false ; cDaysMonthWise [ 0 ] = 0 ;
cDaysMonthWise [ 1 ] = 31 ; cDaysMonthWise [ 2 ] = 59 ; cDaysMonthWise [ 3 ]
= 90 ; cDaysMonthWise [ 4 ] = 120 ; cDaysMonthWise [ 5 ] = 151 ;
cDaysMonthWise [ 6 ] = 181 ; cDaysMonthWise [ 7 ] = 212 ; cDaysMonthWise [ 8
] = 243 ; cDaysMonthWise [ 9 ] = 273 ; cDaysMonthWise [ 10 ] = 304 ;
cDaysMonthWise [ 11 ] = 334 ; time ( & rawtime ) ; expl_temp = * localtime (
& rawtime ) ; dDateNum = ( ( ( ( ( real_T ) ( expl_temp . tm_year + 1900 ) *
365.0 + muDoubleScalarCeil ( ( real_T ) ( expl_temp . tm_year + 1900 ) / 4.0
) ) - muDoubleScalarCeil ( ( real_T ) ( expl_temp . tm_year + 1900 ) / 100.0
) ) + muDoubleScalarCeil ( ( real_T ) ( expl_temp . tm_year + 1900 ) / 400.0
) ) + ( real_T ) cDaysMonthWise [ expl_temp . tm_mon ] ) + ( real_T )
expl_temp . tm_mday ; if ( expl_temp . tm_mon + 1 > 2 ) { if ( expl_temp .
tm_year + 1900 == 0 ) { r = 0 ; } else { r = ( int32_T ) muDoubleScalarRem (
expl_temp . tm_year + 1900 , 4.0 ) ; if ( ( r != 0 ) && ( expl_temp . tm_year
+ 1900 < 0 ) ) { r += 4 ; } } guard1 = false ; if ( r == 0 ) { if ( expl_temp
. tm_year + 1900 != 0 ) { r = ( int32_T ) muDoubleScalarRem ( expl_temp .
tm_year + 1900 , 100.0 ) ; if ( ( r != 0 ) && ( expl_temp . tm_year + 1900 <
0 ) ) { r += 100 ; } } if ( r != 0 ) { dDateNum ++ ; } else { guard1 = true ;
} } else { guard1 = true ; } if ( guard1 ) { if ( expl_temp . tm_year + 1900
== 0 ) { r = 0 ; } else { r = ( int32_T ) muDoubleScalarRem ( expl_temp .
tm_year + 1900 , 400.0 ) ; if ( ( r != 0 ) && ( expl_temp . tm_year + 1900 <
0 ) ) { r += 400 ; } } if ( r == 0 ) { dDateNum ++ ; } } } return ( ( (
real_T ) expl_temp . tm_hour * 3600.0 + ( real_T ) expl_temp . tm_min * 60.0
) + ( real_T ) expl_temp . tm_sec ) / 86400.0 + dDateNum ; } static real_T
cjjy1b2srh ( real_T x ) { real_T r ; if ( muDoubleScalarIsNaN ( x ) ||
muDoubleScalarIsInf ( x ) ) { r = ( rtNaN ) ; } else if ( x == 0.0 ) { r =
0.0 ; } else { r = muDoubleScalarRem ( x , 2.147483647E+9 ) ; if ( r == 0.0 )
{ r = 0.0 ; } else if ( x < 0.0 ) { r += 2.147483647E+9 ; } } return r ; }
static real_T pswrm4g13c ( void ) { real_T r ; int32_T hi ; int32_T kk ;
uint32_T u [ 2 ] ; uint32_T mti ; uint32_T y ; if ( rtDW . en0wsgm2d2 == 4U )
{ hi = ( int32_T ) ( rtDW . m5g4cvi2wi / 127773U ) ; mti = ( rtDW .
m5g4cvi2wi - ( uint32_T ) hi * 127773U ) * 16807U ; y = 2836U * ( uint32_T )
hi ; if ( mti < y ) { mti = ~ ( y - mti ) & 2147483647U ; } else { mti -= y ;
} r = ( real_T ) mti * 4.6566128752457969E-10 ; rtDW . m5g4cvi2wi = mti ; }
else if ( rtDW . en0wsgm2d2 == 5U ) { mti = 69069U * rtDW . kf3zpzee4j [ 0 ]
+ 1234567U ; y = rtDW . kf3zpzee4j [ 1 ] << 13 ^ rtDW . kf3zpzee4j [ 1 ] ; y
^= y >> 17 ; y ^= y << 5 ; rtDW . kf3zpzee4j [ 0 ] = mti ; rtDW . kf3zpzee4j
[ 1 ] = y ; r = ( real_T ) ( mti + y ) * 2.328306436538696E-10 ; } else { do
{ for ( hi = 0 ; hi < 2 ; hi ++ ) { mti = rtDW . htl3ck05k3 [ 624 ] + 1U ; if
( rtDW . htl3ck05k3 [ 624 ] + 1U >= 625U ) { for ( kk = 0 ; kk < 227 ; kk ++
) { mti = ( rtDW . htl3ck05k3 [ kk + 1 ] & 2147483647U ) | ( rtDW .
htl3ck05k3 [ kk ] & 2147483648U ) ; if ( ( mti & 1U ) == 0U ) { mti >>= 1U ;
} else { mti = mti >> 1U ^ 2567483615U ; } rtDW . htl3ck05k3 [ kk ] = rtDW .
htl3ck05k3 [ kk + 397 ] ^ mti ; } for ( kk = 0 ; kk < 396 ; kk ++ ) { mti = (
rtDW . htl3ck05k3 [ kk + 227 ] & 2147483648U ) | ( rtDW . htl3ck05k3 [ kk +
228 ] & 2147483647U ) ; if ( ( mti & 1U ) == 0U ) { mti >>= 1U ; } else { mti
= mti >> 1U ^ 2567483615U ; } rtDW . htl3ck05k3 [ kk + 227 ] = rtDW .
htl3ck05k3 [ kk ] ^ mti ; } mti = ( rtDW . htl3ck05k3 [ 623 ] & 2147483648U )
| ( rtDW . htl3ck05k3 [ 0 ] & 2147483647U ) ; if ( ( mti & 1U ) == 0U ) { mti
>>= 1U ; } else { mti = mti >> 1U ^ 2567483615U ; } rtDW . htl3ck05k3 [ 623 ]
= rtDW . htl3ck05k3 [ 396 ] ^ mti ; mti = 1U ; } y = rtDW . htl3ck05k3 [ (
int32_T ) mti - 1 ] ; rtDW . htl3ck05k3 [ 624 ] = mti ; y ^= y >> 11U ; y ^=
y << 7U & 2636928640U ; y ^= y << 15U & 4022730752U ; u [ hi ] = y >> 18U ^ y
; } r = ( ( real_T ) ( u [ 0 ] >> 5U ) * 6.7108864E+7 + ( real_T ) ( u [ 1 ]
>> 6U ) ) * 1.1102230246251565E-16 ; } while ( r == 0.0 ) ; } return r ; }
static real_T gesahh5glk ( void ) { time_t b_eTime ; time_t eTime ; real_T
b_x ; real_T x ; int32_T b_r ; int32_T exitg1 ; int32_T t ; uint32_T r ; x =
ns33m02cgf ( ) * 8.64E+6 ; x = muDoubleScalarFloor ( x ) ; x = cjjy1b2srh ( x
) ; eTime = time ( NULL ) ; do { exitg1 = 0 ; b_eTime = time ( NULL ) ; if (
( int32_T ) b_eTime <= ( int32_T ) eTime + 1 ) { b_x = ns33m02cgf ( ) *
8.64E+6 ; b_x = muDoubleScalarFloor ( b_x ) ; if ( x != cjjy1b2srh ( b_x ) )
{ exitg1 = 1 ; } } else { exitg1 = 1 ; } } while ( exitg1 == 0 ) ; x =
muDoubleScalarRound ( x ) ; if ( x < 4.294967296E+9 ) { if ( x >= 0.0 ) {
rtDW . j4xo2d0p0j = ( uint32_T ) x ; } else { rtDW . j4xo2d0p0j = 0U ; } }
else if ( x >= 4.294967296E+9 ) { rtDW . j4xo2d0p0j = MAX_uint32_T ; } else {
rtDW . j4xo2d0p0j = 0U ; } if ( rtDW . en0wsgm2d2 == 7U ) { r = rtDW .
j4xo2d0p0j ; rtDW . htl3ck05k3 [ 0 ] = rtDW . j4xo2d0p0j ; for ( b_r = 0 ;
b_r < 623 ; b_r ++ ) { r = ( ( r >> 30U ^ r ) * 1812433253U + ( uint32_T )
b_r ) + 1U ; rtDW . htl3ck05k3 [ b_r + 1 ] = r ; } rtDW . htl3ck05k3 [ 624 ]
= 624U ; } else if ( rtDW . en0wsgm2d2 == 5U ) { rtDW . kf3zpzee4j [ 0 ] =
362436069U ; rtDW . kf3zpzee4j [ 1 ] = rtDW . j4xo2d0p0j ; if ( rtDW .
kf3zpzee4j [ 1 ] == 0U ) { rtDW . kf3zpzee4j [ 1 ] = 521288629U ; } } else if
( rtDW . en0wsgm2d2 == 4U ) { b_r = ( int32_T ) ( rtDW . j4xo2d0p0j >> 16U )
; t = ( int32_T ) ( rtDW . j4xo2d0p0j & 32768U ) ; r = ( ( ( ( rtDW .
j4xo2d0p0j - ( ( uint32_T ) b_r << 16U ) ) - ( uint32_T ) t ) << 16U ) + (
uint32_T ) t ) + ( uint32_T ) b_r ; if ( r < 1U ) { r = 1144108930U ; } else
if ( r > 2147483646U ) { r = 2147483646U ; } rtDW . m5g4cvi2wi = r ; } return
pswrm4g13c ( ) ; } void MdlInitialize ( void ) { real_T tmp ; int32_T i ;
int32_T t ; uint32_T tseed ; static const uint32_T tmp_p [ 625 ] = { 5489U ,
1301868182U , 2938499221U , 2950281878U , 1875628136U , 751856242U ,
944701696U , 2243192071U , 694061057U , 219885934U , 2066767472U ,
3182869408U , 485472502U , 2336857883U , 1071588843U , 3418470598U ,
951210697U , 3693558366U , 2923482051U , 1793174584U , 2982310801U ,
1586906132U , 1951078751U , 1808158765U , 1733897588U , 431328322U ,
4202539044U , 530658942U , 1714810322U , 3025256284U , 3342585396U ,
1937033938U , 2640572511U , 1654299090U , 3692403553U , 4233871309U ,
3497650794U , 862629010U , 2943236032U , 2426458545U , 1603307207U ,
1133453895U , 3099196360U , 2208657629U , 2747653927U , 931059398U ,
761573964U , 3157853227U , 785880413U , 730313442U , 124945756U , 2937117055U
, 3295982469U , 1724353043U , 3021675344U , 3884886417U , 4010150098U ,
4056961966U , 699635835U , 2681338818U , 1339167484U , 720757518U ,
2800161476U , 2376097373U , 1532957371U , 3902664099U , 1238982754U ,
3725394514U , 3449176889U , 3570962471U , 4287636090U , 4087307012U ,
3603343627U , 202242161U , 2995682783U , 1620962684U , 3704723357U ,
371613603U , 2814834333U , 2111005706U , 624778151U , 2094172212U ,
4284947003U , 1211977835U , 991917094U , 1570449747U , 2962370480U ,
1259410321U , 170182696U , 146300961U , 2836829791U , 619452428U ,
2723670296U , 1881399711U , 1161269684U , 1675188680U , 4132175277U ,
780088327U , 3409462821U , 1036518241U , 1834958505U , 3048448173U ,
161811569U , 618488316U , 44795092U , 3918322701U , 1924681712U , 3239478144U
, 383254043U , 4042306580U , 2146983041U , 3992780527U , 3518029708U ,
3545545436U , 3901231469U , 1896136409U , 2028528556U , 2339662006U ,
501326714U , 2060962201U , 2502746480U , 561575027U , 581893337U ,
3393774360U , 1778912547U , 3626131687U , 2175155826U , 319853231U ,
986875531U , 819755096U , 2915734330U , 2688355739U , 3482074849U , 2736559U
, 2296975761U , 1029741190U , 2876812646U , 690154749U , 579200347U ,
4027461746U , 1285330465U , 2701024045U , 4117700889U , 759495121U ,
3332270341U , 2313004527U , 2277067795U , 4131855432U , 2722057515U ,
1264804546U , 3848622725U , 2211267957U , 4100593547U , 959123777U ,
2130745407U , 3194437393U , 486673947U , 1377371204U , 17472727U , 352317554U
, 3955548058U , 159652094U , 1232063192U , 3835177280U , 49423123U ,
3083993636U , 733092U , 2120519771U , 2573409834U , 1112952433U , 3239502554U
, 761045320U , 1087580692U , 2540165110U , 641058802U , 1792435497U ,
2261799288U , 1579184083U , 627146892U , 2165744623U , 2200142389U ,
2167590760U , 2381418376U , 1793358889U , 3081659520U , 1663384067U ,
2009658756U , 2689600308U , 739136266U , 2304581039U , 3529067263U ,
591360555U , 525209271U , 3131882996U , 294230224U , 2076220115U ,
3113580446U , 1245621585U , 1386885462U , 3203270426U , 123512128U ,
12350217U , 354956375U , 4282398238U , 3356876605U , 3888857667U , 157639694U
, 2616064085U , 1563068963U , 2762125883U , 4045394511U , 4180452559U ,
3294769488U , 1684529556U , 1002945951U , 3181438866U , 22506664U ,
691783457U , 2685221343U , 171579916U , 3878728600U , 2475806724U ,
2030324028U , 3331164912U , 1708711359U , 1970023127U , 2859691344U ,
2588476477U , 2748146879U , 136111222U , 2967685492U , 909517429U ,
2835297809U , 3206906216U , 3186870716U , 341264097U , 2542035121U ,
3353277068U , 548223577U , 3170936588U , 1678403446U , 297435620U ,
2337555430U , 466603495U , 1132321815U , 1208589219U , 696392160U ,
894244439U , 2562678859U , 470224582U , 3306867480U , 201364898U ,
2075966438U , 1767227936U , 2929737987U , 3674877796U , 2654196643U ,
3692734598U , 3528895099U , 2796780123U , 3048728353U , 842329300U ,
191554730U , 2922459673U , 3489020079U , 3979110629U , 1022523848U ,
2202932467U , 3583655201U , 3565113719U , 587085778U , 4176046313U ,
3013713762U , 950944241U , 396426791U , 3784844662U , 3477431613U ,
3594592395U , 2782043838U , 3392093507U , 3106564952U , 2829419931U ,
1358665591U , 2206918825U , 3170783123U , 31522386U , 2988194168U ,
1782249537U , 1105080928U , 843500134U , 1225290080U , 1521001832U ,
3605886097U , 2802786495U , 2728923319U , 3996284304U , 903417639U ,
1171249804U , 1020374987U , 2824535874U , 423621996U , 1988534473U ,
2493544470U , 1008604435U , 1756003503U , 1488867287U , 1386808992U ,
732088248U , 1780630732U , 2482101014U , 976561178U , 1543448953U ,
2602866064U , 2021139923U , 1952599828U , 2360242564U , 2117959962U ,
2753061860U , 2388623612U , 4138193781U , 2962920654U , 2284970429U ,
766920861U , 3457264692U , 2879611383U , 815055854U , 2332929068U ,
1254853997U , 3740375268U , 3799380844U , 4091048725U , 2006331129U ,
1982546212U , 686850534U , 1907447564U , 2682801776U , 2780821066U ,
998290361U , 1342433871U , 4195430425U , 607905174U , 3902331779U ,
2454067926U , 1708133115U , 1170874362U , 2008609376U , 3260320415U ,
2211196135U , 433538229U , 2728786374U , 2189520818U , 262554063U ,
1182318347U , 3710237267U , 1221022450U , 715966018U , 2417068910U ,
2591870721U , 2870691989U , 3418190842U , 4238214053U , 1540704231U ,
1575580968U , 2095917976U , 4078310857U , 2313532447U , 2110690783U ,
4056346629U , 4061784526U , 1123218514U , 551538993U , 597148360U ,
4120175196U , 3581618160U , 3181170517U , 422862282U , 3227524138U ,
1713114790U , 662317149U , 1230418732U , 928171837U , 1324564878U ,
1928816105U , 1786535431U , 2878099422U , 3290185549U , 539474248U ,
1657512683U , 552370646U , 1671741683U , 3655312128U , 1552739510U ,
2605208763U , 1441755014U , 181878989U , 3124053868U , 1447103986U ,
3183906156U , 1728556020U , 3502241336U , 3055466967U , 1013272474U ,
818402132U , 1715099063U , 2900113506U , 397254517U , 4194863039U ,
1009068739U , 232864647U , 2540223708U , 2608288560U , 2415367765U ,
478404847U , 3455100648U , 3182600021U , 2115988978U , 434269567U ,
4117179324U , 3461774077U , 887256537U , 3545801025U , 286388911U ,
3451742129U , 1981164769U , 786667016U , 3310123729U , 3097811076U ,
2224235657U , 2959658883U , 3370969234U , 2514770915U , 3345656436U ,
2677010851U , 2206236470U , 271648054U , 2342188545U , 4292848611U ,
3646533909U , 3754009956U , 3803931226U , 4160647125U , 1477814055U ,
4043852216U , 1876372354U , 3133294443U , 3871104810U , 3177020907U ,
2074304428U , 3479393793U , 759562891U , 164128153U , 1839069216U ,
2114162633U , 3989947309U , 3611054956U , 1333547922U , 835429831U ,
494987340U , 171987910U , 1252001001U , 370809172U , 3508925425U ,
2535703112U , 1276855041U , 1922855120U , 835673414U , 3030664304U ,
613287117U , 171219893U , 3423096126U , 3376881639U , 2287770315U ,
1658692645U , 1262815245U , 3957234326U , 1168096164U , 2968737525U ,
2655813712U , 2132313144U , 3976047964U , 326516571U , 353088456U ,
3679188938U , 3205649712U , 2654036126U , 1249024881U , 880166166U ,
691800469U , 2229503665U , 1673458056U , 4032208375U , 1851778863U ,
2563757330U , 376742205U , 1794655231U , 340247333U , 1505873033U ,
396524441U , 879666767U , 3335579166U , 3260764261U , 3335999539U ,
506221798U , 4214658741U , 975887814U , 2080536343U , 3360539560U ,
571586418U , 138896374U , 4234352651U , 2737620262U , 3928362291U ,
1516365296U , 38056726U , 3599462320U , 3585007266U , 3850961033U ,
471667319U , 1536883193U , 2310166751U , 1861637689U , 2530999841U ,
4139843801U , 2710569485U , 827578615U , 2012334720U , 2907369459U ,
3029312804U , 2820112398U , 1965028045U , 35518606U , 2478379033U ,
643747771U , 1924139484U , 4123405127U , 3811735531U , 3429660832U ,
3285177704U , 1948416081U , 1311525291U , 1183517742U , 1739192232U ,
3979815115U , 2567840007U , 4116821529U , 213304419U , 4125718577U ,
1473064925U , 2442436592U , 1893310111U , 4195361916U , 3747569474U ,
828465101U , 2991227658U , 750582866U , 1205170309U , 1409813056U ,
678418130U , 1171531016U , 3821236156U , 354504587U , 4202874632U ,
3882511497U , 1893248677U , 1903078632U , 26340130U , 2069166240U ,
3657122492U , 3725758099U , 831344905U , 811453383U , 3447711422U ,
2434543565U , 4166886888U , 3358210805U , 4142984013U , 2988152326U ,
3527824853U , 982082992U , 2809155763U , 190157081U , 3340214818U ,
2365432395U , 2548636180U , 2894533366U , 3474657421U , 2372634704U ,
2845748389U , 43024175U , 2774226648U , 1987702864U , 3186502468U ,
453610222U , 4204736567U , 1392892630U , 2471323686U , 2470534280U ,
3541393095U , 4269885866U , 3909911300U , 759132955U , 1482612480U ,
667715263U , 1795580598U , 2337923983U , 3390586366U , 581426223U ,
1515718634U , 476374295U , 705213300U , 363062054U , 2084697697U ,
2407503428U , 2292957699U , 2426213835U , 2199989172U , 1987356470U ,
4026755612U , 2147252133U , 270400031U , 1367820199U , 2369854699U ,
2844269403U , 79981964U , 624U } ; tmp = muDoubleScalarFloor ( rtP .
UniformRandomNumber2_Seed ) ; if ( muDoubleScalarIsNaN ( tmp ) ||
muDoubleScalarIsInf ( tmp ) ) { tmp = 0.0 ; } else { tmp = muDoubleScalarRem
( tmp , 4.294967296E+9 ) ; } tseed = tmp < 0.0 ? ( uint32_T ) - ( int32_T ) (
uint32_T ) - tmp : ( uint32_T ) tmp ; i = ( int32_T ) ( tseed >> 16U ) ; t =
( int32_T ) ( tseed & 32768U ) ; tseed = ( ( ( ( tseed - ( ( uint32_T ) i <<
16U ) ) + ( uint32_T ) t ) << 16U ) + ( uint32_T ) t ) + ( uint32_T ) i ; if
( tseed < 1U ) { tseed = 1144108930U ; } else if ( tseed > 2147483646U ) {
tseed = 2147483646U ; } rtDW . bmwah53if2 = tseed ; rtDW . bv534fxrfq = ( rtP
. UniformRandomNumber2_Maximum - rtP . UniformRandomNumber2_Minimum ) *
rt_urand_Upu32_Yd_f_pw_snf ( & rtDW . bmwah53if2 ) + rtP .
UniformRandomNumber2_Minimum ; rtDW . i3eqa0qza0 = rtP .
UnitDelay9_InitialCondition ; rtDW . fudylxbq0j = rtP .
Memory_InitialCondition ; tmp = muDoubleScalarFloor ( rtP .
UniformRandomNumber10_Seed ) ; if ( muDoubleScalarIsNaN ( tmp ) ||
muDoubleScalarIsInf ( tmp ) ) { tmp = 0.0 ; } else { tmp = muDoubleScalarRem
( tmp , 4.294967296E+9 ) ; } tseed = tmp < 0.0 ? ( uint32_T ) - ( int32_T ) (
uint32_T ) - tmp : ( uint32_T ) tmp ; i = ( int32_T ) ( tseed >> 16U ) ; t =
( int32_T ) ( tseed & 32768U ) ; tseed = ( ( ( ( tseed - ( ( uint32_T ) i <<
16U ) ) + ( uint32_T ) t ) << 16U ) + ( uint32_T ) t ) + ( uint32_T ) i ; if
( tseed < 1U ) { tseed = 1144108930U ; } else if ( tseed > 2147483646U ) {
tseed = 2147483646U ; } rtDW . lustmxh0ru = tseed ; rtDW . bgotvck1y4 = ( rtP
. UniformRandomNumber10_Maximum - rtP . UniformRandomNumber10_Minimum ) *
rt_urand_Upu32_Yd_f_pw_snf ( & rtDW . lustmxh0ru ) + rtP .
UniformRandomNumber10_Minimum ; rtDW . agio50d4gu = rtP .
UnitDelay10_InitialCondition ; rtDW . dfulppyfs1 = rtP .
Memory10_InitialCondition ; tmp = muDoubleScalarFloor ( rtP .
UniformRandomNumber6_Seed ) ; if ( muDoubleScalarIsNaN ( tmp ) ||
muDoubleScalarIsInf ( tmp ) ) { tmp = 0.0 ; } else { tmp = muDoubleScalarRem
( tmp , 4.294967296E+9 ) ; } tseed = tmp < 0.0 ? ( uint32_T ) - ( int32_T ) (
uint32_T ) - tmp : ( uint32_T ) tmp ; i = ( int32_T ) ( tseed >> 16U ) ; t =
( int32_T ) ( tseed & 32768U ) ; tseed = ( ( ( ( tseed - ( ( uint32_T ) i <<
16U ) ) + ( uint32_T ) t ) << 16U ) + ( uint32_T ) t ) + ( uint32_T ) i ; if
( tseed < 1U ) { tseed = 1144108930U ; } else if ( tseed > 2147483646U ) {
tseed = 2147483646U ; } rtDW . o5vdryefj2 = tseed ; rtDW . o0jhm5tqhv = ( rtP
. UniformRandomNumber6_Maximum - rtP . UniformRandomNumber6_Minimum ) *
rt_urand_Upu32_Yd_f_pw_snf ( & rtDW . o5vdryefj2 ) + rtP .
UniformRandomNumber6_Minimum ; rtDW . g10sbzotef = rtP .
UnitDelay11_InitialCondition ; rtDW . gymfbya0lf = rtP .
Memory6_InitialCondition ; rtDW . mz0zdu34tn = rtP .
UnitDelay8_InitialCondition ; rtDW . cronjwvq3j = rtP .
UnitDelay1_InitialCondition ; rtDW . dsnlclvjlf = rtP .
UnitDelay2_InitialCondition ; rtDW . nfi0353erc = rtP .
UnitDelay6_InitialCondition ; rtDW . g5guutg2r4 = rtP .
UnitDelay7_InitialCondition ; rtDW . iecjfocdpt = rtP .
UnitDelay6_InitialCondition_m0rhsscivj ; tmp = muDoubleScalarFloor ( rtP .
UniformRandomNumber5_Seed ) ; if ( muDoubleScalarIsNaN ( tmp ) ||
muDoubleScalarIsInf ( tmp ) ) { tmp = 0.0 ; } else { tmp = muDoubleScalarRem
( tmp , 4.294967296E+9 ) ; } tseed = tmp < 0.0 ? ( uint32_T ) - ( int32_T ) (
uint32_T ) - tmp : ( uint32_T ) tmp ; i = ( int32_T ) ( tseed >> 16U ) ; t =
( int32_T ) ( tseed & 32768U ) ; tseed = ( ( ( ( tseed - ( ( uint32_T ) i <<
16U ) ) + ( uint32_T ) t ) << 16U ) + ( uint32_T ) t ) + ( uint32_T ) i ; if
( tseed < 1U ) { tseed = 1144108930U ; } else if ( tseed > 2147483646U ) {
tseed = 2147483646U ; } rtDW . kasvnwnwfd = tseed ; rtDW . mq4tzms12g = ( rtP
. UniformRandomNumber5_Maximum - rtP . UniformRandomNumber5_Minimum ) *
rt_urand_Upu32_Yd_f_pw_snf ( & rtDW . kasvnwnwfd ) + rtP .
UniformRandomNumber5_Minimum ; rtDW . pdh0ayrbq2 = rtP .
UnitDelay1_InitialCondition_fked3caosb ; tmp = muDoubleScalarFloor ( rtP .
UniformRandomNumber_Seed ) ; if ( muDoubleScalarIsNaN ( tmp ) ||
muDoubleScalarIsInf ( tmp ) ) { tmp = 0.0 ; } else { tmp = muDoubleScalarRem
( tmp , 4.294967296E+9 ) ; } tseed = tmp < 0.0 ? ( uint32_T ) - ( int32_T ) (
uint32_T ) - tmp : ( uint32_T ) tmp ; i = ( int32_T ) ( tseed >> 16U ) ; t =
( int32_T ) ( tseed & 32768U ) ; tseed = ( ( ( ( tseed - ( ( uint32_T ) i <<
16U ) ) + ( uint32_T ) t ) << 16U ) + ( uint32_T ) t ) + ( uint32_T ) i ; if
( tseed < 1U ) { tseed = 1144108930U ; } else if ( tseed > 2147483646U ) {
tseed = 2147483646U ; } rtDW . d2hdmgi2df = tseed ; rtDW . jk5yslpya4 = ( rtP
. UniformRandomNumber_Maximum - rtP . UniformRandomNumber_Minimum ) *
rt_urand_Upu32_Yd_f_pw_snf ( & rtDW . d2hdmgi2df ) + rtP .
UniformRandomNumber_Minimum ; tmp = muDoubleScalarFloor ( rtP .
UniformRandomNumber1_Seed ) ; if ( muDoubleScalarIsNaN ( tmp ) ||
muDoubleScalarIsInf ( tmp ) ) { tmp = 0.0 ; } else { tmp = muDoubleScalarRem
( tmp , 4.294967296E+9 ) ; } tseed = tmp < 0.0 ? ( uint32_T ) - ( int32_T ) (
uint32_T ) - tmp : ( uint32_T ) tmp ; i = ( int32_T ) ( tseed >> 16U ) ; t =
( int32_T ) ( tseed & 32768U ) ; tseed = ( ( ( ( tseed - ( ( uint32_T ) i <<
16U ) ) + ( uint32_T ) t ) << 16U ) + ( uint32_T ) t ) + ( uint32_T ) i ; if
( tseed < 1U ) { tseed = 1144108930U ; } else if ( tseed > 2147483646U ) {
tseed = 2147483646U ; } rtDW . eesjxfyvk2 = tseed ; rtDW . o0mql2hqjx = ( rtP
. UniformRandomNumber1_Maximum - rtP . UniformRandomNumber1_Minimum ) *
rt_urand_Upu32_Yd_f_pw_snf ( & rtDW . eesjxfyvk2 ) + rtP .
UniformRandomNumber1_Minimum ; tmp = muDoubleScalarFloor ( rtP .
UniformRandomNumber2_Seed_l3l21jyov0 ) ; if ( muDoubleScalarIsNaN ( tmp ) ||
muDoubleScalarIsInf ( tmp ) ) { tmp = 0.0 ; } else { tmp = muDoubleScalarRem
( tmp , 4.294967296E+9 ) ; } tseed = tmp < 0.0 ? ( uint32_T ) - ( int32_T ) (
uint32_T ) - tmp : ( uint32_T ) tmp ; i = ( int32_T ) ( tseed >> 16U ) ; t =
( int32_T ) ( tseed & 32768U ) ; tseed = ( ( ( ( tseed - ( ( uint32_T ) i <<
16U ) ) + ( uint32_T ) t ) << 16U ) + ( uint32_T ) t ) + ( uint32_T ) i ; if
( tseed < 1U ) { tseed = 1144108930U ; } else if ( tseed > 2147483646U ) {
tseed = 2147483646U ; } rtDW . cdqamvzgi2 = tseed ; rtDW . o2pzpkkeul = ( rtP
. UniformRandomNumber2_Maximum_h0hkt0qhvs - rtP .
UniformRandomNumber2_Minimum_fx5mnbvdh4 ) * rt_urand_Upu32_Yd_f_pw_snf ( &
rtDW . cdqamvzgi2 ) + rtP . UniformRandomNumber2_Minimum_fx5mnbvdh4 ; tmp =
muDoubleScalarFloor ( rtP . UniformRandomNumber3_Seed ) ; if (
muDoubleScalarIsNaN ( tmp ) || muDoubleScalarIsInf ( tmp ) ) { tmp = 0.0 ; }
else { tmp = muDoubleScalarRem ( tmp , 4.294967296E+9 ) ; } tseed = tmp < 0.0
? ( uint32_T ) - ( int32_T ) ( uint32_T ) - tmp : ( uint32_T ) tmp ; i = (
int32_T ) ( tseed >> 16U ) ; t = ( int32_T ) ( tseed & 32768U ) ; tseed = ( (
( ( tseed - ( ( uint32_T ) i << 16U ) ) + ( uint32_T ) t ) << 16U ) + (
uint32_T ) t ) + ( uint32_T ) i ; if ( tseed < 1U ) { tseed = 1144108930U ; }
else if ( tseed > 2147483646U ) { tseed = 2147483646U ; } rtDW . a2u1lqkyoh =
tseed ; rtDW . njvyqws1h5 = ( rtP . UniformRandomNumber3_Maximum - rtP .
UniformRandomNumber3_Minimum ) * rt_urand_Upu32_Yd_f_pw_snf ( & rtDW .
a2u1lqkyoh ) + rtP . UniformRandomNumber3_Minimum ; tmp = muDoubleScalarFloor
( rtP . UniformRandomNumber4_Seed ) ; if ( muDoubleScalarIsNaN ( tmp ) ||
muDoubleScalarIsInf ( tmp ) ) { tmp = 0.0 ; } else { tmp = muDoubleScalarRem
( tmp , 4.294967296E+9 ) ; } tseed = tmp < 0.0 ? ( uint32_T ) - ( int32_T ) (
uint32_T ) - tmp : ( uint32_T ) tmp ; i = ( int32_T ) ( tseed >> 16U ) ; t =
( int32_T ) ( tseed & 32768U ) ; tseed = ( ( ( ( tseed - ( ( uint32_T ) i <<
16U ) ) + ( uint32_T ) t ) << 16U ) + ( uint32_T ) t ) + ( uint32_T ) i ; if
( tseed < 1U ) { tseed = 1144108930U ; } else if ( tseed > 2147483646U ) {
tseed = 2147483646U ; } rtDW . mpm2qm4ahz = tseed ; rtDW . hblnhilp5j = ( rtP
. UniformRandomNumber4_Maximum - rtP . UniformRandomNumber4_Minimum ) *
rt_urand_Upu32_Yd_f_pw_snf ( & rtDW . mpm2qm4ahz ) + rtP .
UniformRandomNumber4_Minimum ; rtDW . i2jledyuxk = rtP .
UnitDelay2_InitialCondition_cz3sr01ooy ; { SimStruct * rts = ssGetSFunction (
rtS , 0 ) ; sfcnInitializeConditions ( rts ) ; if ( ssGetErrorStatus ( rts )
!= ( NULL ) ) return ; } rtX . lnj4efc1py = rtP . Integrator_IC ; rtX .
mt5ndntoey = rtP . PIDController1_InitialConditionForIntegrator ; rtX .
korolwetpt = rtP . PIDController1_InitialConditionForFilter ; rtX .
indcayvth4 = rtP . PIDController_InitialConditionForIntegrator ; rtX .
nbjzeco0u3 = rtP . PIDController_InitialConditionForFilter ; rtDW .
mk4nogmrgx = rtP . Difference_ICPrevInput ; rtDW . hdgt0peaua = rtP .
Difference1_ICPrevInput ; rtDW . dx0psck2g2 = jh4s05c31l ; rtDW . a3naafic3w
= kluzj30pzp ; rtDW . ksqmuzqxoq = kluzj30pzp ; rtDW . ntbs21hax4 = 0U ; rtDW
. hjgrew42b2 = 0U ; rtDW . il0ohwuds5 = 0U ; rtDW . eyqkltgelg = 0U ; rtDW .
g0pte1h22i = kluzj30pzp ; rtDW . csce1vtaiv = 0U ; rtDW . jraid5zlrs = 0U ;
rtDW . arjuzvir0v = kluzj30pzp ; rtB . gvytu245ky = 0.0 ; rtB . ai311bapfw =
0.0 ; rtB . nr5jzefs11 = false ; rtB . g4otcjhaps = false ; rtB . c50enbqbhd
= false ; euommxokvy ( & rtB . lvdmxslirzu , & rtP . lvdmxslirzu ) ;
dnd2bzvthx ( & rtB . lsul0j3thv5 , & rtP . lsul0j3thv5 ) ; b2ou3bzaum ( & rtB
. o0l0tlmums2 , & rtP . o0l0tlmums2 ) ; cbl0gm11na ( & rtB . e5i1gkys053 , &
rtP . e5i1gkys053 ) ; memcpy ( & rtDW . htl3ck05k3 [ 0 ] , & tmp_p [ 0 ] ,
625U * sizeof ( uint32_T ) ) ; rtDW . bv5o5ntfep = jh4s05c31l ; rtDW .
lyrzf3l331 = kluzj30pzp ; rtDW . o5lpscgpim = kluzj30pzp ; rtDW . i33gdokzps
= kluzj30pzp ; rtDW . puvxpdyspy = kluzj30pzp ; rtDW . hvipzkfxby =
kluzj30pzp ; rtDW . b2oh0gakei = kluzj30pzp ; rtDW . ifylc1ayya = 0U ; rtDW .
cuxelkmbzn = 0U ; rtDW . cnphnmyixz = kluzj30pzp ; rtB . koa2xwzkqz = false ;
rtB . llcmsauyav = false ; rtB . govtsadkmh = false ; rtB . gfgfscs3wh =
false ; rtB . hwlkc3gph4 = false ; rtB . ipy2o045sf = false ; rtB .
ggozffptrp = false ; rtB . ln01g2x54f = false ; rtDW . j4xo2d0p0j = 0U ; rtDW
. hhdj03gcse = true ; rtDW . en0wsgm2d2 = 7U ; rtDW . e54eqryqod = true ;
rtDW . ek03o5d0zn = true ; rtDW . kf3zpzee4j [ 0 ] = 362436069U ; rtDW .
kf3zpzee4j [ 1 ] = 521288629U ; rtDW . ouoju14cbw = true ; rtDW . m5g4cvi2wi
= 1144108930U ; rtDW . k20nitrd4l = true ; } void MdlStart ( void ) { { bool
externalInputIsInDatasetFormat = false ; void * pISigstreamManager =
rt_GetISigstreamManager ( rtS ) ;
rtwISigstreamManagerGetInputIsInDatasetFormat ( pISigstreamManager , &
externalInputIsInDatasetFormat ) ; if ( externalInputIsInDatasetFormat ) { }
} { { { bool isStreamoutAlreadyRegistered = false ; { sdiSignalSourceInfoU
srcInfo ; sdiLabelU loggedName = sdiGetLabelFromChars ( "" ) ; sdiLabelU
origSigName = sdiGetLabelFromChars ( "" ) ; sdiLabelU propName =
sdiGetLabelFromChars ( "" ) ; sdiLabelU blockPath = sdiGetLabelFromChars (
"cstr_simulationEnv/Feed_Temperature_In" ) ; sdiLabelU blockSID =
sdiGetLabelFromChars ( "" ) ; sdiLabelU subPath = sdiGetLabelFromChars ( "" )
; sdiDims sigDims ; sdiLabelU sigName = sdiGetLabelFromChars ( "" ) ;
sdiAsyncRepoDataTypeHandle hDT = sdiAsyncRepoGetBuiltInDataTypeHandle (
DATA_TYPE_DOUBLE ) ; { sdiComplexity sigComplexity = REAL ;
sdiSampleTimeContinuity stCont = SAMPLE_TIME_DISCRETE ; int_T sigDimsArray [
1 ] = { 1 } ; sigDims . nDims = 1 ; sigDims . dimensions = sigDimsArray ;
srcInfo . numBlockPathElems = 1 ; srcInfo . fullBlockPath = ( sdiFullBlkPathU
) & blockPath ; srcInfo . SID = ( sdiSignalIDU ) & blockSID ; srcInfo .
subPath = subPath ; srcInfo . portIndex = 0 + 1 ; srcInfo . signalName =
sigName ; srcInfo . sigSourceUUID = 0 ; rtDW . j2ehmt2zxo . AQHandles =
sdiStartAsyncioQueueCreation ( hDT , & srcInfo , rt_dataMapInfo . mmi .
InstanceMap . fullPath , "b87d17fb-cd4d-417c-a963-f7d4a4d3578b" ,
sigComplexity , & sigDims , DIMENSIONS_MODE_FIXED , stCont , "" ) ;
sdiCompleteAsyncioQueueCreation ( rtDW . j2ehmt2zxo . AQHandles , hDT , &
srcInfo ) ; if ( rtDW . j2ehmt2zxo . AQHandles ) {
sdiSetSignalSampleTimeString ( rtDW . j2ehmt2zxo . AQHandles , "Parameter" ,
0.0 , ssGetTFinal ( rtS ) ) ; sdiSetSignalRefRate ( rtDW . j2ehmt2zxo .
AQHandles , 0.0 ) ; sdiSetRunStartTime ( rtDW . j2ehmt2zxo . AQHandles ,
ssGetTaskTime ( rtS , 4 ) ) ; sdiAsyncRepoSetSignalExportSettings ( rtDW .
j2ehmt2zxo . AQHandles , 1 , 0 ) ; sdiAsyncRepoSetSignalExportName ( rtDW .
j2ehmt2zxo . AQHandles , loggedName , origSigName , propName ) ; }
sdiFreeLabel ( sigName ) ; sdiFreeLabel ( loggedName ) ; sdiFreeLabel (
origSigName ) ; sdiFreeLabel ( propName ) ; sdiFreeLabel ( blockPath ) ;
sdiFreeLabel ( blockSID ) ; sdiFreeLabel ( subPath ) ; } } if ( !
isStreamoutAlreadyRegistered ) { } } } } { { { bool
isStreamoutAlreadyRegistered = false ; { sdiSignalSourceInfoU srcInfo ;
sdiLabelU loggedName = sdiGetLabelFromChars ( "" ) ; sdiLabelU origSigName =
sdiGetLabelFromChars ( "" ) ; sdiLabelU propName = sdiGetLabelFromChars ( ""
) ; sdiLabelU blockPath = sdiGetLabelFromChars (
"cstr_simulationEnv/Feed_Temperature_Out" ) ; sdiLabelU blockSID =
sdiGetLabelFromChars ( "" ) ; sdiLabelU subPath = sdiGetLabelFromChars ( "" )
; sdiDims sigDims ; sdiLabelU sigName = sdiGetLabelFromChars ( "" ) ;
sdiAsyncRepoDataTypeHandle hDT = sdiAsyncRepoGetBuiltInDataTypeHandle (
DATA_TYPE_DOUBLE ) ; { sdiComplexity sigComplexity = REAL ;
sdiSampleTimeContinuity stCont = SAMPLE_TIME_DISCRETE ; int_T sigDimsArray [
1 ] = { 1 } ; sigDims . nDims = 1 ; sigDims . dimensions = sigDimsArray ;
srcInfo . numBlockPathElems = 1 ; srcInfo . fullBlockPath = ( sdiFullBlkPathU
) & blockPath ; srcInfo . SID = ( sdiSignalIDU ) & blockSID ; srcInfo .
subPath = subPath ; srcInfo . portIndex = 0 + 1 ; srcInfo . signalName =
sigName ; srcInfo . sigSourceUUID = 0 ; rtDW . cue41xrxnu . AQHandles =
sdiStartAsyncioQueueCreation ( hDT , & srcInfo , rt_dataMapInfo . mmi .
InstanceMap . fullPath , "9509dc5c-e394-48b9-a71b-7bd597dbd62e" ,
sigComplexity , & sigDims , DIMENSIONS_MODE_FIXED , stCont , "" ) ;
sdiCompleteAsyncioQueueCreation ( rtDW . cue41xrxnu . AQHandles , hDT , &
srcInfo ) ; if ( rtDW . cue41xrxnu . AQHandles ) {
sdiSetSignalSampleTimeString ( rtDW . cue41xrxnu . AQHandles , "Parameter" ,
0.0 , ssGetTFinal ( rtS ) ) ; sdiSetSignalRefRate ( rtDW . cue41xrxnu .
AQHandles , 0.0 ) ; sdiSetRunStartTime ( rtDW . cue41xrxnu . AQHandles ,
ssGetTaskTime ( rtS , 4 ) ) ; sdiAsyncRepoSetSignalExportSettings ( rtDW .
cue41xrxnu . AQHandles , 1 , 0 ) ; sdiAsyncRepoSetSignalExportName ( rtDW .
cue41xrxnu . AQHandles , loggedName , origSigName , propName ) ; }
sdiFreeLabel ( sigName ) ; sdiFreeLabel ( loggedName ) ; sdiFreeLabel (
origSigName ) ; sdiFreeLabel ( propName ) ; sdiFreeLabel ( blockPath ) ;
sdiFreeLabel ( blockSID ) ; sdiFreeLabel ( subPath ) ; } } if ( !
isStreamoutAlreadyRegistered ) { } } } } { { { bool
isStreamoutAlreadyRegistered = false ; { sdiSignalSourceInfoU srcInfo ;
sdiLabelU loggedName = sdiGetLabelFromChars ( "" ) ; sdiLabelU origSigName =
sdiGetLabelFromChars ( "" ) ; sdiLabelU propName = sdiGetLabelFromChars ( ""
) ; sdiLabelU blockPath = sdiGetLabelFromChars (
"cstr_simulationEnv/Inlet_Flow_In" ) ; sdiLabelU blockSID =
sdiGetLabelFromChars ( "" ) ; sdiLabelU subPath = sdiGetLabelFromChars ( "" )
; sdiDims sigDims ; sdiLabelU sigName = sdiGetLabelFromChars ( "" ) ;
sdiAsyncRepoDataTypeHandle hDT = sdiAsyncRepoGetBuiltInDataTypeHandle (
DATA_TYPE_DOUBLE ) ; { sdiComplexity sigComplexity = REAL ;
sdiSampleTimeContinuity stCont = SAMPLE_TIME_DISCRETE ; int_T sigDimsArray [
1 ] = { 1 } ; sigDims . nDims = 1 ; sigDims . dimensions = sigDimsArray ;
srcInfo . numBlockPathElems = 1 ; srcInfo . fullBlockPath = ( sdiFullBlkPathU
) & blockPath ; srcInfo . SID = ( sdiSignalIDU ) & blockSID ; srcInfo .
subPath = subPath ; srcInfo . portIndex = 0 + 1 ; srcInfo . signalName =
sigName ; srcInfo . sigSourceUUID = 0 ; rtDW . pubxocmqc2 . AQHandles =
sdiStartAsyncioQueueCreation ( hDT , & srcInfo , rt_dataMapInfo . mmi .
InstanceMap . fullPath , "29236805-cce3-464a-afb6-0e763566963a" ,
sigComplexity , & sigDims , DIMENSIONS_MODE_FIXED , stCont , "" ) ;
sdiCompleteAsyncioQueueCreation ( rtDW . pubxocmqc2 . AQHandles , hDT , &
srcInfo ) ; if ( rtDW . pubxocmqc2 . AQHandles ) {
sdiSetSignalSampleTimeString ( rtDW . pubxocmqc2 . AQHandles , "Parameter" ,
0.0 , ssGetTFinal ( rtS ) ) ; sdiSetSignalRefRate ( rtDW . pubxocmqc2 .
AQHandles , 0.0 ) ; sdiSetRunStartTime ( rtDW . pubxocmqc2 . AQHandles ,
ssGetTaskTime ( rtS , 4 ) ) ; sdiAsyncRepoSetSignalExportSettings ( rtDW .
pubxocmqc2 . AQHandles , 1 , 0 ) ; sdiAsyncRepoSetSignalExportName ( rtDW .
pubxocmqc2 . AQHandles , loggedName , origSigName , propName ) ; }
sdiFreeLabel ( sigName ) ; sdiFreeLabel ( loggedName ) ; sdiFreeLabel (
origSigName ) ; sdiFreeLabel ( propName ) ; sdiFreeLabel ( blockPath ) ;
sdiFreeLabel ( blockSID ) ; sdiFreeLabel ( subPath ) ; } } if ( !
isStreamoutAlreadyRegistered ) { } } } } { { { bool
isStreamoutAlreadyRegistered = false ; { sdiSignalSourceInfoU srcInfo ;
sdiLabelU loggedName = sdiGetLabelFromChars ( "" ) ; sdiLabelU origSigName =
sdiGetLabelFromChars ( "" ) ; sdiLabelU propName = sdiGetLabelFromChars ( ""
) ; sdiLabelU blockPath = sdiGetLabelFromChars (
"cstr_simulationEnv/Inlet_Flow_Out" ) ; sdiLabelU blockSID =
sdiGetLabelFromChars ( "" ) ; sdiLabelU subPath = sdiGetLabelFromChars ( "" )
; sdiDims sigDims ; sdiLabelU sigName = sdiGetLabelFromChars ( "" ) ;
sdiAsyncRepoDataTypeHandle hDT = sdiAsyncRepoGetBuiltInDataTypeHandle (
DATA_TYPE_DOUBLE ) ; { sdiComplexity sigComplexity = REAL ;
sdiSampleTimeContinuity stCont = SAMPLE_TIME_DISCRETE ; int_T sigDimsArray [
1 ] = { 1 } ; sigDims . nDims = 1 ; sigDims . dimensions = sigDimsArray ;
srcInfo . numBlockPathElems = 1 ; srcInfo . fullBlockPath = ( sdiFullBlkPathU
) & blockPath ; srcInfo . SID = ( sdiSignalIDU ) & blockSID ; srcInfo .
subPath = subPath ; srcInfo . portIndex = 0 + 1 ; srcInfo . signalName =
sigName ; srcInfo . sigSourceUUID = 0 ; rtDW . f0ugwgjvhr . AQHandles =
sdiStartAsyncioQueueCreation ( hDT , & srcInfo , rt_dataMapInfo . mmi .
InstanceMap . fullPath , "3c17fead-983c-4b5e-9e29-0559d11db408" ,
sigComplexity , & sigDims , DIMENSIONS_MODE_FIXED , stCont , "" ) ;
sdiCompleteAsyncioQueueCreation ( rtDW . f0ugwgjvhr . AQHandles , hDT , &
srcInfo ) ; if ( rtDW . f0ugwgjvhr . AQHandles ) {
sdiSetSignalSampleTimeString ( rtDW . f0ugwgjvhr . AQHandles , "Parameter" ,
0.0 , ssGetTFinal ( rtS ) ) ; sdiSetSignalRefRate ( rtDW . f0ugwgjvhr .
AQHandles , 0.0 ) ; sdiSetRunStartTime ( rtDW . f0ugwgjvhr . AQHandles ,
ssGetTaskTime ( rtS , 4 ) ) ; sdiAsyncRepoSetSignalExportSettings ( rtDW .
f0ugwgjvhr . AQHandles , 1 , 0 ) ; sdiAsyncRepoSetSignalExportName ( rtDW .
f0ugwgjvhr . AQHandles , loggedName , origSigName , propName ) ; }
sdiFreeLabel ( sigName ) ; sdiFreeLabel ( loggedName ) ; sdiFreeLabel (
origSigName ) ; sdiFreeLabel ( propName ) ; sdiFreeLabel ( blockPath ) ;
sdiFreeLabel ( blockSID ) ; sdiFreeLabel ( subPath ) ; } } if ( !
isStreamoutAlreadyRegistered ) { } } } } { { { bool
isStreamoutAlreadyRegistered = false ; { sdiSignalSourceInfoU srcInfo ;
sdiLabelU loggedName = sdiGetLabelFromChars ( "" ) ; sdiLabelU origSigName =
sdiGetLabelFromChars ( "" ) ; sdiLabelU propName = sdiGetLabelFromChars ( ""
) ; sdiLabelU blockPath = sdiGetLabelFromChars (
"cstr_simulationEnv/CSTR_1 Simulation Model + Regulatory Control/C_Bin" ) ;
sdiLabelU blockSID = sdiGetLabelFromChars ( "" ) ; sdiLabelU subPath =
sdiGetLabelFromChars ( "" ) ; sdiDims sigDims ; sdiLabelU sigName =
sdiGetLabelFromChars ( "" ) ; sdiAsyncRepoDataTypeHandle hDT =
sdiAsyncRepoGetBuiltInDataTypeHandle ( DATA_TYPE_DOUBLE ) ; { sdiComplexity
sigComplexity = REAL ; sdiSampleTimeContinuity stCont = SAMPLE_TIME_DISCRETE
; int_T sigDimsArray [ 1 ] = { 1 } ; sigDims . nDims = 1 ; sigDims .
dimensions = sigDimsArray ; srcInfo . numBlockPathElems = 1 ; srcInfo .
fullBlockPath = ( sdiFullBlkPathU ) & blockPath ; srcInfo . SID = (
sdiSignalIDU ) & blockSID ; srcInfo . subPath = subPath ; srcInfo . portIndex
= 0 + 1 ; srcInfo . signalName = sigName ; srcInfo . sigSourceUUID = 0 ; rtDW
. g53jytoip4 . AQHandles = sdiStartAsyncioQueueCreation ( hDT , & srcInfo ,
rt_dataMapInfo . mmi . InstanceMap . fullPath ,
"85b8b43c-4a30-463a-a417-58eb9f0f59df" , sigComplexity , & sigDims ,
DIMENSIONS_MODE_FIXED , stCont , "" ) ; sdiCompleteAsyncioQueueCreation (
rtDW . g53jytoip4 . AQHandles , hDT , & srcInfo ) ; if ( rtDW . g53jytoip4 .
AQHandles ) { sdiSetSignalSampleTimeString ( rtDW . g53jytoip4 . AQHandles ,
"Parameter" , 0.0 , ssGetTFinal ( rtS ) ) ; sdiSetSignalRefRate ( rtDW .
g53jytoip4 . AQHandles , 0.0 ) ; sdiSetRunStartTime ( rtDW . g53jytoip4 .
AQHandles , ssGetTaskTime ( rtS , 4 ) ) ; sdiAsyncRepoSetSignalExportSettings
( rtDW . g53jytoip4 . AQHandles , 1 , 0 ) ; sdiAsyncRepoSetSignalExportName (
rtDW . g53jytoip4 . AQHandles , loggedName , origSigName , propName ) ; }
sdiFreeLabel ( sigName ) ; sdiFreeLabel ( loggedName ) ; sdiFreeLabel (
origSigName ) ; sdiFreeLabel ( propName ) ; sdiFreeLabel ( blockPath ) ;
sdiFreeLabel ( blockSID ) ; sdiFreeLabel ( subPath ) ; } } if ( !
isStreamoutAlreadyRegistered ) { } } } } { { { bool
isStreamoutAlreadyRegistered = false ; { sdiSignalSourceInfoU srcInfo ;
sdiLabelU loggedName = sdiGetLabelFromChars ( "" ) ; sdiLabelU origSigName =
sdiGetLabelFromChars ( "" ) ; sdiLabelU propName = sdiGetLabelFromChars ( ""
) ; sdiLabelU blockPath = sdiGetLabelFromChars (
"cstr_simulationEnv/CSTR_1 Simulation Model + Regulatory Control/C_Cin" ) ;
sdiLabelU blockSID = sdiGetLabelFromChars ( "" ) ; sdiLabelU subPath =
sdiGetLabelFromChars ( "" ) ; sdiDims sigDims ; sdiLabelU sigName =
sdiGetLabelFromChars ( "" ) ; sdiAsyncRepoDataTypeHandle hDT =
sdiAsyncRepoGetBuiltInDataTypeHandle ( DATA_TYPE_DOUBLE ) ; { sdiComplexity
sigComplexity = REAL ; sdiSampleTimeContinuity stCont = SAMPLE_TIME_DISCRETE
; int_T sigDimsArray [ 1 ] = { 1 } ; sigDims . nDims = 1 ; sigDims .
dimensions = sigDimsArray ; srcInfo . numBlockPathElems = 1 ; srcInfo .
fullBlockPath = ( sdiFullBlkPathU ) & blockPath ; srcInfo . SID = (
sdiSignalIDU ) & blockSID ; srcInfo . subPath = subPath ; srcInfo . portIndex
= 0 + 1 ; srcInfo . signalName = sigName ; srcInfo . sigSourceUUID = 0 ; rtDW
. obf4siedf4 . AQHandles = sdiStartAsyncioQueueCreation ( hDT , & srcInfo ,
rt_dataMapInfo . mmi . InstanceMap . fullPath ,
"84a121a8-8be5-4a58-8adb-76d675f9b5d7" , sigComplexity , & sigDims ,
DIMENSIONS_MODE_FIXED , stCont , "" ) ; sdiCompleteAsyncioQueueCreation (
rtDW . obf4siedf4 . AQHandles , hDT , & srcInfo ) ; if ( rtDW . obf4siedf4 .
AQHandles ) { sdiSetSignalSampleTimeString ( rtDW . obf4siedf4 . AQHandles ,
"Parameter" , 0.0 , ssGetTFinal ( rtS ) ) ; sdiSetSignalRefRate ( rtDW .
obf4siedf4 . AQHandles , 0.0 ) ; sdiSetRunStartTime ( rtDW . obf4siedf4 .
AQHandles , ssGetTaskTime ( rtS , 4 ) ) ; sdiAsyncRepoSetSignalExportSettings
( rtDW . obf4siedf4 . AQHandles , 1 , 0 ) ; sdiAsyncRepoSetSignalExportName (
rtDW . obf4siedf4 . AQHandles , loggedName , origSigName , propName ) ; }
sdiFreeLabel ( sigName ) ; sdiFreeLabel ( loggedName ) ; sdiFreeLabel (
origSigName ) ; sdiFreeLabel ( propName ) ; sdiFreeLabel ( blockPath ) ;
sdiFreeLabel ( blockSID ) ; sdiFreeLabel ( subPath ) ; } } if ( !
isStreamoutAlreadyRegistered ) { } } } } { { { bool
isStreamoutAlreadyRegistered = false ; { sdiSignalSourceInfoU srcInfo ;
sdiLabelU loggedName = sdiGetLabelFromChars ( "" ) ; sdiLabelU origSigName =
sdiGetLabelFromChars ( "" ) ; sdiLabelU propName = sdiGetLabelFromChars ( ""
) ; sdiLabelU blockPath = sdiGetLabelFromChars (
"cstr_simulationEnv/CSTR_1 Simulation Model + Regulatory Control/Rate3" ) ;
sdiLabelU blockSID = sdiGetLabelFromChars ( "" ) ; sdiLabelU subPath =
sdiGetLabelFromChars ( "" ) ; sdiDims sigDims ; sdiLabelU sigName =
sdiGetLabelFromChars ( "" ) ; sdiAsyncRepoDataTypeHandle hDT =
sdiAsyncRepoGetBuiltInDataTypeHandle ( DATA_TYPE_DOUBLE ) ; { sdiComplexity
sigComplexity = REAL ; sdiSampleTimeContinuity stCont = SAMPLE_TIME_DISCRETE
; int_T sigDimsArray [ 1 ] = { 1 } ; sigDims . nDims = 1 ; sigDims .
dimensions = sigDimsArray ; srcInfo . numBlockPathElems = 1 ; srcInfo .
fullBlockPath = ( sdiFullBlkPathU ) & blockPath ; srcInfo . SID = (
sdiSignalIDU ) & blockSID ; srcInfo . subPath = subPath ; srcInfo . portIndex
= 0 + 1 ; srcInfo . signalName = sigName ; srcInfo . sigSourceUUID = 0 ; rtDW
. o5jtmaqc3t . AQHandles = sdiStartAsyncioQueueCreation ( hDT , & srcInfo ,
rt_dataMapInfo . mmi . InstanceMap . fullPath ,
"a7909db1-8ffc-4657-a62b-ba160900a7b7" , sigComplexity , & sigDims ,
DIMENSIONS_MODE_FIXED , stCont , "" ) ; sdiCompleteAsyncioQueueCreation (
rtDW . o5jtmaqc3t . AQHandles , hDT , & srcInfo ) ; if ( rtDW . o5jtmaqc3t .
AQHandles ) { sdiSetSignalSampleTimeString ( rtDW . o5jtmaqc3t . AQHandles ,
"Parameter" , 0.0 , ssGetTFinal ( rtS ) ) ; sdiSetSignalRefRate ( rtDW .
o5jtmaqc3t . AQHandles , 0.0 ) ; sdiSetRunStartTime ( rtDW . o5jtmaqc3t .
AQHandles , ssGetTaskTime ( rtS , 4 ) ) ; sdiAsyncRepoSetSignalExportSettings
( rtDW . o5jtmaqc3t . AQHandles , 1 , 0 ) ; sdiAsyncRepoSetSignalExportName (
rtDW . o5jtmaqc3t . AQHandles , loggedName , origSigName , propName ) ; }
sdiFreeLabel ( sigName ) ; sdiFreeLabel ( loggedName ) ; sdiFreeLabel (
origSigName ) ; sdiFreeLabel ( propName ) ; sdiFreeLabel ( blockPath ) ;
sdiFreeLabel ( blockSID ) ; sdiFreeLabel ( subPath ) ; } } if ( !
isStreamoutAlreadyRegistered ) { } } } } { { { bool
isStreamoutAlreadyRegistered = false ; { sdiSignalSourceInfoU srcInfo ;
sdiLabelU loggedName = sdiGetLabelFromChars ( "" ) ; sdiLabelU origSigName =
sdiGetLabelFromChars ( "" ) ; sdiLabelU propName = sdiGetLabelFromChars ( ""
) ; sdiLabelU blockPath = sdiGetLabelFromChars (
"cstr_simulationEnv/Fault Engine" ) ; sdiLabelU blockSID =
sdiGetLabelFromChars ( "" ) ; sdiLabelU subPath = sdiGetLabelFromChars ( "" )
; sdiDims sigDims ; sdiLabelU sigName = sdiGetLabelFromChars ( "" ) ;
sdiAsyncRepoDataTypeHandle hDT = sdiAsyncRepoGetBuiltInDataTypeHandle (
DATA_TYPE_DOUBLE ) ; { sdiComplexity sigComplexity = REAL ;
sdiSampleTimeContinuity stCont = SAMPLE_TIME_CONTINUOUS ; int_T sigDimsArray
[ 1 ] = { 1 } ; sigDims . nDims = 1 ; sigDims . dimensions = sigDimsArray ;
srcInfo . numBlockPathElems = 1 ; srcInfo . fullBlockPath = ( sdiFullBlkPathU
) & blockPath ; srcInfo . SID = ( sdiSignalIDU ) & blockSID ; srcInfo .
subPath = subPath ; srcInfo . portIndex = 0 + 1 ; srcInfo . signalName =
sigName ; srcInfo . sigSourceUUID = 0 ; rtDW . odihpq11te . AQHandles =
sdiStartAsyncioQueueCreation ( hDT , & srcInfo , rt_dataMapInfo . mmi .
InstanceMap . fullPath , "8285ab6a-37ee-4dfa-9579-cc56ca4c531c" ,
sigComplexity , & sigDims , DIMENSIONS_MODE_FIXED , stCont , "" ) ;
sdiCompleteAsyncioQueueCreation ( rtDW . odihpq11te . AQHandles , hDT , &
srcInfo ) ; if ( rtDW . odihpq11te . AQHandles ) {
sdiSetSignalSampleTimeString ( rtDW . odihpq11te . AQHandles , "1" , 1.0 ,
ssGetTFinal ( rtS ) ) ; sdiSetSignalRefRate ( rtDW . odihpq11te . AQHandles ,
0.0 ) ; sdiSetRunStartTime ( rtDW . odihpq11te . AQHandles , ssGetTaskTime (
rtS , 1 ) ) ; sdiAsyncRepoSetSignalExportSettings ( rtDW . odihpq11te .
AQHandles , 1 , 0 ) ; sdiAsyncRepoSetSignalExportName ( rtDW . odihpq11te .
AQHandles , loggedName , origSigName , propName ) ; } sdiFreeLabel ( sigName
) ; sdiFreeLabel ( loggedName ) ; sdiFreeLabel ( origSigName ) ; sdiFreeLabel
( propName ) ; sdiFreeLabel ( blockPath ) ; sdiFreeLabel ( blockSID ) ;
sdiFreeLabel ( subPath ) ; } } if ( ! isStreamoutAlreadyRegistered ) { } } }
} { { { bool isStreamoutAlreadyRegistered = false ; { sdiSignalSourceInfoU
srcInfo ; sdiLabelU loggedName = sdiGetLabelFromChars ( "" ) ; sdiLabelU
origSigName = sdiGetLabelFromChars ( "" ) ; sdiLabelU propName =
sdiGetLabelFromChars ( "" ) ; sdiLabelU blockPath = sdiGetLabelFromChars (
"cstr_simulationEnv/Fault Engine" ) ; sdiLabelU blockSID =
sdiGetLabelFromChars ( "" ) ; sdiLabelU subPath = sdiGetLabelFromChars ( "" )
; sdiDims sigDims ; sdiLabelU sigName = sdiGetLabelFromChars ( "" ) ;
sdiAsyncRepoDataTypeHandle hDT = sdiAsyncRepoGetBuiltInDataTypeHandle (
DATA_TYPE_DOUBLE ) ; { sdiComplexity sigComplexity = REAL ;
sdiSampleTimeContinuity stCont = SAMPLE_TIME_DISCRETE ; int_T sigDimsArray [
1 ] = { 1 } ; sigDims . nDims = 1 ; sigDims . dimensions = sigDimsArray ;
srcInfo . numBlockPathElems = 1 ; srcInfo . fullBlockPath = ( sdiFullBlkPathU
) & blockPath ; srcInfo . SID = ( sdiSignalIDU ) & blockSID ; srcInfo .
subPath = subPath ; srcInfo . portIndex = 1 + 1 ; srcInfo . signalName =
sigName ; srcInfo . sigSourceUUID = 0 ; rtDW . jsnyah43h5 . AQHandles =
sdiStartAsyncioQueueCreation ( hDT , & srcInfo , rt_dataMapInfo . mmi .
InstanceMap . fullPath , "43a486d1-0e14-4a9c-b218-42716d1c1bd1" ,
sigComplexity , & sigDims , DIMENSIONS_MODE_FIXED , stCont , "" ) ;
sdiCompleteAsyncioQueueCreation ( rtDW . jsnyah43h5 . AQHandles , hDT , &
srcInfo ) ; if ( rtDW . jsnyah43h5 . AQHandles ) {
sdiSetSignalSampleTimeString ( rtDW . jsnyah43h5 . AQHandles , "1" , 1.0 ,
ssGetTFinal ( rtS ) ) ; sdiSetSignalRefRate ( rtDW . jsnyah43h5 . AQHandles ,
0.0 ) ; sdiSetRunStartTime ( rtDW . jsnyah43h5 . AQHandles , ssGetTaskTime (
rtS , 1 ) ) ; sdiAsyncRepoSetSignalExportSettings ( rtDW . jsnyah43h5 .
AQHandles , 1 , 0 ) ; sdiAsyncRepoSetSignalExportName ( rtDW . jsnyah43h5 .
AQHandles , loggedName , origSigName , propName ) ; } sdiFreeLabel ( sigName
) ; sdiFreeLabel ( loggedName ) ; sdiFreeLabel ( origSigName ) ; sdiFreeLabel
( propName ) ; sdiFreeLabel ( blockPath ) ; sdiFreeLabel ( blockSID ) ;
sdiFreeLabel ( subPath ) ; } } if ( ! isStreamoutAlreadyRegistered ) { } } }
} { { { bool isStreamoutAlreadyRegistered = false ; { sdiSignalSourceInfoU
srcInfo ; sdiLabelU loggedName = sdiGetLabelFromChars ( "" ) ; sdiLabelU
origSigName = sdiGetLabelFromChars ( "" ) ; sdiLabelU propName =
sdiGetLabelFromChars ( "" ) ; sdiLabelU blockPath = sdiGetLabelFromChars (
"cstr_simulationEnv/Fault Engine" ) ; sdiLabelU blockSID =
sdiGetLabelFromChars ( "" ) ; sdiLabelU subPath = sdiGetLabelFromChars ( "" )
; sdiDims sigDims ; sdiLabelU sigName = sdiGetLabelFromChars ( "" ) ;
sdiAsyncRepoDataTypeHandle hDT = sdiAsyncRepoGetBuiltInDataTypeHandle (
DATA_TYPE_DOUBLE ) ; { sdiComplexity sigComplexity = REAL ;
sdiSampleTimeContinuity stCont = SAMPLE_TIME_DISCRETE ; int_T sigDimsArray [
1 ] = { 1 } ; sigDims . nDims = 1 ; sigDims . dimensions = sigDimsArray ;
srcInfo . numBlockPathElems = 1 ; srcInfo . fullBlockPath = ( sdiFullBlkPathU
) & blockPath ; srcInfo . SID = ( sdiSignalIDU ) & blockSID ; srcInfo .
subPath = subPath ; srcInfo . portIndex = 2 + 1 ; srcInfo . signalName =
sigName ; srcInfo . sigSourceUUID = 0 ; rtDW . ggzqve4ryn . AQHandles =
sdiStartAsyncioQueueCreation ( hDT , & srcInfo , rt_dataMapInfo . mmi .
InstanceMap . fullPath , "917f5793-c53b-4253-a8dc-9e70d12c3b8c" ,
sigComplexity , & sigDims , DIMENSIONS_MODE_FIXED , stCont , "" ) ;
sdiCompleteAsyncioQueueCreation ( rtDW . ggzqve4ryn . AQHandles , hDT , &
srcInfo ) ; if ( rtDW . ggzqve4ryn . AQHandles ) {
sdiSetSignalSampleTimeString ( rtDW . ggzqve4ryn . AQHandles , "1" , 1.0 ,
ssGetTFinal ( rtS ) ) ; sdiSetSignalRefRate ( rtDW . ggzqve4ryn . AQHandles ,
0.0 ) ; sdiSetRunStartTime ( rtDW . ggzqve4ryn . AQHandles , ssGetTaskTime (
rtS , 1 ) ) ; sdiAsyncRepoSetSignalExportSettings ( rtDW . ggzqve4ryn .
AQHandles , 1 , 0 ) ; sdiAsyncRepoSetSignalExportName ( rtDW . ggzqve4ryn .
AQHandles , loggedName , origSigName , propName ) ; } sdiFreeLabel ( sigName
) ; sdiFreeLabel ( loggedName ) ; sdiFreeLabel ( origSigName ) ; sdiFreeLabel
( propName ) ; sdiFreeLabel ( blockPath ) ; sdiFreeLabel ( blockSID ) ;
sdiFreeLabel ( subPath ) ; } } if ( ! isStreamoutAlreadyRegistered ) { } } }
} { { { bool isStreamoutAlreadyRegistered = false ; { sdiSignalSourceInfoU
srcInfo ; sdiLabelU loggedName = sdiGetLabelFromChars ( "" ) ; sdiLabelU
origSigName = sdiGetLabelFromChars ( "" ) ; sdiLabelU propName =
sdiGetLabelFromChars ( "" ) ; sdiLabelU blockPath = sdiGetLabelFromChars (
"cstr_simulationEnv/Operator Control" ) ; sdiLabelU blockSID =
sdiGetLabelFromChars ( "" ) ; sdiLabelU subPath = sdiGetLabelFromChars ( "" )
; sdiDims sigDims ; sdiLabelU sigName = sdiGetLabelFromChars ( "" ) ;
sdiAsyncRepoDataTypeHandle hDT = sdiAsyncRepoGetBuiltInDataTypeHandle (
DATA_TYPE_BOOLEAN ) ; { sdiComplexity sigComplexity = REAL ;
sdiSampleTimeContinuity stCont = SAMPLE_TIME_DISCRETE ; int_T sigDimsArray [
1 ] = { 1 } ; sigDims . nDims = 1 ; sigDims . dimensions = sigDimsArray ;
srcInfo . numBlockPathElems = 1 ; srcInfo . fullBlockPath = ( sdiFullBlkPathU
) & blockPath ; srcInfo . SID = ( sdiSignalIDU ) & blockSID ; srcInfo .
subPath = subPath ; srcInfo . portIndex = 0 + 1 ; srcInfo . signalName =
sigName ; srcInfo . sigSourceUUID = 0 ; rtDW . ismfv5vasc . AQHandles =
sdiStartAsyncioQueueCreation ( hDT , & srcInfo , rt_dataMapInfo . mmi .
InstanceMap . fullPath , "5dc8479d-cc40-44b1-b904-610abcc59e4f" ,
sigComplexity , & sigDims , DIMENSIONS_MODE_FIXED , stCont , "" ) ;
sdiCompleteAsyncioQueueCreation ( rtDW . ismfv5vasc . AQHandles , hDT , &
srcInfo ) ; if ( rtDW . ismfv5vasc . AQHandles ) {
sdiSetSignalSampleTimeString ( rtDW . ismfv5vasc . AQHandles , "1" , 1.0 ,
ssGetTFinal ( rtS ) ) ; sdiSetSignalRefRate ( rtDW . ismfv5vasc . AQHandles ,
0.0 ) ; sdiSetRunStartTime ( rtDW . ismfv5vasc . AQHandles , ssGetTaskTime (
rtS , 1 ) ) ; sdiAsyncRepoSetSignalExportSettings ( rtDW . ismfv5vasc .
AQHandles , 1 , 0 ) ; sdiAsyncRepoSetSignalExportName ( rtDW . ismfv5vasc .
AQHandles , loggedName , origSigName , propName ) ; } sdiFreeLabel ( sigName
) ; sdiFreeLabel ( loggedName ) ; sdiFreeLabel ( origSigName ) ; sdiFreeLabel
( propName ) ; sdiFreeLabel ( blockPath ) ; sdiFreeLabel ( blockSID ) ;
sdiFreeLabel ( subPath ) ; } } if ( ! isStreamoutAlreadyRegistered ) { } } }
} { { { bool isStreamoutAlreadyRegistered = false ; { sdiSignalSourceInfoU
srcInfo ; sdiLabelU loggedName = sdiGetLabelFromChars ( "" ) ; sdiLabelU
origSigName = sdiGetLabelFromChars ( "" ) ; sdiLabelU propName =
sdiGetLabelFromChars ( "" ) ; sdiLabelU blockPath = sdiGetLabelFromChars (
"cstr_simulationEnv/Operator Control" ) ; sdiLabelU blockSID =
sdiGetLabelFromChars ( "" ) ; sdiLabelU subPath = sdiGetLabelFromChars ( "" )
; sdiDims sigDims ; sdiLabelU sigName = sdiGetLabelFromChars ( "" ) ;
sdiAsyncRepoDataTypeHandle hDT = sdiAsyncRepoGetBuiltInDataTypeHandle (
DATA_TYPE_BOOLEAN ) ; { sdiComplexity sigComplexity = REAL ;
sdiSampleTimeContinuity stCont = SAMPLE_TIME_DISCRETE ; int_T sigDimsArray [
1 ] = { 1 } ; sigDims . nDims = 1 ; sigDims . dimensions = sigDimsArray ;
srcInfo . numBlockPathElems = 1 ; srcInfo . fullBlockPath = ( sdiFullBlkPathU
) & blockPath ; srcInfo . SID = ( sdiSignalIDU ) & blockSID ; srcInfo .
subPath = subPath ; srcInfo . portIndex = 1 + 1 ; srcInfo . signalName =
sigName ; srcInfo . sigSourceUUID = 0 ; rtDW . ns05uf10ld . AQHandles =
sdiStartAsyncioQueueCreation ( hDT , & srcInfo , rt_dataMapInfo . mmi .
InstanceMap . fullPath , "eed4764b-7eac-434f-b911-16d0e49b285b" ,
sigComplexity , & sigDims , DIMENSIONS_MODE_FIXED , stCont , "" ) ;
sdiCompleteAsyncioQueueCreation ( rtDW . ns05uf10ld . AQHandles , hDT , &
srcInfo ) ; if ( rtDW . ns05uf10ld . AQHandles ) {
sdiSetSignalSampleTimeString ( rtDW . ns05uf10ld . AQHandles , "1" , 1.0 ,
ssGetTFinal ( rtS ) ) ; sdiSetSignalRefRate ( rtDW . ns05uf10ld . AQHandles ,
0.0 ) ; sdiSetRunStartTime ( rtDW . ns05uf10ld . AQHandles , ssGetTaskTime (
rtS , 1 ) ) ; sdiAsyncRepoSetSignalExportSettings ( rtDW . ns05uf10ld .
AQHandles , 1 , 0 ) ; sdiAsyncRepoSetSignalExportName ( rtDW . ns05uf10ld .
AQHandles , loggedName , origSigName , propName ) ; } sdiFreeLabel ( sigName
) ; sdiFreeLabel ( loggedName ) ; sdiFreeLabel ( origSigName ) ; sdiFreeLabel
( propName ) ; sdiFreeLabel ( blockPath ) ; sdiFreeLabel ( blockSID ) ;
sdiFreeLabel ( subPath ) ; } } if ( ! isStreamoutAlreadyRegistered ) { } } }
} { { { bool isStreamoutAlreadyRegistered = false ; { sdiSignalSourceInfoU
srcInfo ; sdiLabelU loggedName = sdiGetLabelFromChars ( "" ) ; sdiLabelU
origSigName = sdiGetLabelFromChars ( "" ) ; sdiLabelU propName =
sdiGetLabelFromChars ( "" ) ; sdiLabelU blockPath = sdiGetLabelFromChars (
"cstr_simulationEnv/Operator Control" ) ; sdiLabelU blockSID =
sdiGetLabelFromChars ( "" ) ; sdiLabelU subPath = sdiGetLabelFromChars ( "" )
; sdiDims sigDims ; sdiLabelU sigName = sdiGetLabelFromChars ( "" ) ;
sdiAsyncRepoDataTypeHandle hDT = sdiAsyncRepoGetBuiltInDataTypeHandle (
DATA_TYPE_BOOLEAN ) ; { sdiComplexity sigComplexity = REAL ;
sdiSampleTimeContinuity stCont = SAMPLE_TIME_DISCRETE ; int_T sigDimsArray [
1 ] = { 1 } ; sigDims . nDims = 1 ; sigDims . dimensions = sigDimsArray ;
srcInfo . numBlockPathElems = 1 ; srcInfo . fullBlockPath = ( sdiFullBlkPathU
) & blockPath ; srcInfo . SID = ( sdiSignalIDU ) & blockSID ; srcInfo .
subPath = subPath ; srcInfo . portIndex = 2 + 1 ; srcInfo . signalName =
sigName ; srcInfo . sigSourceUUID = 0 ; rtDW . nkxcwijbwx . AQHandles =
sdiStartAsyncioQueueCreation ( hDT , & srcInfo , rt_dataMapInfo . mmi .
InstanceMap . fullPath , "47282b27-508e-46d6-a401-bec8d664858d" ,
sigComplexity , & sigDims , DIMENSIONS_MODE_FIXED , stCont , "" ) ;
sdiCompleteAsyncioQueueCreation ( rtDW . nkxcwijbwx . AQHandles , hDT , &
srcInfo ) ; if ( rtDW . nkxcwijbwx . AQHandles ) {
sdiSetSignalSampleTimeString ( rtDW . nkxcwijbwx . AQHandles , "1" , 1.0 ,
ssGetTFinal ( rtS ) ) ; sdiSetSignalRefRate ( rtDW . nkxcwijbwx . AQHandles ,
0.0 ) ; sdiSetRunStartTime ( rtDW . nkxcwijbwx . AQHandles , ssGetTaskTime (
rtS , 1 ) ) ; sdiAsyncRepoSetSignalExportSettings ( rtDW . nkxcwijbwx .
AQHandles , 1 , 0 ) ; sdiAsyncRepoSetSignalExportName ( rtDW . nkxcwijbwx .
AQHandles , loggedName , origSigName , propName ) ; } sdiFreeLabel ( sigName
) ; sdiFreeLabel ( loggedName ) ; sdiFreeLabel ( origSigName ) ; sdiFreeLabel
( propName ) ; sdiFreeLabel ( blockPath ) ; sdiFreeLabel ( blockSID ) ;
sdiFreeLabel ( subPath ) ; } } if ( ! isStreamoutAlreadyRegistered ) { } } }
} { { { bool isStreamoutAlreadyRegistered = false ; { sdiSignalSourceInfoU
srcInfo ; sdiLabelU loggedName = sdiGetLabelFromChars ( "" ) ; sdiLabelU
origSigName = sdiGetLabelFromChars ( "" ) ; sdiLabelU propName =
sdiGetLabelFromChars ( "" ) ; sdiLabelU blockPath = sdiGetLabelFromChars (
"cstr_simulationEnv/Operator Control" ) ; sdiLabelU blockSID =
sdiGetLabelFromChars ( "" ) ; sdiLabelU subPath = sdiGetLabelFromChars ( "" )
; sdiDims sigDims ; sdiLabelU sigName = sdiGetLabelFromChars ( "" ) ;
sdiAsyncRepoDataTypeHandle hDT = sdiAsyncRepoGetBuiltInDataTypeHandle (
DATA_TYPE_BOOLEAN ) ; { sdiComplexity sigComplexity = REAL ;
sdiSampleTimeContinuity stCont = SAMPLE_TIME_DISCRETE ; int_T sigDimsArray [
1 ] = { 1 } ; sigDims . nDims = 1 ; sigDims . dimensions = sigDimsArray ;
srcInfo . numBlockPathElems = 1 ; srcInfo . fullBlockPath = ( sdiFullBlkPathU
) & blockPath ; srcInfo . SID = ( sdiSignalIDU ) & blockSID ; srcInfo .
subPath = subPath ; srcInfo . portIndex = 3 + 1 ; srcInfo . signalName =
sigName ; srcInfo . sigSourceUUID = 0 ; rtDW . msb5d3me1j . AQHandles =
sdiStartAsyncioQueueCreation ( hDT , & srcInfo , rt_dataMapInfo . mmi .
InstanceMap . fullPath , "4110a1e1-2f38-4045-b43c-b88fbc4f384d" ,
sigComplexity , & sigDims , DIMENSIONS_MODE_FIXED , stCont , "" ) ;
sdiCompleteAsyncioQueueCreation ( rtDW . msb5d3me1j . AQHandles , hDT , &
srcInfo ) ; if ( rtDW . msb5d3me1j . AQHandles ) {
sdiSetSignalSampleTimeString ( rtDW . msb5d3me1j . AQHandles , "1" , 1.0 ,
ssGetTFinal ( rtS ) ) ; sdiSetSignalRefRate ( rtDW . msb5d3me1j . AQHandles ,
0.0 ) ; sdiSetRunStartTime ( rtDW . msb5d3me1j . AQHandles , ssGetTaskTime (
rtS , 1 ) ) ; sdiAsyncRepoSetSignalExportSettings ( rtDW . msb5d3me1j .
AQHandles , 1 , 0 ) ; sdiAsyncRepoSetSignalExportName ( rtDW . msb5d3me1j .
AQHandles , loggedName , origSigName , propName ) ; } sdiFreeLabel ( sigName
) ; sdiFreeLabel ( loggedName ) ; sdiFreeLabel ( origSigName ) ; sdiFreeLabel
( propName ) ; sdiFreeLabel ( blockPath ) ; sdiFreeLabel ( blockSID ) ;
sdiFreeLabel ( subPath ) ; } } if ( ! isStreamoutAlreadyRegistered ) { } } }
} { { { bool isStreamoutAlreadyRegistered = false ; { sdiSignalSourceInfoU
srcInfo ; sdiLabelU loggedName = sdiGetLabelFromChars ( "" ) ; sdiLabelU
origSigName = sdiGetLabelFromChars ( "" ) ; sdiLabelU propName =
sdiGetLabelFromChars ( "" ) ; sdiLabelU blockPath = sdiGetLabelFromChars (
"cstr_simulationEnv/Operator Control" ) ; sdiLabelU blockSID =
sdiGetLabelFromChars ( "" ) ; sdiLabelU subPath = sdiGetLabelFromChars ( "" )
; sdiDims sigDims ; sdiLabelU sigName = sdiGetLabelFromChars ( "" ) ;
sdiAsyncRepoDataTypeHandle hDT = sdiAsyncRepoGetBuiltInDataTypeHandle (
DATA_TYPE_BOOLEAN ) ; { sdiComplexity sigComplexity = REAL ;
sdiSampleTimeContinuity stCont = SAMPLE_TIME_DISCRETE ; int_T sigDimsArray [
1 ] = { 1 } ; sigDims . nDims = 1 ; sigDims . dimensions = sigDimsArray ;
srcInfo . numBlockPathElems = 1 ; srcInfo . fullBlockPath = ( sdiFullBlkPathU
) & blockPath ; srcInfo . SID = ( sdiSignalIDU ) & blockSID ; srcInfo .
subPath = subPath ; srcInfo . portIndex = 4 + 1 ; srcInfo . signalName =
sigName ; srcInfo . sigSourceUUID = 0 ; rtDW . lbtghvt0ml . AQHandles =
sdiStartAsyncioQueueCreation ( hDT , & srcInfo , rt_dataMapInfo . mmi .
InstanceMap . fullPath , "c2e1cc51-3683-4d59-bc1e-f770f063f8ce" ,
sigComplexity , & sigDims , DIMENSIONS_MODE_FIXED , stCont , "" ) ;
sdiCompleteAsyncioQueueCreation ( rtDW . lbtghvt0ml . AQHandles , hDT , &
srcInfo ) ; if ( rtDW . lbtghvt0ml . AQHandles ) {
sdiSetSignalSampleTimeString ( rtDW . lbtghvt0ml . AQHandles , "1" , 1.0 ,
ssGetTFinal ( rtS ) ) ; sdiSetSignalRefRate ( rtDW . lbtghvt0ml . AQHandles ,
0.0 ) ; sdiSetRunStartTime ( rtDW . lbtghvt0ml . AQHandles , ssGetTaskTime (
rtS , 1 ) ) ; sdiAsyncRepoSetSignalExportSettings ( rtDW . lbtghvt0ml .
AQHandles , 1 , 0 ) ; sdiAsyncRepoSetSignalExportName ( rtDW . lbtghvt0ml .
AQHandles , loggedName , origSigName , propName ) ; } sdiFreeLabel ( sigName
) ; sdiFreeLabel ( loggedName ) ; sdiFreeLabel ( origSigName ) ; sdiFreeLabel
( propName ) ; sdiFreeLabel ( blockPath ) ; sdiFreeLabel ( blockSID ) ;
sdiFreeLabel ( subPath ) ; } } if ( ! isStreamoutAlreadyRegistered ) { } } }
} { { { bool isStreamoutAlreadyRegistered = false ; { sdiSignalSourceInfoU
srcInfo ; sdiLabelU loggedName = sdiGetLabelFromChars ( "" ) ; sdiLabelU
origSigName = sdiGetLabelFromChars ( "" ) ; sdiLabelU propName =
sdiGetLabelFromChars ( "" ) ; sdiLabelU blockPath = sdiGetLabelFromChars (
"cstr_simulationEnv/Operator Control" ) ; sdiLabelU blockSID =
sdiGetLabelFromChars ( "" ) ; sdiLabelU subPath = sdiGetLabelFromChars ( "" )
; sdiDims sigDims ; sdiLabelU sigName = sdiGetLabelFromChars ( "" ) ;
sdiAsyncRepoDataTypeHandle hDT = sdiAsyncRepoGetBuiltInDataTypeHandle (
DATA_TYPE_BOOLEAN ) ; { sdiComplexity sigComplexity = REAL ;
sdiSampleTimeContinuity stCont = SAMPLE_TIME_DISCRETE ; int_T sigDimsArray [
1 ] = { 1 } ; sigDims . nDims = 1 ; sigDims . dimensions = sigDimsArray ;
srcInfo . numBlockPathElems = 1 ; srcInfo . fullBlockPath = ( sdiFullBlkPathU
) & blockPath ; srcInfo . SID = ( sdiSignalIDU ) & blockSID ; srcInfo .
subPath = subPath ; srcInfo . portIndex = 5 + 1 ; srcInfo . signalName =
sigName ; srcInfo . sigSourceUUID = 0 ; rtDW . mvgtzq34qx . AQHandles =
sdiStartAsyncioQueueCreation ( hDT , & srcInfo , rt_dataMapInfo . mmi .
InstanceMap . fullPath , "fcd39017-34cb-4e6a-99d2-1178f1babea7" ,
sigComplexity , & sigDims , DIMENSIONS_MODE_FIXED , stCont , "" ) ;
sdiCompleteAsyncioQueueCreation ( rtDW . mvgtzq34qx . AQHandles , hDT , &
srcInfo ) ; if ( rtDW . mvgtzq34qx . AQHandles ) {
sdiSetSignalSampleTimeString ( rtDW . mvgtzq34qx . AQHandles , "1" , 1.0 ,
ssGetTFinal ( rtS ) ) ; sdiSetSignalRefRate ( rtDW . mvgtzq34qx . AQHandles ,
0.0 ) ; sdiSetRunStartTime ( rtDW . mvgtzq34qx . AQHandles , ssGetTaskTime (
rtS , 1 ) ) ; sdiAsyncRepoSetSignalExportSettings ( rtDW . mvgtzq34qx .
AQHandles , 1 , 0 ) ; sdiAsyncRepoSetSignalExportName ( rtDW . mvgtzq34qx .
AQHandles , loggedName , origSigName , propName ) ; } sdiFreeLabel ( sigName
) ; sdiFreeLabel ( loggedName ) ; sdiFreeLabel ( origSigName ) ; sdiFreeLabel
( propName ) ; sdiFreeLabel ( blockPath ) ; sdiFreeLabel ( blockSID ) ;
sdiFreeLabel ( subPath ) ; } } if ( ! isStreamoutAlreadyRegistered ) { } } }
} { { { bool isStreamoutAlreadyRegistered = false ; { sdiSignalSourceInfoU
srcInfo ; sdiLabelU loggedName = sdiGetLabelFromChars ( "" ) ; sdiLabelU
origSigName = sdiGetLabelFromChars ( "" ) ; sdiLabelU propName =
sdiGetLabelFromChars ( "" ) ; sdiLabelU blockPath = sdiGetLabelFromChars (
"cstr_simulationEnv/Operator Control" ) ; sdiLabelU blockSID =
sdiGetLabelFromChars ( "" ) ; sdiLabelU subPath = sdiGetLabelFromChars ( "" )
; sdiDims sigDims ; sdiLabelU sigName = sdiGetLabelFromChars ( "" ) ;
sdiAsyncRepoDataTypeHandle hDT = sdiAsyncRepoGetBuiltInDataTypeHandle (
DATA_TYPE_BOOLEAN ) ; { sdiComplexity sigComplexity = REAL ;
sdiSampleTimeContinuity stCont = SAMPLE_TIME_DISCRETE ; int_T sigDimsArray [
1 ] = { 1 } ; sigDims . nDims = 1 ; sigDims . dimensions = sigDimsArray ;
srcInfo . numBlockPathElems = 1 ; srcInfo . fullBlockPath = ( sdiFullBlkPathU
) & blockPath ; srcInfo . SID = ( sdiSignalIDU ) & blockSID ; srcInfo .
subPath = subPath ; srcInfo . portIndex = 6 + 1 ; srcInfo . signalName =
sigName ; srcInfo . sigSourceUUID = 0 ; rtDW . aosifnfz0v . AQHandles =
sdiStartAsyncioQueueCreation ( hDT , & srcInfo , rt_dataMapInfo . mmi .
InstanceMap . fullPath , "780bd8f5-f0f0-40a1-a975-b16bbbd225d3" ,
sigComplexity , & sigDims , DIMENSIONS_MODE_FIXED , stCont , "" ) ;
sdiCompleteAsyncioQueueCreation ( rtDW . aosifnfz0v . AQHandles , hDT , &
srcInfo ) ; if ( rtDW . aosifnfz0v . AQHandles ) {
sdiSetSignalSampleTimeString ( rtDW . aosifnfz0v . AQHandles , "1" , 1.0 ,
ssGetTFinal ( rtS ) ) ; sdiSetSignalRefRate ( rtDW . aosifnfz0v . AQHandles ,
0.0 ) ; sdiSetRunStartTime ( rtDW . aosifnfz0v . AQHandles , ssGetTaskTime (
rtS , 1 ) ) ; sdiAsyncRepoSetSignalExportSettings ( rtDW . aosifnfz0v .
AQHandles , 1 , 0 ) ; sdiAsyncRepoSetSignalExportName ( rtDW . aosifnfz0v .
AQHandles , loggedName , origSigName , propName ) ; } sdiFreeLabel ( sigName
) ; sdiFreeLabel ( loggedName ) ; sdiFreeLabel ( origSigName ) ; sdiFreeLabel
( propName ) ; sdiFreeLabel ( blockPath ) ; sdiFreeLabel ( blockSID ) ;
sdiFreeLabel ( subPath ) ; } } if ( ! isStreamoutAlreadyRegistered ) { } } }
} { { { bool isStreamoutAlreadyRegistered = false ; { sdiSignalSourceInfoU
srcInfo ; sdiLabelU loggedName = sdiGetLabelFromChars ( "" ) ; sdiLabelU
origSigName = sdiGetLabelFromChars ( "" ) ; sdiLabelU propName =
sdiGetLabelFromChars ( "" ) ; sdiLabelU blockPath = sdiGetLabelFromChars (
"cstr_simulationEnv/Operator Control" ) ; sdiLabelU blockSID =
sdiGetLabelFromChars ( "" ) ; sdiLabelU subPath = sdiGetLabelFromChars ( "" )
; sdiDims sigDims ; sdiLabelU sigName = sdiGetLabelFromChars ( "" ) ;
sdiAsyncRepoDataTypeHandle hDT = sdiAsyncRepoGetBuiltInDataTypeHandle (
DATA_TYPE_BOOLEAN ) ; { sdiComplexity sigComplexity = REAL ;
sdiSampleTimeContinuity stCont = SAMPLE_TIME_DISCRETE ; int_T sigDimsArray [
1 ] = { 1 } ; sigDims . nDims = 1 ; sigDims . dimensions = sigDimsArray ;
srcInfo . numBlockPathElems = 1 ; srcInfo . fullBlockPath = ( sdiFullBlkPathU
) & blockPath ; srcInfo . SID = ( sdiSignalIDU ) & blockSID ; srcInfo .
subPath = subPath ; srcInfo . portIndex = 7 + 1 ; srcInfo . signalName =
sigName ; srcInfo . sigSourceUUID = 0 ; rtDW . lpahj2azln . AQHandles =
sdiStartAsyncioQueueCreation ( hDT , & srcInfo , rt_dataMapInfo . mmi .
InstanceMap . fullPath , "780d514e-0992-4acd-918b-b21aacf84ef9" ,
sigComplexity , & sigDims , DIMENSIONS_MODE_FIXED , stCont , "" ) ;
sdiCompleteAsyncioQueueCreation ( rtDW . lpahj2azln . AQHandles , hDT , &
srcInfo ) ; if ( rtDW . lpahj2azln . AQHandles ) {
sdiSetSignalSampleTimeString ( rtDW . lpahj2azln . AQHandles , "1" , 1.0 ,
ssGetTFinal ( rtS ) ) ; sdiSetSignalRefRate ( rtDW . lpahj2azln . AQHandles ,
0.0 ) ; sdiSetRunStartTime ( rtDW . lpahj2azln . AQHandles , ssGetTaskTime (
rtS , 1 ) ) ; sdiAsyncRepoSetSignalExportSettings ( rtDW . lpahj2azln .
AQHandles , 1 , 0 ) ; sdiAsyncRepoSetSignalExportName ( rtDW . lpahj2azln .
AQHandles , loggedName , origSigName , propName ) ; } sdiFreeLabel ( sigName
) ; sdiFreeLabel ( loggedName ) ; sdiFreeLabel ( origSigName ) ; sdiFreeLabel
( propName ) ; sdiFreeLabel ( blockPath ) ; sdiFreeLabel ( blockSID ) ;
sdiFreeLabel ( subPath ) ; } } if ( ! isStreamoutAlreadyRegistered ) { } } }
} { { { bool isStreamoutAlreadyRegistered = false ; { sdiSignalSourceInfoU
srcInfo ; sdiLabelU loggedName = sdiGetLabelFromChars ( "" ) ; sdiLabelU
origSigName = sdiGetLabelFromChars ( "" ) ; sdiLabelU propName =
sdiGetLabelFromChars ( "" ) ; sdiLabelU blockPath = sdiGetLabelFromChars (
"cstr_simulationEnv/SIF" ) ; sdiLabelU blockSID = sdiGetLabelFromChars ( "" )
; sdiLabelU subPath = sdiGetLabelFromChars ( "" ) ; sdiDims sigDims ;
sdiLabelU sigName = sdiGetLabelFromChars ( "" ) ; sdiAsyncRepoDataTypeHandle
hDT = sdiAsyncRepoGetBuiltInDataTypeHandle ( DATA_TYPE_DOUBLE ) ; {
sdiComplexity sigComplexity = REAL ; sdiSampleTimeContinuity stCont =
SAMPLE_TIME_DISCRETE ; int_T sigDimsArray [ 1 ] = { 1 } ; sigDims . nDims = 1
; sigDims . dimensions = sigDimsArray ; srcInfo . numBlockPathElems = 1 ;
srcInfo . fullBlockPath = ( sdiFullBlkPathU ) & blockPath ; srcInfo . SID = (
sdiSignalIDU ) & blockSID ; srcInfo . subPath = subPath ; srcInfo . portIndex
= 0 + 1 ; srcInfo . signalName = sigName ; srcInfo . sigSourceUUID = 0 ; rtDW
. pyvmjo2bqw . AQHandles = sdiStartAsyncioQueueCreation ( hDT , & srcInfo ,
rt_dataMapInfo . mmi . InstanceMap . fullPath ,
"b94b00ec-1d2f-4b08-ad55-ee38a5b42b33" , sigComplexity , & sigDims ,
DIMENSIONS_MODE_FIXED , stCont , "" ) ; sdiCompleteAsyncioQueueCreation (
rtDW . pyvmjo2bqw . AQHandles , hDT , & srcInfo ) ; if ( rtDW . pyvmjo2bqw .
AQHandles ) { sdiSetSignalSampleTimeString ( rtDW . pyvmjo2bqw . AQHandles ,
"1" , 1.0 , ssGetTFinal ( rtS ) ) ; sdiSetSignalRefRate ( rtDW . pyvmjo2bqw .
AQHandles , 0.0 ) ; sdiSetRunStartTime ( rtDW . pyvmjo2bqw . AQHandles ,
ssGetTaskTime ( rtS , 1 ) ) ; sdiAsyncRepoSetSignalExportSettings ( rtDW .
pyvmjo2bqw . AQHandles , 1 , 0 ) ; sdiAsyncRepoSetSignalExportName ( rtDW .
pyvmjo2bqw . AQHandles , loggedName , origSigName , propName ) ; }
sdiFreeLabel ( sigName ) ; sdiFreeLabel ( loggedName ) ; sdiFreeLabel (
origSigName ) ; sdiFreeLabel ( propName ) ; sdiFreeLabel ( blockPath ) ;
sdiFreeLabel ( blockSID ) ; sdiFreeLabel ( subPath ) ; } } if ( !
isStreamoutAlreadyRegistered ) { } } } } { { { bool
isStreamoutAlreadyRegistered = false ; { sdiSignalSourceInfoU srcInfo ;
sdiLabelU loggedName = sdiGetLabelFromChars ( "" ) ; sdiLabelU origSigName =
sdiGetLabelFromChars ( "" ) ; sdiLabelU propName = sdiGetLabelFromChars ( ""
) ; sdiLabelU blockPath = sdiGetLabelFromChars ( "cstr_simulationEnv/SIF" ) ;
sdiLabelU blockSID = sdiGetLabelFromChars ( "" ) ; sdiLabelU subPath =
sdiGetLabelFromChars ( "" ) ; sdiDims sigDims ; sdiLabelU sigName =
sdiGetLabelFromChars ( "" ) ; sdiAsyncRepoDataTypeHandle hDT =
sdiAsyncRepoGetBuiltInDataTypeHandle ( DATA_TYPE_DOUBLE ) ; { sdiComplexity
sigComplexity = REAL ; sdiSampleTimeContinuity stCont = SAMPLE_TIME_DISCRETE
; int_T sigDimsArray [ 1 ] = { 1 } ; sigDims . nDims = 1 ; sigDims .
dimensions = sigDimsArray ; srcInfo . numBlockPathElems = 1 ; srcInfo .
fullBlockPath = ( sdiFullBlkPathU ) & blockPath ; srcInfo . SID = (
sdiSignalIDU ) & blockSID ; srcInfo . subPath = subPath ; srcInfo . portIndex
= 1 + 1 ; srcInfo . signalName = sigName ; srcInfo . sigSourceUUID = 0 ; rtDW
. mcwiq2fdf3 . AQHandles = sdiStartAsyncioQueueCreation ( hDT , & srcInfo ,
rt_dataMapInfo . mmi . InstanceMap . fullPath ,
"dd8dd141-6045-49ed-abcf-a874a6ef6170" , sigComplexity , & sigDims ,
DIMENSIONS_MODE_FIXED , stCont , "" ) ; sdiCompleteAsyncioQueueCreation (
rtDW . mcwiq2fdf3 . AQHandles , hDT , & srcInfo ) ; if ( rtDW . mcwiq2fdf3 .
AQHandles ) { sdiSetSignalSampleTimeString ( rtDW . mcwiq2fdf3 . AQHandles ,
"1" , 1.0 , ssGetTFinal ( rtS ) ) ; sdiSetSignalRefRate ( rtDW . mcwiq2fdf3 .
AQHandles , 0.0 ) ; sdiSetRunStartTime ( rtDW . mcwiq2fdf3 . AQHandles ,
ssGetTaskTime ( rtS , 1 ) ) ; sdiAsyncRepoSetSignalExportSettings ( rtDW .
mcwiq2fdf3 . AQHandles , 1 , 0 ) ; sdiAsyncRepoSetSignalExportName ( rtDW .
mcwiq2fdf3 . AQHandles , loggedName , origSigName , propName ) ; }
sdiFreeLabel ( sigName ) ; sdiFreeLabel ( loggedName ) ; sdiFreeLabel (
origSigName ) ; sdiFreeLabel ( propName ) ; sdiFreeLabel ( blockPath ) ;
sdiFreeLabel ( blockSID ) ; sdiFreeLabel ( subPath ) ; } } if ( !
isStreamoutAlreadyRegistered ) { } } } } { { { bool
isStreamoutAlreadyRegistered = false ; { sdiSignalSourceInfoU srcInfo ;
sdiLabelU loggedName = sdiGetLabelFromChars ( "" ) ; sdiLabelU origSigName =
sdiGetLabelFromChars ( "" ) ; sdiLabelU propName = sdiGetLabelFromChars ( ""
) ; sdiLabelU blockPath = sdiGetLabelFromChars ( "cstr_simulationEnv/SIF" ) ;
sdiLabelU blockSID = sdiGetLabelFromChars ( "" ) ; sdiLabelU subPath =
sdiGetLabelFromChars ( "" ) ; sdiDims sigDims ; sdiLabelU sigName =
sdiGetLabelFromChars ( "" ) ; sdiAsyncRepoDataTypeHandle hDT =
sdiAsyncRepoGetBuiltInDataTypeHandle ( DATA_TYPE_DOUBLE ) ; { sdiComplexity
sigComplexity = REAL ; sdiSampleTimeContinuity stCont = SAMPLE_TIME_DISCRETE
; int_T sigDimsArray [ 1 ] = { 1 } ; sigDims . nDims = 1 ; sigDims .
dimensions = sigDimsArray ; srcInfo . numBlockPathElems = 1 ; srcInfo .
fullBlockPath = ( sdiFullBlkPathU ) & blockPath ; srcInfo . SID = (
sdiSignalIDU ) & blockSID ; srcInfo . subPath = subPath ; srcInfo . portIndex
= 2 + 1 ; srcInfo . signalName = sigName ; srcInfo . sigSourceUUID = 0 ; rtDW
. jarmeshqgo . AQHandles = sdiStartAsyncioQueueCreation ( hDT , & srcInfo ,
rt_dataMapInfo . mmi . InstanceMap . fullPath ,
"da369f1b-f938-49e1-b568-65e3f7baed96" , sigComplexity , & sigDims ,
DIMENSIONS_MODE_FIXED , stCont , "" ) ; sdiCompleteAsyncioQueueCreation (
rtDW . jarmeshqgo . AQHandles , hDT , & srcInfo ) ; if ( rtDW . jarmeshqgo .
AQHandles ) { sdiSetSignalSampleTimeString ( rtDW . jarmeshqgo . AQHandles ,
"1" , 1.0 , ssGetTFinal ( rtS ) ) ; sdiSetSignalRefRate ( rtDW . jarmeshqgo .
AQHandles , 0.0 ) ; sdiSetRunStartTime ( rtDW . jarmeshqgo . AQHandles ,
ssGetTaskTime ( rtS , 1 ) ) ; sdiAsyncRepoSetSignalExportSettings ( rtDW .
jarmeshqgo . AQHandles , 1 , 0 ) ; sdiAsyncRepoSetSignalExportName ( rtDW .
jarmeshqgo . AQHandles , loggedName , origSigName , propName ) ; }
sdiFreeLabel ( sigName ) ; sdiFreeLabel ( loggedName ) ; sdiFreeLabel (
origSigName ) ; sdiFreeLabel ( propName ) ; sdiFreeLabel ( blockPath ) ;
sdiFreeLabel ( blockSID ) ; sdiFreeLabel ( subPath ) ; } } if ( !
isStreamoutAlreadyRegistered ) { } } } } { { { bool
isStreamoutAlreadyRegistered = false ; { sdiSignalSourceInfoU srcInfo ;
sdiLabelU loggedName = sdiGetLabelFromChars ( "" ) ; sdiLabelU origSigName =
sdiGetLabelFromChars ( "" ) ; sdiLabelU propName = sdiGetLabelFromChars ( ""
) ; sdiLabelU blockPath = sdiGetLabelFromChars ( "cstr_simulationEnv/SIF" ) ;
sdiLabelU blockSID = sdiGetLabelFromChars ( "" ) ; sdiLabelU subPath =
sdiGetLabelFromChars ( "" ) ; sdiDims sigDims ; sdiLabelU sigName =
sdiGetLabelFromChars ( "" ) ; sdiAsyncRepoDataTypeHandle hDT =
sdiAsyncRepoGetBuiltInDataTypeHandle ( DATA_TYPE_DOUBLE ) ; { sdiComplexity
sigComplexity = REAL ; sdiSampleTimeContinuity stCont = SAMPLE_TIME_DISCRETE
; int_T sigDimsArray [ 1 ] = { 1 } ; sigDims . nDims = 1 ; sigDims .
dimensions = sigDimsArray ; srcInfo . numBlockPathElems = 1 ; srcInfo .
fullBlockPath = ( sdiFullBlkPathU ) & blockPath ; srcInfo . SID = (
sdiSignalIDU ) & blockSID ; srcInfo . subPath = subPath ; srcInfo . portIndex
= 3 + 1 ; srcInfo . signalName = sigName ; srcInfo . sigSourceUUID = 0 ; rtDW
. ltulzml5oa . AQHandles = sdiStartAsyncioQueueCreation ( hDT , & srcInfo ,
rt_dataMapInfo . mmi . InstanceMap . fullPath ,
"29a3372f-88df-49b9-b053-3f48c8b93c27" , sigComplexity , & sigDims ,
DIMENSIONS_MODE_FIXED , stCont , "" ) ; sdiCompleteAsyncioQueueCreation (
rtDW . ltulzml5oa . AQHandles , hDT , & srcInfo ) ; if ( rtDW . ltulzml5oa .
AQHandles ) { sdiSetSignalSampleTimeString ( rtDW . ltulzml5oa . AQHandles ,
"1" , 1.0 , ssGetTFinal ( rtS ) ) ; sdiSetSignalRefRate ( rtDW . ltulzml5oa .
AQHandles , 0.0 ) ; sdiSetRunStartTime ( rtDW . ltulzml5oa . AQHandles ,
ssGetTaskTime ( rtS , 1 ) ) ; sdiAsyncRepoSetSignalExportSettings ( rtDW .
ltulzml5oa . AQHandles , 1 , 0 ) ; sdiAsyncRepoSetSignalExportName ( rtDW .
ltulzml5oa . AQHandles , loggedName , origSigName , propName ) ; }
sdiFreeLabel ( sigName ) ; sdiFreeLabel ( loggedName ) ; sdiFreeLabel (
origSigName ) ; sdiFreeLabel ( propName ) ; sdiFreeLabel ( blockPath ) ;
sdiFreeLabel ( blockSID ) ; sdiFreeLabel ( subPath ) ; } } if ( !
isStreamoutAlreadyRegistered ) { } } } } { { { bool
isStreamoutAlreadyRegistered = false ; { sdiSignalSourceInfoU srcInfo ;
sdiLabelU loggedName = sdiGetLabelFromChars ( "" ) ; sdiLabelU origSigName =
sdiGetLabelFromChars ( "" ) ; sdiLabelU propName = sdiGetLabelFromChars ( ""
) ; sdiLabelU blockPath = sdiGetLabelFromChars ( "cstr_simulationEnv/SIF" ) ;
sdiLabelU blockSID = sdiGetLabelFromChars ( "" ) ; sdiLabelU subPath =
sdiGetLabelFromChars ( "" ) ; sdiDims sigDims ; sdiLabelU sigName =
sdiGetLabelFromChars ( "" ) ; sdiAsyncRepoDataTypeHandle hDT =
sdiAsyncRepoGetBuiltInDataTypeHandle ( DATA_TYPE_DOUBLE ) ; { sdiComplexity
sigComplexity = REAL ; sdiSampleTimeContinuity stCont = SAMPLE_TIME_DISCRETE
; int_T sigDimsArray [ 1 ] = { 1 } ; sigDims . nDims = 1 ; sigDims .
dimensions = sigDimsArray ; srcInfo . numBlockPathElems = 1 ; srcInfo .
fullBlockPath = ( sdiFullBlkPathU ) & blockPath ; srcInfo . SID = (
sdiSignalIDU ) & blockSID ; srcInfo . subPath = subPath ; srcInfo . portIndex
= 4 + 1 ; srcInfo . signalName = sigName ; srcInfo . sigSourceUUID = 0 ; rtDW
. lvl5uvsvj2 . AQHandles = sdiStartAsyncioQueueCreation ( hDT , & srcInfo ,
rt_dataMapInfo . mmi . InstanceMap . fullPath ,
"3252d530-1e10-4d91-b6ba-869861d9cba9" , sigComplexity , & sigDims ,
DIMENSIONS_MODE_FIXED , stCont , "" ) ; sdiCompleteAsyncioQueueCreation (
rtDW . lvl5uvsvj2 . AQHandles , hDT , & srcInfo ) ; if ( rtDW . lvl5uvsvj2 .
AQHandles ) { sdiSetSignalSampleTimeString ( rtDW . lvl5uvsvj2 . AQHandles ,
"1" , 1.0 , ssGetTFinal ( rtS ) ) ; sdiSetSignalRefRate ( rtDW . lvl5uvsvj2 .
AQHandles , 0.0 ) ; sdiSetRunStartTime ( rtDW . lvl5uvsvj2 . AQHandles ,
ssGetTaskTime ( rtS , 1 ) ) ; sdiAsyncRepoSetSignalExportSettings ( rtDW .
lvl5uvsvj2 . AQHandles , 1 , 0 ) ; sdiAsyncRepoSetSignalExportName ( rtDW .
lvl5uvsvj2 . AQHandles , loggedName , origSigName , propName ) ; }
sdiFreeLabel ( sigName ) ; sdiFreeLabel ( loggedName ) ; sdiFreeLabel (
origSigName ) ; sdiFreeLabel ( propName ) ; sdiFreeLabel ( blockPath ) ;
sdiFreeLabel ( blockSID ) ; sdiFreeLabel ( subPath ) ; } } if ( !
isStreamoutAlreadyRegistered ) { } } } } { { { bool
isStreamoutAlreadyRegistered = false ; { sdiSignalSourceInfoU srcInfo ;
sdiLabelU loggedName = sdiGetLabelFromChars ( "" ) ; sdiLabelU origSigName =
sdiGetLabelFromChars ( "" ) ; sdiLabelU propName = sdiGetLabelFromChars ( ""
) ; sdiLabelU blockPath = sdiGetLabelFromChars (
"cstr_simulationEnv/State-based Control System" ) ; sdiLabelU blockSID =
sdiGetLabelFromChars ( "" ) ; sdiLabelU subPath = sdiGetLabelFromChars ( "" )
; sdiDims sigDims ; sdiLabelU sigName = sdiGetLabelFromChars ( "" ) ;
sdiAsyncRepoDataTypeHandle hDT = sdiAsyncRepoGetBuiltInDataTypeHandle (
DATA_TYPE_BOOLEAN ) ; { sdiComplexity sigComplexity = REAL ;
sdiSampleTimeContinuity stCont = SAMPLE_TIME_DISCRETE ; int_T sigDimsArray [
1 ] = { 1 } ; sigDims . nDims = 1 ; sigDims . dimensions = sigDimsArray ;
srcInfo . numBlockPathElems = 1 ; srcInfo . fullBlockPath = ( sdiFullBlkPathU
) & blockPath ; srcInfo . SID = ( sdiSignalIDU ) & blockSID ; srcInfo .
subPath = subPath ; srcInfo . portIndex = 2 + 1 ; srcInfo . signalName =
sigName ; srcInfo . sigSourceUUID = 0 ; rtDW . inyhtmatu2 . AQHandles =
sdiStartAsyncioQueueCreation ( hDT , & srcInfo , rt_dataMapInfo . mmi .
InstanceMap . fullPath , "c490b5ea-227a-4770-91ff-a830ebc0dd52" ,
sigComplexity , & sigDims , DIMENSIONS_MODE_FIXED , stCont , "" ) ;
sdiCompleteAsyncioQueueCreation ( rtDW . inyhtmatu2 . AQHandles , hDT , &
srcInfo ) ; if ( rtDW . inyhtmatu2 . AQHandles ) {
sdiSetSignalSampleTimeString ( rtDW . inyhtmatu2 . AQHandles , "1" , 1.0 ,
ssGetTFinal ( rtS ) ) ; sdiSetSignalRefRate ( rtDW . inyhtmatu2 . AQHandles ,
0.0 ) ; sdiSetRunStartTime ( rtDW . inyhtmatu2 . AQHandles , ssGetTaskTime (
rtS , 1 ) ) ; sdiAsyncRepoSetSignalExportSettings ( rtDW . inyhtmatu2 .
AQHandles , 1 , 0 ) ; sdiAsyncRepoSetSignalExportName ( rtDW . inyhtmatu2 .
AQHandles , loggedName , origSigName , propName ) ; } sdiFreeLabel ( sigName
) ; sdiFreeLabel ( loggedName ) ; sdiFreeLabel ( origSigName ) ; sdiFreeLabel
( propName ) ; sdiFreeLabel ( blockPath ) ; sdiFreeLabel ( blockSID ) ;
sdiFreeLabel ( subPath ) ; } } if ( ! isStreamoutAlreadyRegistered ) { } } }
} { { { bool isStreamoutAlreadyRegistered = false ; { sdiSignalSourceInfoU
srcInfo ; sdiLabelU loggedName = sdiGetLabelFromChars ( "" ) ; sdiLabelU
origSigName = sdiGetLabelFromChars ( "" ) ; sdiLabelU propName =
sdiGetLabelFromChars ( "" ) ; sdiLabelU blockPath = sdiGetLabelFromChars (
"cstr_simulationEnv/State-based Control System" ) ; sdiLabelU blockSID =
sdiGetLabelFromChars ( "" ) ; sdiLabelU subPath = sdiGetLabelFromChars ( "" )
; sdiDims sigDims ; sdiLabelU sigName = sdiGetLabelFromChars ( "" ) ;
sdiAsyncRepoDataTypeHandle hDT = sdiAsyncRepoGetBuiltInDataTypeHandle (
DATA_TYPE_BOOLEAN ) ; { sdiComplexity sigComplexity = REAL ;
sdiSampleTimeContinuity stCont = SAMPLE_TIME_DISCRETE ; int_T sigDimsArray [
1 ] = { 1 } ; sigDims . nDims = 1 ; sigDims . dimensions = sigDimsArray ;
srcInfo . numBlockPathElems = 1 ; srcInfo . fullBlockPath = ( sdiFullBlkPathU
) & blockPath ; srcInfo . SID = ( sdiSignalIDU ) & blockSID ; srcInfo .
subPath = subPath ; srcInfo . portIndex = 3 + 1 ; srcInfo . signalName =
sigName ; srcInfo . sigSourceUUID = 0 ; rtDW . ah0o3rwxbv . AQHandles =
sdiStartAsyncioQueueCreation ( hDT , & srcInfo , rt_dataMapInfo . mmi .
InstanceMap . fullPath , "448e5d5b-962e-4dfa-8e66-df3d2410d205" ,
sigComplexity , & sigDims , DIMENSIONS_MODE_FIXED , stCont , "" ) ;
sdiCompleteAsyncioQueueCreation ( rtDW . ah0o3rwxbv . AQHandles , hDT , &
srcInfo ) ; if ( rtDW . ah0o3rwxbv . AQHandles ) {
sdiSetSignalSampleTimeString ( rtDW . ah0o3rwxbv . AQHandles , "1" , 1.0 ,
ssGetTFinal ( rtS ) ) ; sdiSetSignalRefRate ( rtDW . ah0o3rwxbv . AQHandles ,
0.0 ) ; sdiSetRunStartTime ( rtDW . ah0o3rwxbv . AQHandles , ssGetTaskTime (
rtS , 1 ) ) ; sdiAsyncRepoSetSignalExportSettings ( rtDW . ah0o3rwxbv .
AQHandles , 1 , 0 ) ; sdiAsyncRepoSetSignalExportName ( rtDW . ah0o3rwxbv .
AQHandles , loggedName , origSigName , propName ) ; } sdiFreeLabel ( sigName
) ; sdiFreeLabel ( loggedName ) ; sdiFreeLabel ( origSigName ) ; sdiFreeLabel
( propName ) ; sdiFreeLabel ( blockPath ) ; sdiFreeLabel ( blockSID ) ;
sdiFreeLabel ( subPath ) ; } } if ( ! isStreamoutAlreadyRegistered ) { } } }
} { { { bool isStreamoutAlreadyRegistered = false ; { sdiSignalSourceInfoU
srcInfo ; sdiLabelU loggedName = sdiGetLabelFromChars ( "" ) ; sdiLabelU
origSigName = sdiGetLabelFromChars ( "" ) ; sdiLabelU propName =
sdiGetLabelFromChars ( "" ) ; sdiLabelU blockPath = sdiGetLabelFromChars (
"cstr_simulationEnv/State-based Control System" ) ; sdiLabelU blockSID =
sdiGetLabelFromChars ( "" ) ; sdiLabelU subPath = sdiGetLabelFromChars ( "" )
; sdiDims sigDims ; sdiLabelU sigName = sdiGetLabelFromChars ( "" ) ;
sdiAsyncRepoDataTypeHandle hDT = sdiAsyncRepoGetBuiltInDataTypeHandle (
DATA_TYPE_BOOLEAN ) ; { sdiComplexity sigComplexity = REAL ;
sdiSampleTimeContinuity stCont = SAMPLE_TIME_DISCRETE ; int_T sigDimsArray [
1 ] = { 1 } ; sigDims . nDims = 1 ; sigDims . dimensions = sigDimsArray ;
srcInfo . numBlockPathElems = 1 ; srcInfo . fullBlockPath = ( sdiFullBlkPathU
) & blockPath ; srcInfo . SID = ( sdiSignalIDU ) & blockSID ; srcInfo .
subPath = subPath ; srcInfo . portIndex = 4 + 1 ; srcInfo . signalName =
sigName ; srcInfo . sigSourceUUID = 0 ; rtDW . flebub5s5m . AQHandles =
sdiStartAsyncioQueueCreation ( hDT , & srcInfo , rt_dataMapInfo . mmi .
InstanceMap . fullPath , "eaf09dd5-ad95-4de1-9f27-4675dc98e5c5" ,
sigComplexity , & sigDims , DIMENSIONS_MODE_FIXED , stCont , "" ) ;
sdiCompleteAsyncioQueueCreation ( rtDW . flebub5s5m . AQHandles , hDT , &
srcInfo ) ; if ( rtDW . flebub5s5m . AQHandles ) {
sdiSetSignalSampleTimeString ( rtDW . flebub5s5m . AQHandles , "1" , 1.0 ,
ssGetTFinal ( rtS ) ) ; sdiSetSignalRefRate ( rtDW . flebub5s5m . AQHandles ,
0.0 ) ; sdiSetRunStartTime ( rtDW . flebub5s5m . AQHandles , ssGetTaskTime (
rtS , 1 ) ) ; sdiAsyncRepoSetSignalExportSettings ( rtDW . flebub5s5m .
AQHandles , 1 , 0 ) ; sdiAsyncRepoSetSignalExportName ( rtDW . flebub5s5m .
AQHandles , loggedName , origSigName , propName ) ; } sdiFreeLabel ( sigName
) ; sdiFreeLabel ( loggedName ) ; sdiFreeLabel ( origSigName ) ; sdiFreeLabel
( propName ) ; sdiFreeLabel ( blockPath ) ; sdiFreeLabel ( blockSID ) ;
sdiFreeLabel ( subPath ) ; } } if ( ! isStreamoutAlreadyRegistered ) { } } }
} { int_T numCols = 2 ; rtDW . e3pcjst2gf . LoggedData = rt_CreateLogVar (
ssGetRTWLogInfo ( rtS ) , ssGetTStart ( rtS ) , ssGetTFinal ( rtS ) , 0.0 , (
& ssGetErrorStatus ( rtS ) ) , "ScopeData5" , SS_DOUBLE , 0 , 0 , 0 , 2 , 1 ,
( int_T * ) & numCols , NO_LOGVALDIMS , ( NULL ) , ( NULL ) , 0 , 1 , 1.0 , 1
) ; if ( rtDW . e3pcjst2gf . LoggedData == ( NULL ) ) return ; } { { { bool
isStreamoutAlreadyRegistered = false ; { sdiSignalSourceInfoU srcInfo ;
sdiLabelU loggedName = sdiGetLabelFromChars ( "" ) ; sdiLabelU origSigName =
sdiGetLabelFromChars ( "" ) ; sdiLabelU propName = sdiGetLabelFromChars ( ""
) ; sdiLabelU blockPath = sdiGetLabelFromChars (
"cstr_simulationEnv/CSTR_1 Simulation Model + Regulatory Control/Demux" ) ;
sdiLabelU blockSID = sdiGetLabelFromChars ( "" ) ; sdiLabelU subPath =
sdiGetLabelFromChars ( "" ) ; sdiDims sigDims ; sdiLabelU sigName =
sdiGetLabelFromChars ( "" ) ; sdiAsyncRepoDataTypeHandle hDT =
sdiAsyncRepoGetBuiltInDataTypeHandle ( DATA_TYPE_DOUBLE ) ; { sdiComplexity
sigComplexity = REAL ; sdiSampleTimeContinuity stCont =
SAMPLE_TIME_CONTINUOUS ; int_T sigDimsArray [ 1 ] = { 1 } ; sigDims . nDims =
1 ; sigDims . dimensions = sigDimsArray ; srcInfo . numBlockPathElems = 1 ;
srcInfo . fullBlockPath = ( sdiFullBlkPathU ) & blockPath ; srcInfo . SID = (
sdiSignalIDU ) & blockSID ; srcInfo . subPath = subPath ; srcInfo . portIndex
= 0 + 1 ; srcInfo . signalName = sigName ; srcInfo . sigSourceUUID = 0 ; rtDW
. j3e0f44doy . AQHandles = sdiStartAsyncioQueueCreation ( hDT , & srcInfo ,
rt_dataMapInfo . mmi . InstanceMap . fullPath ,
"cdb5a4c1-a011-427f-aeb8-e0e2abb03887" , sigComplexity , & sigDims ,
DIMENSIONS_MODE_FIXED , stCont , "" ) ; sdiCompleteAsyncioQueueCreation (
rtDW . j3e0f44doy . AQHandles , hDT , & srcInfo ) ; if ( rtDW . j3e0f44doy .
AQHandles ) { sdiSetSignalSampleTimeString ( rtDW . j3e0f44doy . AQHandles ,
"1" , 1.0 , ssGetTFinal ( rtS ) ) ; sdiSetSignalRefRate ( rtDW . j3e0f44doy .
AQHandles , 0.0 ) ; sdiSetRunStartTime ( rtDW . j3e0f44doy . AQHandles ,
ssGetTaskTime ( rtS , 1 ) ) ; sdiAsyncRepoSetSignalExportSettings ( rtDW .
j3e0f44doy . AQHandles , 1 , 0 ) ; sdiAsyncRepoSetSignalExportName ( rtDW .
j3e0f44doy . AQHandles , loggedName , origSigName , propName ) ; }
sdiFreeLabel ( sigName ) ; sdiFreeLabel ( loggedName ) ; sdiFreeLabel (
origSigName ) ; sdiFreeLabel ( propName ) ; sdiFreeLabel ( blockPath ) ;
sdiFreeLabel ( blockSID ) ; sdiFreeLabel ( subPath ) ; } } if ( !
isStreamoutAlreadyRegistered ) { } } } } { { { bool
isStreamoutAlreadyRegistered = false ; { sdiSignalSourceInfoU srcInfo ;
sdiLabelU loggedName = sdiGetLabelFromChars ( "" ) ; sdiLabelU origSigName =
sdiGetLabelFromChars ( "" ) ; sdiLabelU propName = sdiGetLabelFromChars ( ""
) ; sdiLabelU blockPath = sdiGetLabelFromChars (
"cstr_simulationEnv/CSTR_1 Simulation Model + Regulatory Control/Demux" ) ;
sdiLabelU blockSID = sdiGetLabelFromChars ( "" ) ; sdiLabelU subPath =
sdiGetLabelFromChars ( "" ) ; sdiDims sigDims ; sdiLabelU sigName =
sdiGetLabelFromChars ( "" ) ; sdiAsyncRepoDataTypeHandle hDT =
sdiAsyncRepoGetBuiltInDataTypeHandle ( DATA_TYPE_DOUBLE ) ; { sdiComplexity
sigComplexity = REAL ; sdiSampleTimeContinuity stCont =
SAMPLE_TIME_CONTINUOUS ; int_T sigDimsArray [ 1 ] = { 1 } ; sigDims . nDims =
1 ; sigDims . dimensions = sigDimsArray ; srcInfo . numBlockPathElems = 1 ;
srcInfo . fullBlockPath = ( sdiFullBlkPathU ) & blockPath ; srcInfo . SID = (
sdiSignalIDU ) & blockSID ; srcInfo . subPath = subPath ; srcInfo . portIndex
= 1 + 1 ; srcInfo . signalName = sigName ; srcInfo . sigSourceUUID = 0 ; rtDW
. oot0srnoki . AQHandles = sdiStartAsyncioQueueCreation ( hDT , & srcInfo ,
rt_dataMapInfo . mmi . InstanceMap . fullPath ,
"e37db432-e12a-4e18-9492-f6226ec223de" , sigComplexity , & sigDims ,
DIMENSIONS_MODE_FIXED , stCont , "" ) ; sdiCompleteAsyncioQueueCreation (
rtDW . oot0srnoki . AQHandles , hDT , & srcInfo ) ; if ( rtDW . oot0srnoki .
AQHandles ) { sdiSetSignalSampleTimeString ( rtDW . oot0srnoki . AQHandles ,
"1" , 1.0 , ssGetTFinal ( rtS ) ) ; sdiSetSignalRefRate ( rtDW . oot0srnoki .
AQHandles , 0.0 ) ; sdiSetRunStartTime ( rtDW . oot0srnoki . AQHandles ,
ssGetTaskTime ( rtS , 1 ) ) ; sdiAsyncRepoSetSignalExportSettings ( rtDW .
oot0srnoki . AQHandles , 1 , 0 ) ; sdiAsyncRepoSetSignalExportName ( rtDW .
oot0srnoki . AQHandles , loggedName , origSigName , propName ) ; }
sdiFreeLabel ( sigName ) ; sdiFreeLabel ( loggedName ) ; sdiFreeLabel (
origSigName ) ; sdiFreeLabel ( propName ) ; sdiFreeLabel ( blockPath ) ;
sdiFreeLabel ( blockSID ) ; sdiFreeLabel ( subPath ) ; } } if ( !
isStreamoutAlreadyRegistered ) { } } } } { { { bool
isStreamoutAlreadyRegistered = false ; { sdiSignalSourceInfoU srcInfo ;
sdiLabelU loggedName = sdiGetLabelFromChars ( "" ) ; sdiLabelU origSigName =
sdiGetLabelFromChars ( "" ) ; sdiLabelU propName = sdiGetLabelFromChars ( ""
) ; sdiLabelU blockPath = sdiGetLabelFromChars (
"cstr_simulationEnv/CSTR_1 Simulation Model + Regulatory Control/Demux" ) ;
sdiLabelU blockSID = sdiGetLabelFromChars ( "" ) ; sdiLabelU subPath =
sdiGetLabelFromChars ( "" ) ; sdiDims sigDims ; sdiLabelU sigName =
sdiGetLabelFromChars ( "" ) ; sdiAsyncRepoDataTypeHandle hDT =
sdiAsyncRepoGetBuiltInDataTypeHandle ( DATA_TYPE_DOUBLE ) ; { sdiComplexity
sigComplexity = REAL ; sdiSampleTimeContinuity stCont =
SAMPLE_TIME_CONTINUOUS ; int_T sigDimsArray [ 1 ] = { 1 } ; sigDims . nDims =
1 ; sigDims . dimensions = sigDimsArray ; srcInfo . numBlockPathElems = 1 ;
srcInfo . fullBlockPath = ( sdiFullBlkPathU ) & blockPath ; srcInfo . SID = (
sdiSignalIDU ) & blockSID ; srcInfo . subPath = subPath ; srcInfo . portIndex
= 2 + 1 ; srcInfo . signalName = sigName ; srcInfo . sigSourceUUID = 0 ; rtDW
. bjz5tw4p5j . AQHandles = sdiStartAsyncioQueueCreation ( hDT , & srcInfo ,
rt_dataMapInfo . mmi . InstanceMap . fullPath ,
"1036edfb-7927-4407-893e-3bb82bdf2459" , sigComplexity , & sigDims ,
DIMENSIONS_MODE_FIXED , stCont , "" ) ; sdiCompleteAsyncioQueueCreation (
rtDW . bjz5tw4p5j . AQHandles , hDT , & srcInfo ) ; if ( rtDW . bjz5tw4p5j .
AQHandles ) { sdiSetSignalSampleTimeString ( rtDW . bjz5tw4p5j . AQHandles ,
"1" , 1.0 , ssGetTFinal ( rtS ) ) ; sdiSetSignalRefRate ( rtDW . bjz5tw4p5j .
AQHandles , 0.0 ) ; sdiSetRunStartTime ( rtDW . bjz5tw4p5j . AQHandles ,
ssGetTaskTime ( rtS , 1 ) ) ; sdiAsyncRepoSetSignalExportSettings ( rtDW .
bjz5tw4p5j . AQHandles , 1 , 0 ) ; sdiAsyncRepoSetSignalExportName ( rtDW .
bjz5tw4p5j . AQHandles , loggedName , origSigName , propName ) ; }
sdiFreeLabel ( sigName ) ; sdiFreeLabel ( loggedName ) ; sdiFreeLabel (
origSigName ) ; sdiFreeLabel ( propName ) ; sdiFreeLabel ( blockPath ) ;
sdiFreeLabel ( blockSID ) ; sdiFreeLabel ( subPath ) ; } } if ( !
isStreamoutAlreadyRegistered ) { } } } } { { { bool
isStreamoutAlreadyRegistered = false ; { sdiSignalSourceInfoU srcInfo ;
sdiLabelU loggedName = sdiGetLabelFromChars ( "" ) ; sdiLabelU origSigName =
sdiGetLabelFromChars ( "" ) ; sdiLabelU propName = sdiGetLabelFromChars ( ""
) ; sdiLabelU blockPath = sdiGetLabelFromChars (
"cstr_simulationEnv/CSTR_1 Simulation Model + Regulatory Control/Demux" ) ;
sdiLabelU blockSID = sdiGetLabelFromChars ( "" ) ; sdiLabelU subPath =
sdiGetLabelFromChars ( "" ) ; sdiDims sigDims ; sdiLabelU sigName =
sdiGetLabelFromChars ( "" ) ; sdiAsyncRepoDataTypeHandle hDT =
sdiAsyncRepoGetBuiltInDataTypeHandle ( DATA_TYPE_DOUBLE ) ; { sdiComplexity
sigComplexity = REAL ; sdiSampleTimeContinuity stCont =
SAMPLE_TIME_CONTINUOUS ; int_T sigDimsArray [ 1 ] = { 1 } ; sigDims . nDims =
1 ; sigDims . dimensions = sigDimsArray ; srcInfo . numBlockPathElems = 1 ;
srcInfo . fullBlockPath = ( sdiFullBlkPathU ) & blockPath ; srcInfo . SID = (
sdiSignalIDU ) & blockSID ; srcInfo . subPath = subPath ; srcInfo . portIndex
= 3 + 1 ; srcInfo . signalName = sigName ; srcInfo . sigSourceUUID = 0 ; rtDW
. mljkjloakr . AQHandles = sdiStartAsyncioQueueCreation ( hDT , & srcInfo ,
rt_dataMapInfo . mmi . InstanceMap . fullPath ,
"3c099004-5c8c-49cb-9805-ff31db19a3f1" , sigComplexity , & sigDims ,
DIMENSIONS_MODE_FIXED , stCont , "" ) ; sdiCompleteAsyncioQueueCreation (
rtDW . mljkjloakr . AQHandles , hDT , & srcInfo ) ; if ( rtDW . mljkjloakr .
AQHandles ) { sdiSetSignalSampleTimeString ( rtDW . mljkjloakr . AQHandles ,
"1" , 1.0 , ssGetTFinal ( rtS ) ) ; sdiSetSignalRefRate ( rtDW . mljkjloakr .
AQHandles , 0.0 ) ; sdiSetRunStartTime ( rtDW . mljkjloakr . AQHandles ,
ssGetTaskTime ( rtS , 1 ) ) ; sdiAsyncRepoSetSignalExportSettings ( rtDW .
mljkjloakr . AQHandles , 1 , 0 ) ; sdiAsyncRepoSetSignalExportName ( rtDW .
mljkjloakr . AQHandles , loggedName , origSigName , propName ) ; }
sdiFreeLabel ( sigName ) ; sdiFreeLabel ( loggedName ) ; sdiFreeLabel (
origSigName ) ; sdiFreeLabel ( propName ) ; sdiFreeLabel ( blockPath ) ;
sdiFreeLabel ( blockSID ) ; sdiFreeLabel ( subPath ) ; } } if ( !
isStreamoutAlreadyRegistered ) { } } } } { { { bool
isStreamoutAlreadyRegistered = false ; { sdiSignalSourceInfoU srcInfo ;
sdiLabelU loggedName = sdiGetLabelFromChars ( "" ) ; sdiLabelU origSigName =
sdiGetLabelFromChars ( "" ) ; sdiLabelU propName = sdiGetLabelFromChars ( ""
) ; sdiLabelU blockPath = sdiGetLabelFromChars (
"cstr_simulationEnv/CSTR_1 Simulation Model + Regulatory Control/Demux" ) ;
sdiLabelU blockSID = sdiGetLabelFromChars ( "" ) ; sdiLabelU subPath =
sdiGetLabelFromChars ( "" ) ; sdiDims sigDims ; sdiLabelU sigName =
sdiGetLabelFromChars ( "" ) ; sdiAsyncRepoDataTypeHandle hDT =
sdiAsyncRepoGetBuiltInDataTypeHandle ( DATA_TYPE_DOUBLE ) ; { sdiComplexity
sigComplexity = REAL ; sdiSampleTimeContinuity stCont =
SAMPLE_TIME_CONTINUOUS ; int_T sigDimsArray [ 1 ] = { 1 } ; sigDims . nDims =
1 ; sigDims . dimensions = sigDimsArray ; srcInfo . numBlockPathElems = 1 ;
srcInfo . fullBlockPath = ( sdiFullBlkPathU ) & blockPath ; srcInfo . SID = (
sdiSignalIDU ) & blockSID ; srcInfo . subPath = subPath ; srcInfo . portIndex
= 4 + 1 ; srcInfo . signalName = sigName ; srcInfo . sigSourceUUID = 0 ; rtDW
. l4vlioxbgl . AQHandles = sdiStartAsyncioQueueCreation ( hDT , & srcInfo ,
rt_dataMapInfo . mmi . InstanceMap . fullPath ,
"d68bb345-a949-4587-acd3-f55b2dcbb6c8" , sigComplexity , & sigDims ,
DIMENSIONS_MODE_FIXED , stCont , "" ) ; sdiCompleteAsyncioQueueCreation (
rtDW . l4vlioxbgl . AQHandles , hDT , & srcInfo ) ; if ( rtDW . l4vlioxbgl .
AQHandles ) { sdiSetSignalSampleTimeString ( rtDW . l4vlioxbgl . AQHandles ,
"1" , 1.0 , ssGetTFinal ( rtS ) ) ; sdiSetSignalRefRate ( rtDW . l4vlioxbgl .
AQHandles , 0.0 ) ; sdiSetRunStartTime ( rtDW . l4vlioxbgl . AQHandles ,
ssGetTaskTime ( rtS , 1 ) ) ; sdiAsyncRepoSetSignalExportSettings ( rtDW .
l4vlioxbgl . AQHandles , 1 , 0 ) ; sdiAsyncRepoSetSignalExportName ( rtDW .
l4vlioxbgl . AQHandles , loggedName , origSigName , propName ) ; }
sdiFreeLabel ( sigName ) ; sdiFreeLabel ( loggedName ) ; sdiFreeLabel (
origSigName ) ; sdiFreeLabel ( propName ) ; sdiFreeLabel ( blockPath ) ;
sdiFreeLabel ( blockSID ) ; sdiFreeLabel ( subPath ) ; } } if ( !
isStreamoutAlreadyRegistered ) { } } } } { { { bool
isStreamoutAlreadyRegistered = false ; { sdiSignalSourceInfoU srcInfo ;
sdiLabelU loggedName = sdiGetLabelFromChars ( "" ) ; sdiLabelU origSigName =
sdiGetLabelFromChars ( "" ) ; sdiLabelU propName = sdiGetLabelFromChars ( ""
) ; sdiLabelU blockPath = sdiGetLabelFromChars (
"cstr_simulationEnv/CSTR_1 Simulation Model + Regulatory Control/Demux" ) ;
sdiLabelU blockSID = sdiGetLabelFromChars ( "" ) ; sdiLabelU subPath =
sdiGetLabelFromChars ( "" ) ; sdiDims sigDims ; sdiLabelU sigName =
sdiGetLabelFromChars ( "" ) ; sdiAsyncRepoDataTypeHandle hDT =
sdiAsyncRepoGetBuiltInDataTypeHandle ( DATA_TYPE_DOUBLE ) ; { sdiComplexity
sigComplexity = REAL ; sdiSampleTimeContinuity stCont =
SAMPLE_TIME_CONTINUOUS ; int_T sigDimsArray [ 1 ] = { 1 } ; sigDims . nDims =
1 ; sigDims . dimensions = sigDimsArray ; srcInfo . numBlockPathElems = 1 ;
srcInfo . fullBlockPath = ( sdiFullBlkPathU ) & blockPath ; srcInfo . SID = (
sdiSignalIDU ) & blockSID ; srcInfo . subPath = subPath ; srcInfo . portIndex
= 5 + 1 ; srcInfo . signalName = sigName ; srcInfo . sigSourceUUID = 0 ; rtDW
. kkblxpcw3m . AQHandles = sdiStartAsyncioQueueCreation ( hDT , & srcInfo ,
rt_dataMapInfo . mmi . InstanceMap . fullPath ,
"d1534fc1-f113-4072-9e93-df136e6b7f58" , sigComplexity , & sigDims ,
DIMENSIONS_MODE_FIXED , stCont , "" ) ; sdiCompleteAsyncioQueueCreation (
rtDW . kkblxpcw3m . AQHandles , hDT , & srcInfo ) ; if ( rtDW . kkblxpcw3m .
AQHandles ) { sdiSetSignalSampleTimeString ( rtDW . kkblxpcw3m . AQHandles ,
"1" , 1.0 , ssGetTFinal ( rtS ) ) ; sdiSetSignalRefRate ( rtDW . kkblxpcw3m .
AQHandles , 0.0 ) ; sdiSetRunStartTime ( rtDW . kkblxpcw3m . AQHandles ,
ssGetTaskTime ( rtS , 1 ) ) ; sdiAsyncRepoSetSignalExportSettings ( rtDW .
kkblxpcw3m . AQHandles , 1 , 0 ) ; sdiAsyncRepoSetSignalExportName ( rtDW .
kkblxpcw3m . AQHandles , loggedName , origSigName , propName ) ; }
sdiFreeLabel ( sigName ) ; sdiFreeLabel ( loggedName ) ; sdiFreeLabel (
origSigName ) ; sdiFreeLabel ( propName ) ; sdiFreeLabel ( blockPath ) ;
sdiFreeLabel ( blockSID ) ; sdiFreeLabel ( subPath ) ; } } if ( !
isStreamoutAlreadyRegistered ) { } } } } { { { bool
isStreamoutAlreadyRegistered = false ; { sdiSignalSourceInfoU srcInfo ;
sdiLabelU loggedName = sdiGetLabelFromChars ( "" ) ; sdiLabelU origSigName =
sdiGetLabelFromChars ( "" ) ; sdiLabelU propName = sdiGetLabelFromChars ( ""
) ; sdiLabelU blockPath = sdiGetLabelFromChars (
"cstr_simulationEnv/CSTR_1 Simulation Model + Regulatory Control/Demux" ) ;
sdiLabelU blockSID = sdiGetLabelFromChars ( "" ) ; sdiLabelU subPath =
sdiGetLabelFromChars ( "" ) ; sdiDims sigDims ; sdiLabelU sigName =
sdiGetLabelFromChars ( "" ) ; sdiAsyncRepoDataTypeHandle hDT =
sdiAsyncRepoGetBuiltInDataTypeHandle ( DATA_TYPE_DOUBLE ) ; { sdiComplexity
sigComplexity = REAL ; sdiSampleTimeContinuity stCont =
SAMPLE_TIME_CONTINUOUS ; int_T sigDimsArray [ 1 ] = { 1 } ; sigDims . nDims =
1 ; sigDims . dimensions = sigDimsArray ; srcInfo . numBlockPathElems = 1 ;
srcInfo . fullBlockPath = ( sdiFullBlkPathU ) & blockPath ; srcInfo . SID = (
sdiSignalIDU ) & blockSID ; srcInfo . subPath = subPath ; srcInfo . portIndex
= 6 + 1 ; srcInfo . signalName = sigName ; srcInfo . sigSourceUUID = 0 ; rtDW
. h3jcwnop0g . AQHandles = sdiStartAsyncioQueueCreation ( hDT , & srcInfo ,
rt_dataMapInfo . mmi . InstanceMap . fullPath ,
"41ab9970-d38d-44d5-bdb6-97189956d0c7" , sigComplexity , & sigDims ,
DIMENSIONS_MODE_FIXED , stCont , "" ) ; sdiCompleteAsyncioQueueCreation (
rtDW . h3jcwnop0g . AQHandles , hDT , & srcInfo ) ; if ( rtDW . h3jcwnop0g .
AQHandles ) { sdiSetSignalSampleTimeString ( rtDW . h3jcwnop0g . AQHandles ,
"1" , 1.0 , ssGetTFinal ( rtS ) ) ; sdiSetSignalRefRate ( rtDW . h3jcwnop0g .
AQHandles , 0.0 ) ; sdiSetRunStartTime ( rtDW . h3jcwnop0g . AQHandles ,
ssGetTaskTime ( rtS , 1 ) ) ; sdiAsyncRepoSetSignalExportSettings ( rtDW .
h3jcwnop0g . AQHandles , 1 , 0 ) ; sdiAsyncRepoSetSignalExportName ( rtDW .
h3jcwnop0g . AQHandles , loggedName , origSigName , propName ) ; }
sdiFreeLabel ( sigName ) ; sdiFreeLabel ( loggedName ) ; sdiFreeLabel (
origSigName ) ; sdiFreeLabel ( propName ) ; sdiFreeLabel ( blockPath ) ;
sdiFreeLabel ( blockSID ) ; sdiFreeLabel ( subPath ) ; } } if ( !
isStreamoutAlreadyRegistered ) { } } } } { { { bool
isStreamoutAlreadyRegistered = false ; { sdiSignalSourceInfoU srcInfo ;
sdiLabelU loggedName = sdiGetLabelFromChars ( "" ) ; sdiLabelU origSigName =
sdiGetLabelFromChars ( "" ) ; sdiLabelU propName = sdiGetLabelFromChars ( ""
) ; sdiLabelU blockPath = sdiGetLabelFromChars (
"cstr_simulationEnv/CSTR_1 Simulation Model + Regulatory Control/Demux" ) ;
sdiLabelU blockSID = sdiGetLabelFromChars ( "" ) ; sdiLabelU subPath =
sdiGetLabelFromChars ( "" ) ; sdiDims sigDims ; sdiLabelU sigName =
sdiGetLabelFromChars ( "" ) ; sdiAsyncRepoDataTypeHandle hDT =
sdiAsyncRepoGetBuiltInDataTypeHandle ( DATA_TYPE_DOUBLE ) ; { sdiComplexity
sigComplexity = REAL ; sdiSampleTimeContinuity stCont =
SAMPLE_TIME_CONTINUOUS ; int_T sigDimsArray [ 1 ] = { 1 } ; sigDims . nDims =
1 ; sigDims . dimensions = sigDimsArray ; srcInfo . numBlockPathElems = 1 ;
srcInfo . fullBlockPath = ( sdiFullBlkPathU ) & blockPath ; srcInfo . SID = (
sdiSignalIDU ) & blockSID ; srcInfo . subPath = subPath ; srcInfo . portIndex
= 7 + 1 ; srcInfo . signalName = sigName ; srcInfo . sigSourceUUID = 0 ; rtDW
. mjxkrhmtfj . AQHandles = sdiStartAsyncioQueueCreation ( hDT , & srcInfo ,
rt_dataMapInfo . mmi . InstanceMap . fullPath ,
"7b854423-9a78-4944-b457-0cd8571df4c1" , sigComplexity , & sigDims ,
DIMENSIONS_MODE_FIXED , stCont , "" ) ; sdiCompleteAsyncioQueueCreation (
rtDW . mjxkrhmtfj . AQHandles , hDT , & srcInfo ) ; if ( rtDW . mjxkrhmtfj .
AQHandles ) { sdiSetSignalSampleTimeString ( rtDW . mjxkrhmtfj . AQHandles ,
"1" , 1.0 , ssGetTFinal ( rtS ) ) ; sdiSetSignalRefRate ( rtDW . mjxkrhmtfj .
AQHandles , 0.0 ) ; sdiSetRunStartTime ( rtDW . mjxkrhmtfj . AQHandles ,
ssGetTaskTime ( rtS , 1 ) ) ; sdiAsyncRepoSetSignalExportSettings ( rtDW .
mjxkrhmtfj . AQHandles , 1 , 0 ) ; sdiAsyncRepoSetSignalExportName ( rtDW .
mjxkrhmtfj . AQHandles , loggedName , origSigName , propName ) ; }
sdiFreeLabel ( sigName ) ; sdiFreeLabel ( loggedName ) ; sdiFreeLabel (
origSigName ) ; sdiFreeLabel ( propName ) ; sdiFreeLabel ( blockPath ) ;
sdiFreeLabel ( blockSID ) ; sdiFreeLabel ( subPath ) ; } } if ( !
isStreamoutAlreadyRegistered ) { } } } } { { { bool
isStreamoutAlreadyRegistered = false ; { sdiSignalSourceInfoU srcInfo ;
sdiLabelU loggedName = sdiGetLabelFromChars ( "" ) ; sdiLabelU origSigName =
sdiGetLabelFromChars ( "" ) ; sdiLabelU propName = sdiGetLabelFromChars ( ""
) ; sdiLabelU blockPath = sdiGetLabelFromChars (
"cstr_simulationEnv/CSTR_1 Simulation Model + Regulatory Control/Demux" ) ;
sdiLabelU blockSID = sdiGetLabelFromChars ( "" ) ; sdiLabelU subPath =
sdiGetLabelFromChars ( "" ) ; sdiDims sigDims ; sdiLabelU sigName =
sdiGetLabelFromChars ( "" ) ; sdiAsyncRepoDataTypeHandle hDT =
sdiAsyncRepoGetBuiltInDataTypeHandle ( DATA_TYPE_DOUBLE ) ; { sdiComplexity
sigComplexity = REAL ; sdiSampleTimeContinuity stCont =
SAMPLE_TIME_CONTINUOUS ; int_T sigDimsArray [ 1 ] = { 1 } ; sigDims . nDims =
1 ; sigDims . dimensions = sigDimsArray ; srcInfo . numBlockPathElems = 1 ;
srcInfo . fullBlockPath = ( sdiFullBlkPathU ) & blockPath ; srcInfo . SID = (
sdiSignalIDU ) & blockSID ; srcInfo . subPath = subPath ; srcInfo . portIndex
= 8 + 1 ; srcInfo . signalName = sigName ; srcInfo . sigSourceUUID = 0 ; rtDW
. beunqpbxj1 . AQHandles = sdiStartAsyncioQueueCreation ( hDT , & srcInfo ,
rt_dataMapInfo . mmi . InstanceMap . fullPath ,
"3e5414d2-b57d-4f12-a798-a198c2696c73" , sigComplexity , & sigDims ,
DIMENSIONS_MODE_FIXED , stCont , "" ) ; sdiCompleteAsyncioQueueCreation (
rtDW . beunqpbxj1 . AQHandles , hDT , & srcInfo ) ; if ( rtDW . beunqpbxj1 .
AQHandles ) { sdiSetSignalSampleTimeString ( rtDW . beunqpbxj1 . AQHandles ,
"1" , 1.0 , ssGetTFinal ( rtS ) ) ; sdiSetSignalRefRate ( rtDW . beunqpbxj1 .
AQHandles , 0.0 ) ; sdiSetRunStartTime ( rtDW . beunqpbxj1 . AQHandles ,
ssGetTaskTime ( rtS , 1 ) ) ; sdiAsyncRepoSetSignalExportSettings ( rtDW .
beunqpbxj1 . AQHandles , 1 , 0 ) ; sdiAsyncRepoSetSignalExportName ( rtDW .
beunqpbxj1 . AQHandles , loggedName , origSigName , propName ) ; }
sdiFreeLabel ( sigName ) ; sdiFreeLabel ( loggedName ) ; sdiFreeLabel (
origSigName ) ; sdiFreeLabel ( propName ) ; sdiFreeLabel ( blockPath ) ;
sdiFreeLabel ( blockSID ) ; sdiFreeLabel ( subPath ) ; } } if ( !
isStreamoutAlreadyRegistered ) { } } } } { { { bool
isStreamoutAlreadyRegistered = false ; { sdiSignalSourceInfoU srcInfo ;
sdiLabelU loggedName = sdiGetLabelFromChars ( "" ) ; sdiLabelU origSigName =
sdiGetLabelFromChars ( "" ) ; sdiLabelU propName = sdiGetLabelFromChars ( ""
) ; sdiLabelU blockPath = sdiGetLabelFromChars (
 "cstr_simulationEnv/CSTR_1 Simulation Model + Regulatory Control/Feed_Temperature"
) ; sdiLabelU blockSID = sdiGetLabelFromChars ( "" ) ; sdiLabelU subPath =
sdiGetLabelFromChars ( "" ) ; sdiDims sigDims ; sdiLabelU sigName =
sdiGetLabelFromChars ( "" ) ; sdiAsyncRepoDataTypeHandle hDT =
sdiAsyncRepoGetBuiltInDataTypeHandle ( DATA_TYPE_DOUBLE ) ; { sdiComplexity
sigComplexity = REAL ; sdiSampleTimeContinuity stCont = SAMPLE_TIME_DISCRETE
; int_T sigDimsArray [ 1 ] = { 1 } ; sigDims . nDims = 1 ; sigDims .
dimensions = sigDimsArray ; srcInfo . numBlockPathElems = 1 ; srcInfo .
fullBlockPath = ( sdiFullBlkPathU ) & blockPath ; srcInfo . SID = (
sdiSignalIDU ) & blockSID ; srcInfo . subPath = subPath ; srcInfo . portIndex
= 0 + 1 ; srcInfo . signalName = sigName ; srcInfo . sigSourceUUID = 0 ; rtDW
. jvhbaaoh3e . AQHandles = sdiStartAsyncioQueueCreation ( hDT , & srcInfo ,
rt_dataMapInfo . mmi . InstanceMap . fullPath ,
"3071035d-f7b7-4813-9f74-744b05ce1e52" , sigComplexity , & sigDims ,
DIMENSIONS_MODE_FIXED , stCont , "" ) ; sdiCompleteAsyncioQueueCreation (
rtDW . jvhbaaoh3e . AQHandles , hDT , & srcInfo ) ; if ( rtDW . jvhbaaoh3e .
AQHandles ) { sdiSetSignalSampleTimeString ( rtDW . jvhbaaoh3e . AQHandles ,
"1" , 1.0 , ssGetTFinal ( rtS ) ) ; sdiSetSignalRefRate ( rtDW . jvhbaaoh3e .
AQHandles , 0.0 ) ; sdiSetRunStartTime ( rtDW . jvhbaaoh3e . AQHandles ,
ssGetTaskTime ( rtS , 1 ) ) ; sdiAsyncRepoSetSignalExportSettings ( rtDW .
jvhbaaoh3e . AQHandles , 1 , 0 ) ; sdiAsyncRepoSetSignalExportName ( rtDW .
jvhbaaoh3e . AQHandles , loggedName , origSigName , propName ) ; }
sdiFreeLabel ( sigName ) ; sdiFreeLabel ( loggedName ) ; sdiFreeLabel (
origSigName ) ; sdiFreeLabel ( propName ) ; sdiFreeLabel ( blockPath ) ;
sdiFreeLabel ( blockSID ) ; sdiFreeLabel ( subPath ) ; } } if ( !
isStreamoutAlreadyRegistered ) { } } } } { { { bool
isStreamoutAlreadyRegistered = false ; { sdiSignalSourceInfoU srcInfo ;
sdiLabelU loggedName = sdiGetLabelFromChars ( "" ) ; sdiLabelU origSigName =
sdiGetLabelFromChars ( "" ) ; sdiLabelU propName = sdiGetLabelFromChars ( ""
) ; sdiLabelU blockPath = sdiGetLabelFromChars (
"cstr_simulationEnv/CSTR_1 Simulation Model + Regulatory Control/Gain1" ) ;
sdiLabelU blockSID = sdiGetLabelFromChars ( "" ) ; sdiLabelU subPath =
sdiGetLabelFromChars ( "" ) ; sdiDims sigDims ; sdiLabelU sigName =
sdiGetLabelFromChars ( "" ) ; sdiAsyncRepoDataTypeHandle hDT =
sdiAsyncRepoGetBuiltInDataTypeHandle ( DATA_TYPE_DOUBLE ) ; { sdiComplexity
sigComplexity = REAL ; sdiSampleTimeContinuity stCont =
SAMPLE_TIME_CONTINUOUS ; int_T sigDimsArray [ 1 ] = { 1 } ; sigDims . nDims =
1 ; sigDims . dimensions = sigDimsArray ; srcInfo . numBlockPathElems = 1 ;
srcInfo . fullBlockPath = ( sdiFullBlkPathU ) & blockPath ; srcInfo . SID = (
sdiSignalIDU ) & blockSID ; srcInfo . subPath = subPath ; srcInfo . portIndex
= 0 + 1 ; srcInfo . signalName = sigName ; srcInfo . sigSourceUUID = 0 ; rtDW
. ctwshmhpdz . AQHandles = sdiStartAsyncioQueueCreation ( hDT , & srcInfo ,
rt_dataMapInfo . mmi . InstanceMap . fullPath ,
"dc45a102-2b54-4de8-9705-03f2c0f0f1f5" , sigComplexity , & sigDims ,
DIMENSIONS_MODE_FIXED , stCont , "" ) ; sdiCompleteAsyncioQueueCreation (
rtDW . ctwshmhpdz . AQHandles , hDT , & srcInfo ) ; if ( rtDW . ctwshmhpdz .
AQHandles ) { sdiSetSignalSampleTimeString ( rtDW . ctwshmhpdz . AQHandles ,
"1" , 1.0 , ssGetTFinal ( rtS ) ) ; sdiSetSignalRefRate ( rtDW . ctwshmhpdz .
AQHandles , 0.0 ) ; sdiSetRunStartTime ( rtDW . ctwshmhpdz . AQHandles ,
ssGetTaskTime ( rtS , 1 ) ) ; sdiAsyncRepoSetSignalExportSettings ( rtDW .
ctwshmhpdz . AQHandles , 1 , 0 ) ; sdiAsyncRepoSetSignalExportName ( rtDW .
ctwshmhpdz . AQHandles , loggedName , origSigName , propName ) ; }
sdiFreeLabel ( sigName ) ; sdiFreeLabel ( loggedName ) ; sdiFreeLabel (
origSigName ) ; sdiFreeLabel ( propName ) ; sdiFreeLabel ( blockPath ) ;
sdiFreeLabel ( blockSID ) ; sdiFreeLabel ( subPath ) ; } } if ( !
isStreamoutAlreadyRegistered ) { } } } } { { { bool
isStreamoutAlreadyRegistered = false ; { sdiSignalSourceInfoU srcInfo ;
sdiLabelU loggedName = sdiGetLabelFromChars ( "" ) ; sdiLabelU origSigName =
sdiGetLabelFromChars ( "" ) ; sdiLabelU propName = sdiGetLabelFromChars ( ""
) ; sdiLabelU blockPath = sdiGetLabelFromChars (
"cstr_simulationEnv/CSTR_1 Simulation Model + Regulatory Control/Gain2" ) ;
sdiLabelU blockSID = sdiGetLabelFromChars ( "" ) ; sdiLabelU subPath =
sdiGetLabelFromChars ( "" ) ; sdiDims sigDims ; sdiLabelU sigName =
sdiGetLabelFromChars ( "" ) ; sdiAsyncRepoDataTypeHandle hDT =
sdiAsyncRepoGetBuiltInDataTypeHandle ( DATA_TYPE_DOUBLE ) ; { sdiComplexity
sigComplexity = REAL ; sdiSampleTimeContinuity stCont =
SAMPLE_TIME_CONTINUOUS ; int_T sigDimsArray [ 1 ] = { 1 } ; sigDims . nDims =
1 ; sigDims . dimensions = sigDimsArray ; srcInfo . numBlockPathElems = 1 ;
srcInfo . fullBlockPath = ( sdiFullBlkPathU ) & blockPath ; srcInfo . SID = (
sdiSignalIDU ) & blockSID ; srcInfo . subPath = subPath ; srcInfo . portIndex
= 0 + 1 ; srcInfo . signalName = sigName ; srcInfo . sigSourceUUID = 0 ; rtDW
. licnk0hmrn . AQHandles = sdiStartAsyncioQueueCreation ( hDT , & srcInfo ,
rt_dataMapInfo . mmi . InstanceMap . fullPath ,
"27604751-8cad-4372-b690-1dd1cb8875dc" , sigComplexity , & sigDims ,
DIMENSIONS_MODE_FIXED , stCont , "" ) ; sdiCompleteAsyncioQueueCreation (
rtDW . licnk0hmrn . AQHandles , hDT , & srcInfo ) ; if ( rtDW . licnk0hmrn .
AQHandles ) { sdiSetSignalSampleTimeString ( rtDW . licnk0hmrn . AQHandles ,
"1" , 1.0 , ssGetTFinal ( rtS ) ) ; sdiSetSignalRefRate ( rtDW . licnk0hmrn .
AQHandles , 0.0 ) ; sdiSetRunStartTime ( rtDW . licnk0hmrn . AQHandles ,
ssGetTaskTime ( rtS , 1 ) ) ; sdiAsyncRepoSetSignalExportSettings ( rtDW .
licnk0hmrn . AQHandles , 1 , 0 ) ; sdiAsyncRepoSetSignalExportName ( rtDW .
licnk0hmrn . AQHandles , loggedName , origSigName , propName ) ; }
sdiFreeLabel ( sigName ) ; sdiFreeLabel ( loggedName ) ; sdiFreeLabel (
origSigName ) ; sdiFreeLabel ( propName ) ; sdiFreeLabel ( blockPath ) ;
sdiFreeLabel ( blockSID ) ; sdiFreeLabel ( subPath ) ; } } if ( !
isStreamoutAlreadyRegistered ) { } } } } { { { bool
isStreamoutAlreadyRegistered = false ; { sdiSignalSourceInfoU srcInfo ;
sdiLabelU loggedName = sdiGetLabelFromChars ( "" ) ; sdiLabelU origSigName =
sdiGetLabelFromChars ( "" ) ; sdiLabelU propName = sdiGetLabelFromChars ( ""
) ; sdiLabelU blockPath = sdiGetLabelFromChars (
"cstr_simulationEnv/CSTR_1 Simulation Model + Regulatory Control/Product5" )
; sdiLabelU blockSID = sdiGetLabelFromChars ( "" ) ; sdiLabelU subPath =
sdiGetLabelFromChars ( "" ) ; sdiDims sigDims ; sdiLabelU sigName =
sdiGetLabelFromChars ( "" ) ; sdiAsyncRepoDataTypeHandle hDT =
sdiAsyncRepoGetBuiltInDataTypeHandle ( DATA_TYPE_DOUBLE ) ; { sdiComplexity
sigComplexity = REAL ; sdiSampleTimeContinuity stCont =
SAMPLE_TIME_CONTINUOUS ; int_T sigDimsArray [ 1 ] = { 1 } ; sigDims . nDims =
1 ; sigDims . dimensions = sigDimsArray ; srcInfo . numBlockPathElems = 1 ;
srcInfo . fullBlockPath = ( sdiFullBlkPathU ) & blockPath ; srcInfo . SID = (
sdiSignalIDU ) & blockSID ; srcInfo . subPath = subPath ; srcInfo . portIndex
= 0 + 1 ; srcInfo . signalName = sigName ; srcInfo . sigSourceUUID = 0 ; rtDW
. jvdos0csvi . AQHandles = sdiStartAsyncioQueueCreation ( hDT , & srcInfo ,
rt_dataMapInfo . mmi . InstanceMap . fullPath ,
"c4542d63-3c5a-4080-967f-cee248cfb7c8" , sigComplexity , & sigDims ,
DIMENSIONS_MODE_FIXED , stCont , "" ) ; sdiCompleteAsyncioQueueCreation (
rtDW . jvdos0csvi . AQHandles , hDT , & srcInfo ) ; if ( rtDW . jvdos0csvi .
AQHandles ) { sdiSetSignalSampleTimeString ( rtDW . jvdos0csvi . AQHandles ,
"1" , 1.0 , ssGetTFinal ( rtS ) ) ; sdiSetSignalRefRate ( rtDW . jvdos0csvi .
AQHandles , 0.0 ) ; sdiSetRunStartTime ( rtDW . jvdos0csvi . AQHandles ,
ssGetTaskTime ( rtS , 1 ) ) ; sdiAsyncRepoSetSignalExportSettings ( rtDW .
jvdos0csvi . AQHandles , 1 , 0 ) ; sdiAsyncRepoSetSignalExportName ( rtDW .
jvdos0csvi . AQHandles , loggedName , origSigName , propName ) ; }
sdiFreeLabel ( sigName ) ; sdiFreeLabel ( loggedName ) ; sdiFreeLabel (
origSigName ) ; sdiFreeLabel ( propName ) ; sdiFreeLabel ( blockPath ) ;
sdiFreeLabel ( blockSID ) ; sdiFreeLabel ( subPath ) ; } } if ( !
isStreamoutAlreadyRegistered ) { } } } } { { { bool
isStreamoutAlreadyRegistered = false ; { sdiSignalSourceInfoU srcInfo ;
sdiLabelU loggedName = sdiGetLabelFromChars ( "" ) ; sdiLabelU origSigName =
sdiGetLabelFromChars ( "" ) ; sdiLabelU propName = sdiGetLabelFromChars ( ""
) ; sdiLabelU blockPath = sdiGetLabelFromChars (
"cstr_simulationEnv/CSTR_1 Simulation Model + Regulatory Control/Product6" )
; sdiLabelU blockSID = sdiGetLabelFromChars ( "" ) ; sdiLabelU subPath =
sdiGetLabelFromChars ( "" ) ; sdiDims sigDims ; sdiLabelU sigName =
sdiGetLabelFromChars ( "" ) ; sdiAsyncRepoDataTypeHandle hDT =
sdiAsyncRepoGetBuiltInDataTypeHandle ( DATA_TYPE_DOUBLE ) ; { sdiComplexity
sigComplexity = REAL ; sdiSampleTimeContinuity stCont =
SAMPLE_TIME_CONTINUOUS ; int_T sigDimsArray [ 1 ] = { 1 } ; sigDims . nDims =
1 ; sigDims . dimensions = sigDimsArray ; srcInfo . numBlockPathElems = 1 ;
srcInfo . fullBlockPath = ( sdiFullBlkPathU ) & blockPath ; srcInfo . SID = (
sdiSignalIDU ) & blockSID ; srcInfo . subPath = subPath ; srcInfo . portIndex
= 0 + 1 ; srcInfo . signalName = sigName ; srcInfo . sigSourceUUID = 0 ; rtDW
. pn3nw2wp03 . AQHandles = sdiStartAsyncioQueueCreation ( hDT , & srcInfo ,
rt_dataMapInfo . mmi . InstanceMap . fullPath ,
"58570eca-de3c-4d3c-9bac-c40bb42a6b7b" , sigComplexity , & sigDims ,
DIMENSIONS_MODE_FIXED , stCont , "" ) ; sdiCompleteAsyncioQueueCreation (
rtDW . pn3nw2wp03 . AQHandles , hDT , & srcInfo ) ; if ( rtDW . pn3nw2wp03 .
AQHandles ) { sdiSetSignalSampleTimeString ( rtDW . pn3nw2wp03 . AQHandles ,
"1" , 1.0 , ssGetTFinal ( rtS ) ) ; sdiSetSignalRefRate ( rtDW . pn3nw2wp03 .
AQHandles , 0.0 ) ; sdiSetRunStartTime ( rtDW . pn3nw2wp03 . AQHandles ,
ssGetTaskTime ( rtS , 1 ) ) ; sdiAsyncRepoSetSignalExportSettings ( rtDW .
pn3nw2wp03 . AQHandles , 1 , 0 ) ; sdiAsyncRepoSetSignalExportName ( rtDW .
pn3nw2wp03 . AQHandles , loggedName , origSigName , propName ) ; }
sdiFreeLabel ( sigName ) ; sdiFreeLabel ( loggedName ) ; sdiFreeLabel (
origSigName ) ; sdiFreeLabel ( propName ) ; sdiFreeLabel ( blockPath ) ;
sdiFreeLabel ( blockSID ) ; sdiFreeLabel ( subPath ) ; } } if ( !
isStreamoutAlreadyRegistered ) { } } } } { { { bool
isStreamoutAlreadyRegistered = false ; { sdiSignalSourceInfoU srcInfo ;
sdiLabelU loggedName = sdiGetLabelFromChars ( "" ) ; sdiLabelU origSigName =
sdiGetLabelFromChars ( "" ) ; sdiLabelU propName = sdiGetLabelFromChars ( ""
) ; sdiLabelU blockPath = sdiGetLabelFromChars (
"cstr_simulationEnv/CSTR_1 Simulation Model + Regulatory Control/Sum2" ) ;
sdiLabelU blockSID = sdiGetLabelFromChars ( "" ) ; sdiLabelU subPath =
sdiGetLabelFromChars ( "" ) ; sdiDims sigDims ; sdiLabelU sigName =
sdiGetLabelFromChars ( "" ) ; sdiAsyncRepoDataTypeHandle hDT =
sdiAsyncRepoGetBuiltInDataTypeHandle ( DATA_TYPE_DOUBLE ) ; { sdiComplexity
sigComplexity = REAL ; sdiSampleTimeContinuity stCont = SAMPLE_TIME_DISCRETE
; int_T sigDimsArray [ 1 ] = { 1 } ; sigDims . nDims = 1 ; sigDims .
dimensions = sigDimsArray ; srcInfo . numBlockPathElems = 1 ; srcInfo .
fullBlockPath = ( sdiFullBlkPathU ) & blockPath ; srcInfo . SID = (
sdiSignalIDU ) & blockSID ; srcInfo . subPath = subPath ; srcInfo . portIndex
= 0 + 1 ; srcInfo . signalName = sigName ; srcInfo . sigSourceUUID = 0 ; rtDW
. lclc5oxd1y . AQHandles = sdiStartAsyncioQueueCreation ( hDT , & srcInfo ,
rt_dataMapInfo . mmi . InstanceMap . fullPath ,
"dc23175f-fe04-4dbe-a84b-21990c7d3709" , sigComplexity , & sigDims ,
DIMENSIONS_MODE_FIXED , stCont , "" ) ; sdiCompleteAsyncioQueueCreation (
rtDW . lclc5oxd1y . AQHandles , hDT , & srcInfo ) ; if ( rtDW . lclc5oxd1y .
AQHandles ) { sdiSetSignalSampleTimeString ( rtDW . lclc5oxd1y . AQHandles ,
"500" , 500.0 , ssGetTFinal ( rtS ) ) ; sdiSetSignalRefRate ( rtDW .
lclc5oxd1y . AQHandles , 0.0 ) ; sdiSetRunStartTime ( rtDW . lclc5oxd1y .
AQHandles , ssGetTaskTime ( rtS , 3 ) ) ; sdiAsyncRepoSetSignalExportSettings
( rtDW . lclc5oxd1y . AQHandles , 1 , 0 ) ; sdiAsyncRepoSetSignalExportName (
rtDW . lclc5oxd1y . AQHandles , loggedName , origSigName , propName ) ; }
sdiFreeLabel ( sigName ) ; sdiFreeLabel ( loggedName ) ; sdiFreeLabel (
origSigName ) ; sdiFreeLabel ( propName ) ; sdiFreeLabel ( blockPath ) ;
sdiFreeLabel ( blockSID ) ; sdiFreeLabel ( subPath ) ; } } if ( !
isStreamoutAlreadyRegistered ) { } } } } { { { bool
isStreamoutAlreadyRegistered = false ; { sdiSignalSourceInfoU srcInfo ;
sdiLabelU loggedName = sdiGetLabelFromChars ( "" ) ; sdiLabelU origSigName =
sdiGetLabelFromChars ( "" ) ; sdiLabelU propName = sdiGetLabelFromChars ( ""
) ; sdiLabelU blockPath = sdiGetLabelFromChars (
"cstr_simulationEnv/CSTR_1 Simulation Model + Regulatory Control/Sum3" ) ;
sdiLabelU blockSID = sdiGetLabelFromChars ( "" ) ; sdiLabelU subPath =
sdiGetLabelFromChars ( "" ) ; sdiDims sigDims ; sdiLabelU sigName =
sdiGetLabelFromChars ( "" ) ; sdiAsyncRepoDataTypeHandle hDT =
sdiAsyncRepoGetBuiltInDataTypeHandle ( DATA_TYPE_DOUBLE ) ; { sdiComplexity
sigComplexity = REAL ; sdiSampleTimeContinuity stCont = SAMPLE_TIME_DISCRETE
; int_T sigDimsArray [ 1 ] = { 1 } ; sigDims . nDims = 1 ; sigDims .
dimensions = sigDimsArray ; srcInfo . numBlockPathElems = 1 ; srcInfo .
fullBlockPath = ( sdiFullBlkPathU ) & blockPath ; srcInfo . SID = (
sdiSignalIDU ) & blockSID ; srcInfo . subPath = subPath ; srcInfo . portIndex
= 0 + 1 ; srcInfo . signalName = sigName ; srcInfo . sigSourceUUID = 0 ; rtDW
. k2lm4rcfbi . AQHandles = sdiStartAsyncioQueueCreation ( hDT , & srcInfo ,
rt_dataMapInfo . mmi . InstanceMap . fullPath ,
"5ebd15a5-3960-4ec2-b432-e774098552c8" , sigComplexity , & sigDims ,
DIMENSIONS_MODE_FIXED , stCont , "" ) ; sdiCompleteAsyncioQueueCreation (
rtDW . k2lm4rcfbi . AQHandles , hDT , & srcInfo ) ; if ( rtDW . k2lm4rcfbi .
AQHandles ) { sdiSetSignalSampleTimeString ( rtDW . k2lm4rcfbi . AQHandles ,
"500" , 500.0 , ssGetTFinal ( rtS ) ) ; sdiSetSignalRefRate ( rtDW .
k2lm4rcfbi . AQHandles , 0.0 ) ; sdiSetRunStartTime ( rtDW . k2lm4rcfbi .
AQHandles , ssGetTaskTime ( rtS , 3 ) ) ; sdiAsyncRepoSetSignalExportSettings
( rtDW . k2lm4rcfbi . AQHandles , 1 , 0 ) ; sdiAsyncRepoSetSignalExportName (
rtDW . k2lm4rcfbi . AQHandles , loggedName , origSigName , propName ) ; }
sdiFreeLabel ( sigName ) ; sdiFreeLabel ( loggedName ) ; sdiFreeLabel (
origSigName ) ; sdiFreeLabel ( propName ) ; sdiFreeLabel ( blockPath ) ;
sdiFreeLabel ( blockSID ) ; sdiFreeLabel ( subPath ) ; } } if ( !
isStreamoutAlreadyRegistered ) { } } } } { { { bool
isStreamoutAlreadyRegistered = false ; { sdiSignalSourceInfoU srcInfo ;
sdiLabelU loggedName = sdiGetLabelFromChars ( "" ) ; sdiLabelU origSigName =
sdiGetLabelFromChars ( "" ) ; sdiLabelU propName = sdiGetLabelFromChars ( ""
) ; sdiLabelU blockPath = sdiGetLabelFromChars (
"cstr_simulationEnv/CSTR_1 Simulation Model + Regulatory Control/Sum4" ) ;
sdiLabelU blockSID = sdiGetLabelFromChars ( "" ) ; sdiLabelU subPath =
sdiGetLabelFromChars ( "" ) ; sdiDims sigDims ; sdiLabelU sigName =
sdiGetLabelFromChars ( "" ) ; sdiAsyncRepoDataTypeHandle hDT =
sdiAsyncRepoGetBuiltInDataTypeHandle ( DATA_TYPE_DOUBLE ) ; { sdiComplexity
sigComplexity = REAL ; sdiSampleTimeContinuity stCont = SAMPLE_TIME_DISCRETE
; int_T sigDimsArray [ 1 ] = { 1 } ; sigDims . nDims = 1 ; sigDims .
dimensions = sigDimsArray ; srcInfo . numBlockPathElems = 1 ; srcInfo .
fullBlockPath = ( sdiFullBlkPathU ) & blockPath ; srcInfo . SID = (
sdiSignalIDU ) & blockSID ; srcInfo . subPath = subPath ; srcInfo . portIndex
= 0 + 1 ; srcInfo . signalName = sigName ; srcInfo . sigSourceUUID = 0 ; rtDW
. hcvlm25apo . AQHandles = sdiStartAsyncioQueueCreation ( hDT , & srcInfo ,
rt_dataMapInfo . mmi . InstanceMap . fullPath ,
"29a763b6-a75a-4457-b4c0-06404e9264d3" , sigComplexity , & sigDims ,
DIMENSIONS_MODE_FIXED , stCont , "" ) ; sdiCompleteAsyncioQueueCreation (
rtDW . hcvlm25apo . AQHandles , hDT , & srcInfo ) ; if ( rtDW . hcvlm25apo .
AQHandles ) { sdiSetSignalSampleTimeString ( rtDW . hcvlm25apo . AQHandles ,
"500" , 500.0 , ssGetTFinal ( rtS ) ) ; sdiSetSignalRefRate ( rtDW .
hcvlm25apo . AQHandles , 0.0 ) ; sdiSetRunStartTime ( rtDW . hcvlm25apo .
AQHandles , ssGetTaskTime ( rtS , 3 ) ) ; sdiAsyncRepoSetSignalExportSettings
( rtDW . hcvlm25apo . AQHandles , 1 , 0 ) ; sdiAsyncRepoSetSignalExportName (
rtDW . hcvlm25apo . AQHandles , loggedName , origSigName , propName ) ; }
sdiFreeLabel ( sigName ) ; sdiFreeLabel ( loggedName ) ; sdiFreeLabel (
origSigName ) ; sdiFreeLabel ( propName ) ; sdiFreeLabel ( blockPath ) ;
sdiFreeLabel ( blockSID ) ; sdiFreeLabel ( subPath ) ; } } if ( !
isStreamoutAlreadyRegistered ) { } } } } { { { bool
isStreamoutAlreadyRegistered = false ; { sdiSignalSourceInfoU srcInfo ;
sdiLabelU loggedName = sdiGetLabelFromChars ( "" ) ; sdiLabelU origSigName =
sdiGetLabelFromChars ( "" ) ; sdiLabelU propName = sdiGetLabelFromChars ( ""
) ; sdiLabelU blockPath = sdiGetLabelFromChars (
"cstr_simulationEnv/CSTR_1 Simulation Model + Regulatory Control/Sum5" ) ;
sdiLabelU blockSID = sdiGetLabelFromChars ( "" ) ; sdiLabelU subPath =
sdiGetLabelFromChars ( "" ) ; sdiDims sigDims ; sdiLabelU sigName =
sdiGetLabelFromChars ( "" ) ; sdiAsyncRepoDataTypeHandle hDT =
sdiAsyncRepoGetBuiltInDataTypeHandle ( DATA_TYPE_DOUBLE ) ; { sdiComplexity
sigComplexity = REAL ; sdiSampleTimeContinuity stCont = SAMPLE_TIME_DISCRETE
; int_T sigDimsArray [ 1 ] = { 1 } ; sigDims . nDims = 1 ; sigDims .
dimensions = sigDimsArray ; srcInfo . numBlockPathElems = 1 ; srcInfo .
fullBlockPath = ( sdiFullBlkPathU ) & blockPath ; srcInfo . SID = (
sdiSignalIDU ) & blockSID ; srcInfo . subPath = subPath ; srcInfo . portIndex
= 0 + 1 ; srcInfo . signalName = sigName ; srcInfo . sigSourceUUID = 0 ; rtDW
. ku5epe2lev . AQHandles = sdiStartAsyncioQueueCreation ( hDT , & srcInfo ,
rt_dataMapInfo . mmi . InstanceMap . fullPath ,
"a60dfc26-64d3-49d9-84ed-ff49f86dc046" , sigComplexity , & sigDims ,
DIMENSIONS_MODE_FIXED , stCont , "" ) ; sdiCompleteAsyncioQueueCreation (
rtDW . ku5epe2lev . AQHandles , hDT , & srcInfo ) ; if ( rtDW . ku5epe2lev .
AQHandles ) { sdiSetSignalSampleTimeString ( rtDW . ku5epe2lev . AQHandles ,
"500" , 500.0 , ssGetTFinal ( rtS ) ) ; sdiSetSignalRefRate ( rtDW .
ku5epe2lev . AQHandles , 0.0 ) ; sdiSetRunStartTime ( rtDW . ku5epe2lev .
AQHandles , ssGetTaskTime ( rtS , 3 ) ) ; sdiAsyncRepoSetSignalExportSettings
( rtDW . ku5epe2lev . AQHandles , 1 , 0 ) ; sdiAsyncRepoSetSignalExportName (
rtDW . ku5epe2lev . AQHandles , loggedName , origSigName , propName ) ; }
sdiFreeLabel ( sigName ) ; sdiFreeLabel ( loggedName ) ; sdiFreeLabel (
origSigName ) ; sdiFreeLabel ( propName ) ; sdiFreeLabel ( blockPath ) ;
sdiFreeLabel ( blockSID ) ; sdiFreeLabel ( subPath ) ; } } if ( !
isStreamoutAlreadyRegistered ) { } } } } { { { bool
isStreamoutAlreadyRegistered = false ; { sdiSignalSourceInfoU srcInfo ;
sdiLabelU loggedName = sdiGetLabelFromChars ( "" ) ; sdiLabelU origSigName =
sdiGetLabelFromChars ( "" ) ; sdiLabelU propName = sdiGetLabelFromChars ( ""
) ; sdiLabelU blockPath = sdiGetLabelFromChars (
"cstr_simulationEnv/CSTR_1 Simulation Model + Regulatory Control/Sum6" ) ;
sdiLabelU blockSID = sdiGetLabelFromChars ( "" ) ; sdiLabelU subPath =
sdiGetLabelFromChars ( "" ) ; sdiDims sigDims ; sdiLabelU sigName =
sdiGetLabelFromChars ( "" ) ; sdiAsyncRepoDataTypeHandle hDT =
sdiAsyncRepoGetBuiltInDataTypeHandle ( DATA_TYPE_DOUBLE ) ; { sdiComplexity
sigComplexity = REAL ; sdiSampleTimeContinuity stCont = SAMPLE_TIME_DISCRETE
; int_T sigDimsArray [ 1 ] = { 1 } ; sigDims . nDims = 1 ; sigDims .
dimensions = sigDimsArray ; srcInfo . numBlockPathElems = 1 ; srcInfo .
fullBlockPath = ( sdiFullBlkPathU ) & blockPath ; srcInfo . SID = (
sdiSignalIDU ) & blockSID ; srcInfo . subPath = subPath ; srcInfo . portIndex
= 0 + 1 ; srcInfo . signalName = sigName ; srcInfo . sigSourceUUID = 0 ; rtDW
. eksra31szv . AQHandles = sdiStartAsyncioQueueCreation ( hDT , & srcInfo ,
rt_dataMapInfo . mmi . InstanceMap . fullPath ,
"2b2c20e9-9eee-4fd1-9098-d666d8cf7b85" , sigComplexity , & sigDims ,
DIMENSIONS_MODE_FIXED , stCont , "" ) ; sdiCompleteAsyncioQueueCreation (
rtDW . eksra31szv . AQHandles , hDT , & srcInfo ) ; if ( rtDW . eksra31szv .
AQHandles ) { sdiSetSignalSampleTimeString ( rtDW . eksra31szv . AQHandles ,
"500" , 500.0 , ssGetTFinal ( rtS ) ) ; sdiSetSignalRefRate ( rtDW .
eksra31szv . AQHandles , 0.0 ) ; sdiSetRunStartTime ( rtDW . eksra31szv .
AQHandles , ssGetTaskTime ( rtS , 3 ) ) ; sdiAsyncRepoSetSignalExportSettings
( rtDW . eksra31szv . AQHandles , 1 , 0 ) ; sdiAsyncRepoSetSignalExportName (
rtDW . eksra31szv . AQHandles , loggedName , origSigName , propName ) ; }
sdiFreeLabel ( sigName ) ; sdiFreeLabel ( loggedName ) ; sdiFreeLabel (
origSigName ) ; sdiFreeLabel ( propName ) ; sdiFreeLabel ( blockPath ) ;
sdiFreeLabel ( blockSID ) ; sdiFreeLabel ( subPath ) ; } } if ( !
isStreamoutAlreadyRegistered ) { } } } } { { { bool
isStreamoutAlreadyRegistered = false ; { sdiSignalSourceInfoU srcInfo ;
sdiLabelU loggedName = sdiGetLabelFromChars ( "" ) ; sdiLabelU origSigName =
sdiGetLabelFromChars ( "" ) ; sdiLabelU propName = sdiGetLabelFromChars ( ""
) ; sdiLabelU blockPath = sdiGetLabelFromChars (
"cstr_simulationEnv/CSTR_1 Simulation Model + Regulatory Control/Sum7" ) ;
sdiLabelU blockSID = sdiGetLabelFromChars ( "" ) ; sdiLabelU subPath =
sdiGetLabelFromChars ( "" ) ; sdiDims sigDims ; sdiLabelU sigName =
sdiGetLabelFromChars ( "" ) ; sdiAsyncRepoDataTypeHandle hDT =
sdiAsyncRepoGetBuiltInDataTypeHandle ( DATA_TYPE_DOUBLE ) ; { sdiComplexity
sigComplexity = REAL ; sdiSampleTimeContinuity stCont = SAMPLE_TIME_DISCRETE
; int_T sigDimsArray [ 1 ] = { 1 } ; sigDims . nDims = 1 ; sigDims .
dimensions = sigDimsArray ; srcInfo . numBlockPathElems = 1 ; srcInfo .
fullBlockPath = ( sdiFullBlkPathU ) & blockPath ; srcInfo . SID = (
sdiSignalIDU ) & blockSID ; srcInfo . subPath = subPath ; srcInfo . portIndex
= 0 + 1 ; srcInfo . signalName = sigName ; srcInfo . sigSourceUUID = 0 ; rtDW
. ahr1p51zrw . AQHandles = sdiStartAsyncioQueueCreation ( hDT , & srcInfo ,
rt_dataMapInfo . mmi . InstanceMap . fullPath ,
"b5eb5bbb-364e-4842-a98d-bf05cf7a1c0b" , sigComplexity , & sigDims ,
DIMENSIONS_MODE_FIXED , stCont , "" ) ; sdiCompleteAsyncioQueueCreation (
rtDW . ahr1p51zrw . AQHandles , hDT , & srcInfo ) ; if ( rtDW . ahr1p51zrw .
AQHandles ) { sdiSetSignalSampleTimeString ( rtDW . ahr1p51zrw . AQHandles ,
"1" , 1.0 , ssGetTFinal ( rtS ) ) ; sdiSetSignalRefRate ( rtDW . ahr1p51zrw .
AQHandles , 0.0 ) ; sdiSetRunStartTime ( rtDW . ahr1p51zrw . AQHandles ,
ssGetTaskTime ( rtS , 1 ) ) ; sdiAsyncRepoSetSignalExportSettings ( rtDW .
ahr1p51zrw . AQHandles , 1 , 0 ) ; sdiAsyncRepoSetSignalExportName ( rtDW .
ahr1p51zrw . AQHandles , loggedName , origSigName , propName ) ; }
sdiFreeLabel ( sigName ) ; sdiFreeLabel ( loggedName ) ; sdiFreeLabel (
origSigName ) ; sdiFreeLabel ( propName ) ; sdiFreeLabel ( blockPath ) ;
sdiFreeLabel ( blockSID ) ; sdiFreeLabel ( subPath ) ; } } if ( !
isStreamoutAlreadyRegistered ) { } } } } { { { bool
isStreamoutAlreadyRegistered = false ; { sdiSignalSourceInfoU srcInfo ;
sdiLabelU loggedName = sdiGetLabelFromChars ( "" ) ; sdiLabelU origSigName =
sdiGetLabelFromChars ( "" ) ; sdiLabelU propName = sdiGetLabelFromChars ( ""
) ; sdiLabelU blockPath = sdiGetLabelFromChars (
"cstr_simulationEnv/CSTR_1 Simulation Model + Regulatory Control/Switch1" ) ;
sdiLabelU blockSID = sdiGetLabelFromChars ( "" ) ; sdiLabelU subPath =
sdiGetLabelFromChars ( "" ) ; sdiDims sigDims ; sdiLabelU sigName =
sdiGetLabelFromChars ( "" ) ; sdiAsyncRepoDataTypeHandle hDT =
sdiAsyncRepoGetBuiltInDataTypeHandle ( DATA_TYPE_DOUBLE ) ; { sdiComplexity
sigComplexity = REAL ; sdiSampleTimeContinuity stCont = SAMPLE_TIME_DISCRETE
; int_T sigDimsArray [ 1 ] = { 1 } ; sigDims . nDims = 1 ; sigDims .
dimensions = sigDimsArray ; srcInfo . numBlockPathElems = 1 ; srcInfo .
fullBlockPath = ( sdiFullBlkPathU ) & blockPath ; srcInfo . SID = (
sdiSignalIDU ) & blockSID ; srcInfo . subPath = subPath ; srcInfo . portIndex
= 0 + 1 ; srcInfo . signalName = sigName ; srcInfo . sigSourceUUID = 0 ; rtDW
. fwpf1vdbdo . AQHandles = sdiStartAsyncioQueueCreation ( hDT , & srcInfo ,
rt_dataMapInfo . mmi . InstanceMap . fullPath ,
"8403bb25-d3a3-4485-9fc9-eb2f93296c5e" , sigComplexity , & sigDims ,
DIMENSIONS_MODE_FIXED , stCont , "" ) ; sdiCompleteAsyncioQueueCreation (
rtDW . fwpf1vdbdo . AQHandles , hDT , & srcInfo ) ; if ( rtDW . fwpf1vdbdo .
AQHandles ) { sdiSetSignalSampleTimeString ( rtDW . fwpf1vdbdo . AQHandles ,
"1" , 1.0 , ssGetTFinal ( rtS ) ) ; sdiSetSignalRefRate ( rtDW . fwpf1vdbdo .
AQHandles , 0.0 ) ; sdiSetRunStartTime ( rtDW . fwpf1vdbdo . AQHandles ,
ssGetTaskTime ( rtS , 1 ) ) ; sdiAsyncRepoSetSignalExportSettings ( rtDW .
fwpf1vdbdo . AQHandles , 1 , 0 ) ; sdiAsyncRepoSetSignalExportName ( rtDW .
fwpf1vdbdo . AQHandles , loggedName , origSigName , propName ) ; }
sdiFreeLabel ( sigName ) ; sdiFreeLabel ( loggedName ) ; sdiFreeLabel (
origSigName ) ; sdiFreeLabel ( propName ) ; sdiFreeLabel ( blockPath ) ;
sdiFreeLabel ( blockSID ) ; sdiFreeLabel ( subPath ) ; } } if ( !
isStreamoutAlreadyRegistered ) { } } } } { { { bool
isStreamoutAlreadyRegistered = false ; { sdiSignalSourceInfoU srcInfo ;
sdiLabelU loggedName = sdiGetLabelFromChars ( "" ) ; sdiLabelU origSigName =
sdiGetLabelFromChars ( "" ) ; sdiLabelU propName = sdiGetLabelFromChars ( ""
) ; sdiLabelU blockPath = sdiGetLabelFromChars (
"cstr_simulationEnv/CSTR_1 Simulation Model + Regulatory Control/Switch4" ) ;
sdiLabelU blockSID = sdiGetLabelFromChars ( "" ) ; sdiLabelU subPath =
sdiGetLabelFromChars ( "" ) ; sdiDims sigDims ; sdiLabelU sigName =
sdiGetLabelFromChars ( "" ) ; sdiAsyncRepoDataTypeHandle hDT =
sdiAsyncRepoGetBuiltInDataTypeHandle ( DATA_TYPE_DOUBLE ) ; { sdiComplexity
sigComplexity = REAL ; sdiSampleTimeContinuity stCont = SAMPLE_TIME_DISCRETE
; int_T sigDimsArray [ 1 ] = { 1 } ; sigDims . nDims = 1 ; sigDims .
dimensions = sigDimsArray ; srcInfo . numBlockPathElems = 1 ; srcInfo .
fullBlockPath = ( sdiFullBlkPathU ) & blockPath ; srcInfo . SID = (
sdiSignalIDU ) & blockSID ; srcInfo . subPath = subPath ; srcInfo . portIndex
= 0 + 1 ; srcInfo . signalName = sigName ; srcInfo . sigSourceUUID = 0 ; rtDW
. ciu3qjsht5 . AQHandles = sdiStartAsyncioQueueCreation ( hDT , & srcInfo ,
rt_dataMapInfo . mmi . InstanceMap . fullPath ,
"a6241bae-8ae7-4ff8-acb6-a83450b8627c" , sigComplexity , & sigDims ,
DIMENSIONS_MODE_FIXED , stCont , "" ) ; sdiCompleteAsyncioQueueCreation (
rtDW . ciu3qjsht5 . AQHandles , hDT , & srcInfo ) ; if ( rtDW . ciu3qjsht5 .
AQHandles ) { sdiSetSignalSampleTimeString ( rtDW . ciu3qjsht5 . AQHandles ,
"1" , 1.0 , ssGetTFinal ( rtS ) ) ; sdiSetSignalRefRate ( rtDW . ciu3qjsht5 .
AQHandles , 0.0 ) ; sdiSetRunStartTime ( rtDW . ciu3qjsht5 . AQHandles ,
ssGetTaskTime ( rtS , 1 ) ) ; sdiAsyncRepoSetSignalExportSettings ( rtDW .
ciu3qjsht5 . AQHandles , 1 , 0 ) ; sdiAsyncRepoSetSignalExportName ( rtDW .
ciu3qjsht5 . AQHandles , loggedName , origSigName , propName ) ; }
sdiFreeLabel ( sigName ) ; sdiFreeLabel ( loggedName ) ; sdiFreeLabel (
origSigName ) ; sdiFreeLabel ( propName ) ; sdiFreeLabel ( blockPath ) ;
sdiFreeLabel ( blockSID ) ; sdiFreeLabel ( subPath ) ; } } if ( !
isStreamoutAlreadyRegistered ) { } } } } { { { bool
isStreamoutAlreadyRegistered = false ; { sdiSignalSourceInfoU srcInfo ;
sdiLabelU loggedName = sdiGetLabelFromChars ( "" ) ; sdiLabelU origSigName =
sdiGetLabelFromChars ( "" ) ; sdiLabelU propName = sdiGetLabelFromChars ( ""
) ; sdiLabelU blockPath = sdiGetLabelFromChars (
"cstr_simulationEnv/CSTR_1 Simulation Model + Regulatory Control/Switch5" ) ;
sdiLabelU blockSID = sdiGetLabelFromChars ( "" ) ; sdiLabelU subPath =
sdiGetLabelFromChars ( "" ) ; sdiDims sigDims ; sdiLabelU sigName =
sdiGetLabelFromChars ( "" ) ; sdiAsyncRepoDataTypeHandle hDT =
sdiAsyncRepoGetBuiltInDataTypeHandle ( DATA_TYPE_DOUBLE ) ; { sdiComplexity
sigComplexity = REAL ; sdiSampleTimeContinuity stCont = SAMPLE_TIME_DISCRETE
; int_T sigDimsArray [ 1 ] = { 1 } ; sigDims . nDims = 1 ; sigDims .
dimensions = sigDimsArray ; srcInfo . numBlockPathElems = 1 ; srcInfo .
fullBlockPath = ( sdiFullBlkPathU ) & blockPath ; srcInfo . SID = (
sdiSignalIDU ) & blockSID ; srcInfo . subPath = subPath ; srcInfo . portIndex
= 0 + 1 ; srcInfo . signalName = sigName ; srcInfo . sigSourceUUID = 0 ; rtDW
. m2i42ofdw4 . AQHandles = sdiStartAsyncioQueueCreation ( hDT , & srcInfo ,
rt_dataMapInfo . mmi . InstanceMap . fullPath ,
"6c32cac2-2deb-49a0-80e4-46ec5ef4935d" , sigComplexity , & sigDims ,
DIMENSIONS_MODE_FIXED , stCont , "" ) ; sdiCompleteAsyncioQueueCreation (
rtDW . m2i42ofdw4 . AQHandles , hDT , & srcInfo ) ; if ( rtDW . m2i42ofdw4 .
AQHandles ) { sdiSetSignalSampleTimeString ( rtDW . m2i42ofdw4 . AQHandles ,
"1" , 1.0 , ssGetTFinal ( rtS ) ) ; sdiSetSignalRefRate ( rtDW . m2i42ofdw4 .
AQHandles , 0.0 ) ; sdiSetRunStartTime ( rtDW . m2i42ofdw4 . AQHandles ,
ssGetTaskTime ( rtS , 1 ) ) ; sdiAsyncRepoSetSignalExportSettings ( rtDW .
m2i42ofdw4 . AQHandles , 1 , 0 ) ; sdiAsyncRepoSetSignalExportName ( rtDW .
m2i42ofdw4 . AQHandles , loggedName , origSigName , propName ) ; }
sdiFreeLabel ( sigName ) ; sdiFreeLabel ( loggedName ) ; sdiFreeLabel (
origSigName ) ; sdiFreeLabel ( propName ) ; sdiFreeLabel ( blockPath ) ;
sdiFreeLabel ( blockSID ) ; sdiFreeLabel ( subPath ) ; } } if ( !
isStreamoutAlreadyRegistered ) { } } } } { { { bool
isStreamoutAlreadyRegistered = false ; { sdiSignalSourceInfoU srcInfo ;
sdiLabelU loggedName = sdiGetLabelFromChars ( "" ) ; sdiLabelU origSigName =
sdiGetLabelFromChars ( "" ) ; sdiLabelU propName = sdiGetLabelFromChars ( ""
) ; sdiLabelU blockPath = sdiGetLabelFromChars (
"cstr_simulationEnv/CSTR_1 Simulation Model + Regulatory Control/Switch6" ) ;
sdiLabelU blockSID = sdiGetLabelFromChars ( "" ) ; sdiLabelU subPath =
sdiGetLabelFromChars ( "" ) ; sdiDims sigDims ; sdiLabelU sigName =
sdiGetLabelFromChars ( "" ) ; sdiAsyncRepoDataTypeHandle hDT =
sdiAsyncRepoGetBuiltInDataTypeHandle ( DATA_TYPE_DOUBLE ) ; { sdiComplexity
sigComplexity = REAL ; sdiSampleTimeContinuity stCont = SAMPLE_TIME_DISCRETE
; int_T sigDimsArray [ 1 ] = { 1 } ; sigDims . nDims = 1 ; sigDims .
dimensions = sigDimsArray ; srcInfo . numBlockPathElems = 1 ; srcInfo .
fullBlockPath = ( sdiFullBlkPathU ) & blockPath ; srcInfo . SID = (
sdiSignalIDU ) & blockSID ; srcInfo . subPath = subPath ; srcInfo . portIndex
= 0 + 1 ; srcInfo . signalName = sigName ; srcInfo . sigSourceUUID = 0 ; rtDW
. frknafxvto . AQHandles = sdiStartAsyncioQueueCreation ( hDT , & srcInfo ,
rt_dataMapInfo . mmi . InstanceMap . fullPath ,
"cd4cf2f7-a49a-44fc-b757-4542c7bd048d" , sigComplexity , & sigDims ,
DIMENSIONS_MODE_FIXED , stCont , "" ) ; sdiCompleteAsyncioQueueCreation (
rtDW . frknafxvto . AQHandles , hDT , & srcInfo ) ; if ( rtDW . frknafxvto .
AQHandles ) { sdiSetSignalSampleTimeString ( rtDW . frknafxvto . AQHandles ,
"1" , 1.0 , ssGetTFinal ( rtS ) ) ; sdiSetSignalRefRate ( rtDW . frknafxvto .
AQHandles , 0.0 ) ; sdiSetRunStartTime ( rtDW . frknafxvto . AQHandles ,
ssGetTaskTime ( rtS , 1 ) ) ; sdiAsyncRepoSetSignalExportSettings ( rtDW .
frknafxvto . AQHandles , 1 , 0 ) ; sdiAsyncRepoSetSignalExportName ( rtDW .
frknafxvto . AQHandles , loggedName , origSigName , propName ) ; }
sdiFreeLabel ( sigName ) ; sdiFreeLabel ( loggedName ) ; sdiFreeLabel (
origSigName ) ; sdiFreeLabel ( propName ) ; sdiFreeLabel ( blockPath ) ;
sdiFreeLabel ( blockSID ) ; sdiFreeLabel ( subPath ) ; } } if ( !
isStreamoutAlreadyRegistered ) { } } } } { { { bool
isStreamoutAlreadyRegistered = false ; { sdiSignalSourceInfoU srcInfo ;
sdiLabelU loggedName = sdiGetLabelFromChars ( "" ) ; sdiLabelU origSigName =
sdiGetLabelFromChars ( "" ) ; sdiLabelU propName = sdiGetLabelFromChars ( ""
) ; sdiLabelU blockPath = sdiGetLabelFromChars (
"cstr_simulationEnv/CSTR_1 Simulation Model + Regulatory Control/Switch7" ) ;
sdiLabelU blockSID = sdiGetLabelFromChars ( "" ) ; sdiLabelU subPath =
sdiGetLabelFromChars ( "" ) ; sdiDims sigDims ; sdiLabelU sigName =
sdiGetLabelFromChars ( "" ) ; sdiAsyncRepoDataTypeHandle hDT =
sdiAsyncRepoGetBuiltInDataTypeHandle ( DATA_TYPE_DOUBLE ) ; { sdiComplexity
sigComplexity = REAL ; sdiSampleTimeContinuity stCont = SAMPLE_TIME_DISCRETE
; int_T sigDimsArray [ 1 ] = { 1 } ; sigDims . nDims = 1 ; sigDims .
dimensions = sigDimsArray ; srcInfo . numBlockPathElems = 1 ; srcInfo .
fullBlockPath = ( sdiFullBlkPathU ) & blockPath ; srcInfo . SID = (
sdiSignalIDU ) & blockSID ; srcInfo . subPath = subPath ; srcInfo . portIndex
= 0 + 1 ; srcInfo . signalName = sigName ; srcInfo . sigSourceUUID = 0 ; rtDW
. blapbcem3w . AQHandles = sdiStartAsyncioQueueCreation ( hDT , & srcInfo ,
rt_dataMapInfo . mmi . InstanceMap . fullPath ,
"e8bc1d71-2aa5-4b54-9a53-eb5b7114c28f" , sigComplexity , & sigDims ,
DIMENSIONS_MODE_FIXED , stCont , "" ) ; sdiCompleteAsyncioQueueCreation (
rtDW . blapbcem3w . AQHandles , hDT , & srcInfo ) ; if ( rtDW . blapbcem3w .
AQHandles ) { sdiSetSignalSampleTimeString ( rtDW . blapbcem3w . AQHandles ,
"1" , 1.0 , ssGetTFinal ( rtS ) ) ; sdiSetSignalRefRate ( rtDW . blapbcem3w .
AQHandles , 0.0 ) ; sdiSetRunStartTime ( rtDW . blapbcem3w . AQHandles ,
ssGetTaskTime ( rtS , 1 ) ) ; sdiAsyncRepoSetSignalExportSettings ( rtDW .
blapbcem3w . AQHandles , 1 , 0 ) ; sdiAsyncRepoSetSignalExportName ( rtDW .
blapbcem3w . AQHandles , loggedName , origSigName , propName ) ; }
sdiFreeLabel ( sigName ) ; sdiFreeLabel ( loggedName ) ; sdiFreeLabel (
origSigName ) ; sdiFreeLabel ( propName ) ; sdiFreeLabel ( blockPath ) ;
sdiFreeLabel ( blockSID ) ; sdiFreeLabel ( subPath ) ; } } if ( !
isStreamoutAlreadyRegistered ) { } } } } { { { bool
isStreamoutAlreadyRegistered = false ; { sdiSignalSourceInfoU srcInfo ;
sdiLabelU loggedName = sdiGetLabelFromChars ( "" ) ; sdiLabelU origSigName =
sdiGetLabelFromChars ( "" ) ; sdiLabelU propName = sdiGetLabelFromChars ( ""
) ; sdiLabelU blockPath = sdiGetLabelFromChars (
"cstr_simulationEnv/CSTR_1 Simulation Model + Regulatory Control/Switch" ) ;
sdiLabelU blockSID = sdiGetLabelFromChars ( "" ) ; sdiLabelU subPath =
sdiGetLabelFromChars ( "" ) ; sdiDims sigDims ; sdiLabelU sigName =
sdiGetLabelFromChars ( "" ) ; sdiAsyncRepoDataTypeHandle hDT =
sdiAsyncRepoGetBuiltInDataTypeHandle ( DATA_TYPE_DOUBLE ) ; { sdiComplexity
sigComplexity = REAL ; sdiSampleTimeContinuity stCont =
SAMPLE_TIME_CONTINUOUS ; int_T sigDimsArray [ 1 ] = { 1 } ; sigDims . nDims =
1 ; sigDims . dimensions = sigDimsArray ; srcInfo . numBlockPathElems = 1 ;
srcInfo . fullBlockPath = ( sdiFullBlkPathU ) & blockPath ; srcInfo . SID = (
sdiSignalIDU ) & blockSID ; srcInfo . subPath = subPath ; srcInfo . portIndex
= 0 + 1 ; srcInfo . signalName = sigName ; srcInfo . sigSourceUUID = 0 ; rtDW
. ekmy53hjdg . AQHandles = sdiStartAsyncioQueueCreation ( hDT , & srcInfo ,
rt_dataMapInfo . mmi . InstanceMap . fullPath ,
"eaaeb4e0-3a36-452c-a013-38039fb916b8" , sigComplexity , & sigDims ,
DIMENSIONS_MODE_FIXED , stCont , "" ) ; sdiCompleteAsyncioQueueCreation (
rtDW . ekmy53hjdg . AQHandles , hDT , & srcInfo ) ; if ( rtDW . ekmy53hjdg .
AQHandles ) { sdiSetSignalSampleTimeString ( rtDW . ekmy53hjdg . AQHandles ,
"1" , 1.0 , ssGetTFinal ( rtS ) ) ; sdiSetSignalRefRate ( rtDW . ekmy53hjdg .
AQHandles , 0.0 ) ; sdiSetRunStartTime ( rtDW . ekmy53hjdg . AQHandles ,
ssGetTaskTime ( rtS , 1 ) ) ; sdiAsyncRepoSetSignalExportSettings ( rtDW .
ekmy53hjdg . AQHandles , 1 , 0 ) ; sdiAsyncRepoSetSignalExportName ( rtDW .
ekmy53hjdg . AQHandles , loggedName , origSigName , propName ) ; }
sdiFreeLabel ( sigName ) ; sdiFreeLabel ( loggedName ) ; sdiFreeLabel (
origSigName ) ; sdiFreeLabel ( propName ) ; sdiFreeLabel ( blockPath ) ;
sdiFreeLabel ( blockSID ) ; sdiFreeLabel ( subPath ) ; } } if ( !
isStreamoutAlreadyRegistered ) { } } } } rtB . d5u0rvgiee = rtP .
Feed_Temperature_In_Value ; rtB . k3xz1ht2ij = rtP .
Feed_Temperature_Out_Value ; rtB . iorisswymh = rtP . Inlet_Flow_In_Value ;
rtB . l4lnonwfg2 = rtP . Inlet_Flow_Out_Value ; { FWksInfo * fromwksInfo ; if
( ( fromwksInfo = ( FWksInfo * ) calloc ( 1 , sizeof ( FWksInfo ) ) ) == (
NULL ) ) { ssSetErrorStatus ( rtS ,
"from workspace STRING(Name) memory allocation error" ) ; } else {
fromwksInfo -> origWorkspaceVarName = "x1" ; fromwksInfo -> origDataTypeId =
0 ; fromwksInfo -> origIsComplex = 0 ; fromwksInfo -> origWidth = 1 ;
fromwksInfo -> origElSize = sizeof ( real_T ) ; fromwksInfo -> data = ( void
* ) rtP . FromWorkspace_Data0 ; fromwksInfo -> nDataPoints = 5001 ;
fromwksInfo -> time = ( double * ) rtP . FromWorkspace_Time0 ; rtDW .
e0u1digqih . TimePtr = fromwksInfo -> time ; rtDW . e0u1digqih . DataPtr =
fromwksInfo -> data ; rtDW . e0u1digqih . RSimInfoPtr = fromwksInfo ; } rtDW
. f4gzzk1cad . PrevIndex = 0 ; } { FWksInfo * fromwksInfo ; if ( (
fromwksInfo = ( FWksInfo * ) calloc ( 1 , sizeof ( FWksInfo ) ) ) == ( NULL )
) { ssSetErrorStatus ( rtS ,
"from workspace STRING(Name) memory allocation error" ) ; } else {
fromwksInfo -> origWorkspaceVarName = "x2" ; fromwksInfo -> origDataTypeId =
0 ; fromwksInfo -> origIsComplex = 0 ; fromwksInfo -> origWidth = 1 ;
fromwksInfo -> origElSize = sizeof ( real_T ) ; fromwksInfo -> data = ( void
* ) rtP . FromWorkspace1_Data0 ; fromwksInfo -> nDataPoints = 5001 ;
fromwksInfo -> time = ( double * ) rtP . FromWorkspace1_Time0 ; rtDW .
ddqlrilmhr . TimePtr = fromwksInfo -> time ; rtDW . ddqlrilmhr . DataPtr =
fromwksInfo -> data ; rtDW . ddqlrilmhr . RSimInfoPtr = fromwksInfo ; } rtDW
. gizzljrotf . PrevIndex = 0 ; } { void * fp = ( NULL ) ; const char *
fileNameOriginal = "out_data.mat" ; char * fileName = ( char * ) malloc ( 509
) ; if ( fileName == ( NULL ) ) { ssSetErrorStatus ( rtS ,
"Error allocating memory for file name" ) ; return ; } strcpy ( fileName ,
fileNameOriginal ) ; { const char * blockpath =
"cstr_simulationEnv/CSTR_1\nSimulation Model + Regulatory Control/To File" ;
if ( slIsRapidAcceleratorSimulating ( ) ) { rt_RAccelReplaceToFilename (
blockpath , fileName ) ; } } { const char * errMsg = ( NULL ) ; errMsg =
rtwH5LoggingCollectionCreateInstance ( 1 , & fp , rtliGetLoggingInterval (
ssGetRootSS ( rtS ) -> mdlInfo -> rtwLogInfo ) ) ; if ( errMsg != ( NULL ) )
{ ssSetErrorStatus ( rtS , errMsg ) ; return ; } { int_T dimensions [ 1 ] = {
23 } ; errMsg = rtwH5LoggingCollectionAddElement ( 1 , fp , fileName , "cstr"
, 0 , "" , "linear" , "double" , 1 , dimensions , 0 , 1 , 1 , 0 , 0 , 0 , 0 ,
0 , 0 , 0 ) ; } if ( errMsg != ( NULL ) ) { ssSetErrorStatus ( rtS , errMsg )
; return ; } } if ( fileName != ( NULL ) ) { free ( fileName ) ; } rtDW .
bttm2sqgp0 . Count = 0 ; rtDW . bttm2sqgp0 . Decimation = - 1 ; rtDW .
aw4of2bzto . FilePtr = fp ; } MdlInitialize ( ) ; } void MdlOutputs ( int_T
tid ) { real_T nuxxem3eon ; real_T cl1tnmdvcy ; real_T ijwfmqzqly [ 23 ] ;
real_T htg3s421yl ; real_T l03sxfnt5m ; real_T lhb5brsu1h ; real_T p1hmzyi4p0
; uint32_T t ; boolean_T guard1 = false ; srClearBC ( rtDW . lvdmxslirzu .
ec3xwiqauu ) ; srClearBC ( rtDW . lsul0j3thv5 . b0jtmkqrl5 ) ; srClearBC (
rtDW . o0l0tlmums2 . nmoh1fygpu ) ; srClearBC ( rtDW . e5i1gkys053 .
iaiukld4k4 ) ; if ( ssIsSampleHit ( rtS , 2 , 0 ) ) { rtB . bano4r405l = rtDW
. bv534fxrfq ; } if ( ssIsSampleHit ( rtS , 1 , 0 ) ) { rtB . gnzysggnk4 =
rtDW . i3eqa0qza0 ; if ( rtP . ConsiderFault1_CurrentSetting == 1 ) {
p1hmzyi4p0 = rtP . Constant11_Value_jvwwu02wty ; } else { p1hmzyi4p0 = rtP .
Constant12_Value_ce5osxgbbp ; } if ( rtB . bano4r405l * p1hmzyi4p0 > rtP .
Switch4_Threshold ) { rtB . pwkazhfzxj = rtP . Constant13_Value_jemti03zwx ;
} else { rtB . pwkazhfzxj = rtDW . fudylxbq0j - ( real_T ) rtB . gnzysggnk4 ;
} } if ( rtB . pwkazhfzxj > rtP . Switch5_Threshold ) { if ( ssGetTaskTime (
rtS , 0 ) < rtP . Ramp_start ) { p1hmzyi4p0 = rtP . Step_Y0 ; } else {
p1hmzyi4p0 = rtP . Ramp_slope ; } p1hmzyi4p0 = ( ssGetT ( rtS ) - rtP .
Ramp_start ) * p1hmzyi4p0 + rtP . Ramp_InitialOutput ; } else { p1hmzyi4p0 =
rtP . Constant_Value_lg13tpamfv ; } if ( p1hmzyi4p0 > rtP .
Saturation_UpperSat ) { rtB . dztq1uxeww = rtP . Saturation_UpperSat ; } else
if ( p1hmzyi4p0 < rtP . Saturation_LowerSat ) { rtB . dztq1uxeww = rtP .
Saturation_LowerSat ; } else { rtB . dztq1uxeww = p1hmzyi4p0 ; } if (
ssIsSampleHit ( rtS , 1 , 0 ) ) { { if ( rtDW . odihpq11te . AQHandles &&
ssGetLogOutput ( rtS ) ) { sdiWriteSignal ( rtDW . odihpq11te . AQHandles ,
ssGetTaskTime ( rtS , 1 ) , ( char * ) & rtB . dztq1uxeww + 0 ) ; } } } if (
ssIsSampleHit ( rtS , 2 , 0 ) ) { rtB . imj24wyej4 = rtDW . bgotvck1y4 ; } if
( ssIsSampleHit ( rtS , 1 , 0 ) ) { rtB . hdnlmp40uy = rtDW . agio50d4gu ; if
( rtP . ConsiderFault11_CurrentSetting == 1 ) { p1hmzyi4p0 = rtP .
Constant40_Value ; } else { p1hmzyi4p0 = rtP . Constant41_Value ; } if ( rtB
. imj24wyej4 * p1hmzyi4p0 > rtP . Switch22_Threshold ) { rtB . bd3otgosaa =
rtP . Constant42_Value ; } else { rtB . bd3otgosaa = rtDW . dfulppyfs1 - (
real_T ) rtB . hdnlmp40uy ; } if ( rtB . bd3otgosaa > rtP .
Switch23_Threshold ) { rtB . mcsqmnaiu3 = rtP . Constant44_Value ; } else {
rtB . mcsqmnaiu3 = rtP . Constant43_Value ; } { if ( rtDW . jsnyah43h5 .
AQHandles && ssGetLogOutput ( rtS ) ) { sdiWriteSignal ( rtDW . jsnyah43h5 .
AQHandles , ssGetTaskTime ( rtS , 1 ) , ( char * ) & rtB . mcsqmnaiu3 + 0 ) ;
} } } if ( ssIsSampleHit ( rtS , 2 , 0 ) ) { rtB . cx2r4dbgvi = rtDW .
o0jhm5tqhv ; } if ( ssIsSampleHit ( rtS , 1 , 0 ) ) { rtB . euqxsw55q1 = rtDW
. g10sbzotef ; if ( rtP . ConsiderFault7_CurrentSetting == 1 ) { p1hmzyi4p0 =
rtP . Constant29_Value ; } else { p1hmzyi4p0 = rtP . Constant30_Value ; } if
( rtB . cx2r4dbgvi * p1hmzyi4p0 > rtP . Switch13_Threshold ) { rtB .
fnykzau3dd = rtP . Constant31_Value ; } else { rtB . fnykzau3dd = rtDW .
gymfbya0lf - ( real_T ) rtB . euqxsw55q1 ; } if ( rtB . fnykzau3dd > rtP .
Switch14_Threshold ) { rtB . bzuganxdf2 = rtP . Constant33_Value ; } else {
rtB . bzuganxdf2 = rtP . Constant32_Value ; } { if ( rtDW . ggzqve4ryn .
AQHandles && ssGetLogOutput ( rtS ) ) { sdiWriteSignal ( rtDW . ggzqve4ryn .
AQHandles , ssGetTaskTime ( rtS , 1 ) , ( char * ) & rtB . bzuganxdf2 + 0 ) ;
} } rtB . mdshgnp3xt = rtDW . mz0zdu34tn ; rtB . c1djdqayjj = rtDW .
cronjwvq3j ; rtB . h1nl0bfw4n = rtDW . dsnlclvjlf ; rtB . oqv2owxgui = rtDW .
nfi0353erc ; if ( rtDW . csce1vtaiv < 511U ) { rtDW . csce1vtaiv ++ ; } rtDW
. dx0psck2g2 = jh4s05c31l ; if ( rtDW . jraid5zlrs == 0U ) { rtDW .
jraid5zlrs = 1U ; rtDW . arjuzvir0v = enqrwwow5y ; rtDW . a3naafic3w =
dzcgoxakfb ; rtDW . csce1vtaiv = 0U ; rtB . gvytu245ky = rtB . iorisswymh +
0.5 ; rtB . ai311bapfw = rtB . d5u0rvgiee + 2.0 ; } else { guard1 = false ;
switch ( rtDW . a3naafic3w ) { case aodw1v54cb : if ( rtB . gnzysggnk4 || rtB
. hdnlmp40uy || rtB . euqxsw55q1 ) { rtDW . ksqmuzqxoq = kluzj30pzp ; rtDW .
a3naafic3w = arhac2lfsx ; rtDW . g0pte1h22i = if0vy5gd2y ; rtB . gvytu245ky =
rtB . iorisswymh ; rtB . ai311bapfw = rtB . d5u0rvgiee ; rtB . nr5jzefs11 =
false ; rtB . g4otcjhaps = false ; rtB . c50enbqbhd = false ; } else { switch
( rtDW . ksqmuzqxoq ) { case grkerkr1hy : if ( ( rtB . mdshgnp3xt < 0.5 ) &&
( ! rtB . nr5jzefs11 ) ) { rtDW . ksqmuzqxoq = djp1q2gbzd ; rtB . nr5jzefs11
= true ; } else if ( ( rtB . h1nl0bfw4n == 0.0 ) && ( ! rtB . g4otcjhaps ) )
{ rtDW . ksqmuzqxoq = osk10zz3aw ; rtB . g4otcjhaps = true ; } else if ( (
rtB . oqv2owxgui > 400.0 ) && ( ! rtB . c50enbqbhd ) ) { rtDW . ksqmuzqxoq =
cjeyefob4c ; rtB . c50enbqbhd = true ; } break ; case djp1q2gbzd : rtB .
nr5jzefs11 = true ; break ; case osk10zz3aw : rtB . g4otcjhaps = true ; break
; default : rtB . c50enbqbhd = true ; break ; } } break ; case mfbquags3t :
if ( rtDW . csce1vtaiv >= 500U ) { rtDW . a3naafic3w = muyrihtp2b ; rtDW .
hjgrew42b2 = 1U ; rtB . ftctw2pua5 = rtB . mdshgnp3xt ; o0l0tlmums ( rtB .
ftctw2pua5 , & rtB . o0l0tlmums2 , & rtDW . o0l0tlmums2 , & rtP . o0l0tlmums2
) ; rtB . gvytu245ky = rtB . o0l0tlmums2 . ebzcxl42h5 ; rtDW . ntbs21hax4 =
1U ; rtB . c110xhgmn1 = rtB . c1djdqayjj ; e5i1gkys05 ( rtB . c110xhgmn1 , &
rtB . e5i1gkys053 , & rtDW . e5i1gkys053 , & rtP . e5i1gkys053 ) ; rtB .
ai311bapfw = rtB . e5i1gkys053 . nyju2jnyn3 ; } else if ( ( rtB . mdshgnp3xt
< 0.5 ) || ( rtB . h1nl0bfw4n == 0.0 ) || ( rtB . oqv2owxgui > 500.0 ) ) {
rtDW . a3naafic3w = aodw1v54cb ; rtDW . ksqmuzqxoq = grkerkr1hy ; } break ;
case dzcgoxakfb : if ( rtDW . csce1vtaiv >= 50U ) { rtDW . a3naafic3w =
jic5t24gfv ; rtDW . eyqkltgelg = 1U ; rtB . htmpoa25zx = rtB . mdshgnp3xt ;
lvdmxslirz ( rtB . htmpoa25zx , & rtB . lvdmxslirzu , & rtDW . lvdmxslirzu ,
& rtP . lvdmxslirzu ) ; rtB . gvytu245ky = rtB . lvdmxslirzu . ppbrf42mvn ;
rtDW . il0ohwuds5 = 1U ; rtB . nehncd51lh = rtB . ai311bapfw ; lsul0j3thv (
rtB . nehncd51lh , & rtB . lsul0j3thv5 , & rtDW . lsul0j3thv5 , & rtP .
lsul0j3thv5 ) ; rtB . ai311bapfw = rtB . lsul0j3thv5 . nzhrh1tkt0 ; } break ;
case muyrihtp2b : if ( ( rtB . mdshgnp3xt <= rtB . iorisswymh ) && ( rtB .
c1djdqayjj <= rtB . d5u0rvgiee ) ) { rtDW . ntbs21hax4 = 0U ; rtDW .
hjgrew42b2 = 0U ; rtDW . a3naafic3w = arhac2lfsx ; rtDW . g0pte1h22i =
cjniwsoxiu ; rtDW . csce1vtaiv = 0U ; } else if ( ( rtB . mdshgnp3xt >= rtB .
iorisswymh ) || ( rtB . c1djdqayjj >= rtB . d5u0rvgiee ) ) { rtDW .
ntbs21hax4 = 0U ; rtDW . a3naafic3w = muyrihtp2b ; rtDW . hjgrew42b2 = 1U ;
rtB . ftctw2pua5 = rtB . mdshgnp3xt ; o0l0tlmums ( rtB . ftctw2pua5 , & rtB .
o0l0tlmums2 , & rtDW . o0l0tlmums2 , & rtP . o0l0tlmums2 ) ; rtB . gvytu245ky
= rtB . o0l0tlmums2 . ebzcxl42h5 ; rtDW . ntbs21hax4 = 1U ; rtB . c110xhgmn1
= rtB . c1djdqayjj ; e5i1gkys05 ( rtB . c110xhgmn1 , & rtB . e5i1gkys053 , &
rtDW . e5i1gkys053 , & rtP . e5i1gkys053 ) ; rtB . ai311bapfw = rtB .
e5i1gkys053 . nyju2jnyn3 ; } else if ( rtB . oqv2owxgui > 500.0 ) { rtDW .
ntbs21hax4 = 0U ; rtDW . hjgrew42b2 = 0U ; rtDW . a3naafic3w = aodw1v54cb ;
rtDW . ksqmuzqxoq = grkerkr1hy ; } break ; case jic5t24gfv : if ( ( rtB .
mdshgnp3xt >= rtB . l4lnonwfg2 ) && ( rtB . c1djdqayjj >= rtB . k3xz1ht2ij )
) { rtDW . il0ohwuds5 = 0U ; rtDW . eyqkltgelg = 0U ; rtDW . a3naafic3w =
mfbquags3t ; rtDW . csce1vtaiv = 0U ; } else if ( ( rtB . mdshgnp3xt < rtB .
l4lnonwfg2 ) && ( rtB . mdshgnp3xt > 0.0 ) ) { guard1 = true ; } else if ( (
rtB . mdshgnp3xt < 0.5 ) || ( rtB . h1nl0bfw4n == 0.0 ) || ( rtB . oqv2owxgui
> 500.0 ) ) { rtDW . il0ohwuds5 = 0U ; rtDW . eyqkltgelg = 0U ; rtDW .
a3naafic3w = aodw1v54cb ; rtDW . ksqmuzqxoq = grkerkr1hy ; } else if ( rtB .
c1djdqayjj < rtB . k3xz1ht2ij ) { guard1 = true ; } break ; default : if (
rtDW . g0pte1h22i == cjniwsoxiu ) { if ( rtDW . csce1vtaiv >= 300U ) { rtDW .
g0pte1h22i = kluzj30pzp ; rtDW . a3naafic3w = dzcgoxakfb ; rtDW . csce1vtaiv
= 0U ; rtB . gvytu245ky = rtB . iorisswymh + 0.5 ; rtB . ai311bapfw = rtB .
d5u0rvgiee + 2.0 ; } } else { rtB . nr5jzefs11 = false ; rtB . g4otcjhaps =
false ; rtB . c50enbqbhd = false ; rtDW . g0pte1h22i = cjniwsoxiu ; rtDW .
csce1vtaiv = 0U ; } break ; } if ( guard1 ) { rtDW . il0ohwuds5 = 0U ; rtDW .
a3naafic3w = jic5t24gfv ; rtDW . eyqkltgelg = 1U ; rtB . htmpoa25zx = rtB .
mdshgnp3xt ; lvdmxslirz ( rtB . htmpoa25zx , & rtB . lvdmxslirzu , & rtDW .
lvdmxslirzu , & rtP . lvdmxslirzu ) ; rtB . gvytu245ky = rtB . lvdmxslirzu .
ppbrf42mvn ; rtDW . il0ohwuds5 = 1U ; rtB . nehncd51lh = rtB . ai311bapfw ;
lsul0j3thv ( rtB . nehncd51lh , & rtB . lsul0j3thv5 , & rtDW . lsul0j3thv5 ,
& rtP . lsul0j3thv5 ) ; rtB . ai311bapfw = rtB . lsul0j3thv5 . nzhrh1tkt0 ; }
} rtB . lrowya24l3 = rtDW . g5guutg2r4 ; if ( rtDW . ifylc1ayya <
MAX_uint32_T ) { rtDW . ifylc1ayya ++ ; } rtDW . bv5o5ntfep = jh4s05c31l ; if
( rtDW . cuxelkmbzn == 0U ) { rtDW . cuxelkmbzn = 1U ; rtDW . cnphnmyixz =
ggkjqvtxz1 ; rtB . gfgfscs3wh = false ; } else { switch ( rtDW . cnphnmyixz )
{ case l4sas1urex : if ( ! rtB . nr5jzefs11 ) { rtDW . o5lpscgpim =
kluzj30pzp ; rtDW . lyrzf3l331 = kluzj30pzp ; rtDW . cnphnmyixz = ggkjqvtxz1
; rtB . gfgfscs3wh = false ; } else { switch ( rtDW . lyrzf3l331 ) { case
nyrhxonrdt : rtDW . lyrzf3l331 = njrbss2svy ; rtDW . o5lpscgpim = pnztcweof2
; rtDW . ifylc1ayya = 0U ; break ; case h1zo3wxret : rtDW . lyrzf3l331 =
nyrhxonrdt ; break ; default : switch ( rtDW . o5lpscgpim ) { case pnztcweof2
: t = ( uint32_T ) muDoubleScalarCeil ( 10.0 * gesahh5glk ( ) + 10.0 ) ; if (
rtDW . ifylc1ayya >= t ) { rtDW . o5lpscgpim = hn1hwvtdtn ; rtDW . ifylc1ayya
= 0U ; rtB . llcmsauyav = true ; } break ; case lgpwfbpmih : rtB . govtsadkmh
= true ; if ( rtB . lrowya24l3 <= 20.0 ) { rtDW . o5lpscgpim = mp40lbzaqx ;
rtDW . ifylc1ayya = 0U ; rtB . govtsadkmh = false ; } break ; case mp40lbzaqx
: rtB . govtsadkmh = false ; t = ( uint32_T ) muDoubleScalarCeil ( 50.0 *
gesahh5glk ( ) + 50.0 ) ; if ( rtDW . ifylc1ayya >= t ) { rtDW . o5lpscgpim =
dqjw2epu13 ; rtB . llcmsauyav = false ; rtB . koa2xwzkqz = false ; rtB .
gfgfscs3wh = true ; } break ; case dqjw2epu13 : rtB . llcmsauyav = false ;
rtB . koa2xwzkqz = false ; rtB . gfgfscs3wh = true ; break ; case fu5ii0d3lp
: rtB . koa2xwzkqz = true ; if ( rtDW . ifylc1ayya >= 20U ) { rtDW .
o5lpscgpim = lgpwfbpmih ; rtB . govtsadkmh = true ; } break ; default : rtB .
llcmsauyav = true ; if ( rtDW . ifylc1ayya >= 20U ) { rtDW . o5lpscgpim =
fu5ii0d3lp ; rtDW . ifylc1ayya = 0U ; rtB . koa2xwzkqz = true ; } break ; }
break ; } } break ; case p5vaeqbl3t : if ( ! rtB . g4otcjhaps ) { rtDW .
puvxpdyspy = kluzj30pzp ; rtDW . i33gdokzps = kluzj30pzp ; rtDW . cnphnmyixz
= ggkjqvtxz1 ; rtB . gfgfscs3wh = false ; } else { switch ( rtDW . i33gdokzps
) { case nyrhxonrdt : rtDW . i33gdokzps = njrbss2svy ; rtDW . puvxpdyspy =
pnztcweof2 ; rtDW . ifylc1ayya = 0U ; break ; case h1zo3wxret : rtDW .
i33gdokzps = nyrhxonrdt ; break ; default : switch ( rtDW . puvxpdyspy ) {
case pnztcweof2 : t = ( uint32_T ) muDoubleScalarCeil ( 10.0 * gesahh5glk ( )
+ 10.0 ) ; if ( rtDW . ifylc1ayya >= t ) { rtDW . puvxpdyspy = bpmqxywv4s ;
rtDW . ifylc1ayya = 0U ; rtB . ipy2o045sf = true ; } break ; case lgpwfbpmih
: rtB . govtsadkmh = true ; if ( rtB . lrowya24l3 <= 20.0 ) { rtDW .
puvxpdyspy = mp40lbzaqx ; rtDW . ifylc1ayya = 0U ; rtB . govtsadkmh = false ;
} break ; case mp40lbzaqx : rtB . govtsadkmh = false ; t = ( uint32_T )
muDoubleScalarCeil ( 50.0 * gesahh5glk ( ) + 50.0 ) ; if ( rtDW . ifylc1ayya
>= t ) { rtDW . puvxpdyspy = i00hab4fzi ; rtB . hwlkc3gph4 = true ; rtB .
ipy2o045sf = false ; rtB . koa2xwzkqz = false ; } break ; case i00hab4fzi :
rtB . hwlkc3gph4 = true ; rtB . ipy2o045sf = false ; rtB . koa2xwzkqz = false
; break ; case fu5ii0d3lp : rtB . koa2xwzkqz = true ; if ( rtDW . ifylc1ayya
>= 20U ) { rtDW . puvxpdyspy = lgpwfbpmih ; rtB . govtsadkmh = true ; } break
; default : rtB . ipy2o045sf = true ; if ( rtDW . ifylc1ayya >= 20U ) { rtDW
. puvxpdyspy = fu5ii0d3lp ; rtDW . ifylc1ayya = 0U ; rtB . koa2xwzkqz = true
; } break ; } break ; } } break ; case o2nxiy3ufc : if ( ! rtB . c50enbqbhd )
{ rtDW . b2oh0gakei = kluzj30pzp ; rtDW . hvipzkfxby = kluzj30pzp ; rtDW .
cnphnmyixz = ggkjqvtxz1 ; rtB . gfgfscs3wh = false ; } else { switch ( rtDW .
hvipzkfxby ) { case nyrhxonrdt : rtDW . hvipzkfxby = njrbss2svy ; rtDW .
b2oh0gakei = pnztcweof2 ; rtDW . ifylc1ayya = 0U ; break ; case h1zo3wxret :
rtDW . hvipzkfxby = nyrhxonrdt ; break ; default : switch ( rtDW . b2oh0gakei
) { case pnztcweof2 : t = ( uint32_T ) muDoubleScalarCeil ( 10.0 * gesahh5glk
( ) + 10.0 ) ; if ( rtDW . ifylc1ayya >= t ) { rtDW . b2oh0gakei = ecuq3htc1w
; rtDW . ifylc1ayya = 0U ; rtB . ggozffptrp = true ; } break ; case
ecuq3htc1w : rtB . ggozffptrp = true ; if ( rtDW . ifylc1ayya >= 30U ) { rtDW
. b2oh0gakei = mp40lbzaqx ; rtDW . ifylc1ayya = 0U ; } break ; case
mp40lbzaqx : t = ( uint32_T ) muDoubleScalarCeil ( 50.0 * gesahh5glk ( ) +
50.0 ) ; if ( rtDW . ifylc1ayya >= t ) { rtDW . b2oh0gakei = dqjw2epu13 ; rtB
. ggozffptrp = false ; rtB . ln01g2x54f = true ; } break ; default : rtB .
ggozffptrp = false ; rtB . ln01g2x54f = true ; break ; } break ; } } break ;
default : rtB . gfgfscs3wh = false ; if ( rtB . nr5jzefs11 ) { rtDW .
cnphnmyixz = l4sas1urex ; rtDW . lyrzf3l331 = h1zo3wxret ; } else if ( rtB .
g4otcjhaps ) { rtDW . cnphnmyixz = p5vaeqbl3t ; rtDW . i33gdokzps =
h1zo3wxret ; } else if ( rtB . c50enbqbhd ) { rtDW . cnphnmyixz = o2nxiy3ufc
; rtDW . hvipzkfxby = h1zo3wxret ; } break ; } } { if ( rtDW . ismfv5vasc .
AQHandles && ssGetLogOutput ( rtS ) ) { sdiWriteSignal ( rtDW . ismfv5vasc .
AQHandles , ssGetTaskTime ( rtS , 1 ) , ( char * ) & rtB . koa2xwzkqz + 0 ) ;
} } { if ( rtDW . ns05uf10ld . AQHandles && ssGetLogOutput ( rtS ) ) {
sdiWriteSignal ( rtDW . ns05uf10ld . AQHandles , ssGetTaskTime ( rtS , 1 ) ,
( char * ) & rtB . llcmsauyav + 0 ) ; } } { if ( rtDW . nkxcwijbwx .
AQHandles && ssGetLogOutput ( rtS ) ) { sdiWriteSignal ( rtDW . nkxcwijbwx .
AQHandles , ssGetTaskTime ( rtS , 1 ) , ( char * ) & rtB . govtsadkmh + 0 ) ;
} } { if ( rtDW . msb5d3me1j . AQHandles && ssGetLogOutput ( rtS ) ) {
sdiWriteSignal ( rtDW . msb5d3me1j . AQHandles , ssGetTaskTime ( rtS , 1 ) ,
( char * ) & rtB . gfgfscs3wh + 0 ) ; } } { if ( rtDW . lbtghvt0ml .
AQHandles && ssGetLogOutput ( rtS ) ) { sdiWriteSignal ( rtDW . lbtghvt0ml .
AQHandles , ssGetTaskTime ( rtS , 1 ) , ( char * ) & rtB . hwlkc3gph4 + 0 ) ;
} } { if ( rtDW . mvgtzq34qx . AQHandles && ssGetLogOutput ( rtS ) ) {
sdiWriteSignal ( rtDW . mvgtzq34qx . AQHandles , ssGetTaskTime ( rtS , 1 ) ,
( char * ) & rtB . ipy2o045sf + 0 ) ; } } { if ( rtDW . aosifnfz0v .
AQHandles && ssGetLogOutput ( rtS ) ) { sdiWriteSignal ( rtDW . aosifnfz0v .
AQHandles , ssGetTaskTime ( rtS , 1 ) , ( char * ) & rtB . ggozffptrp + 0 ) ;
} } { if ( rtDW . lpahj2azln . AQHandles && ssGetLogOutput ( rtS ) ) {
sdiWriteSignal ( rtDW . lpahj2azln . AQHandles , ssGetTaskTime ( rtS , 1 ) ,
( char * ) & rtB . ln01g2x54f + 0 ) ; } } rtDW . b0xpqic30u = ( ( rtB .
oqv2owxgui >= rtP . Relay2_OnVal ) || ( ( ! ( rtB . oqv2owxgui <= rtP .
Relay2_OffVal ) ) && rtDW . b0xpqic30u ) ) ; if ( rtDW . b0xpqic30u ) {
htg3s421yl = rtP . Relay2_YOn ; } else { htg3s421yl = rtP . Relay2_YOff ; } {
if ( rtDW . pyvmjo2bqw . AQHandles && ssGetLogOutput ( rtS ) ) {
sdiWriteSignal ( rtDW . pyvmjo2bqw . AQHandles , ssGetTaskTime ( rtS , 1 ) ,
( char * ) & htg3s421yl + 0 ) ; } } rtDW . iu2ulpoww0 = ( ( rtB . lrowya24l3
>= rtP . Relay1_OnVal ) || ( ( ! ( rtB . lrowya24l3 <= rtP . Relay1_OffVal )
) && rtDW . iu2ulpoww0 ) ) ; if ( rtDW . iu2ulpoww0 ) { lhb5brsu1h = rtP .
Relay1_YOn ; } else { lhb5brsu1h = rtP . Relay1_YOff ; } { if ( rtDW .
mcwiq2fdf3 . AQHandles && ssGetLogOutput ( rtS ) ) { sdiWriteSignal ( rtDW .
mcwiq2fdf3 . AQHandles , ssGetTaskTime ( rtS , 1 ) , ( char * ) & lhb5brsu1h
+ 0 ) ; } } { if ( rtDW . jarmeshqgo . AQHandles && ssGetLogOutput ( rtS ) )
{ sdiWriteSignal ( rtDW . jarmeshqgo . AQHandles , ssGetTaskTime ( rtS , 1 )
, ( char * ) & lhb5brsu1h + 0 ) ; } } { if ( rtDW . ltulzml5oa . AQHandles &&
ssGetLogOutput ( rtS ) ) { sdiWriteSignal ( rtDW . ltulzml5oa . AQHandles ,
ssGetTaskTime ( rtS , 1 ) , ( char * ) & lhb5brsu1h + 0 ) ; } } rtDW .
l4htxomgyb = ( ( rtB . lrowya24l3 >= rtP . Relay_OnVal ) || ( ( ! ( rtB .
lrowya24l3 <= rtP . Relay_OffVal ) ) && rtDW . l4htxomgyb ) ) ; if ( rtDW .
l4htxomgyb ) { l03sxfnt5m = rtP . Relay_YOn ; } else { l03sxfnt5m = rtP .
Relay_YOff ; } { if ( rtDW . lvl5uvsvj2 . AQHandles && ssGetLogOutput ( rtS )
) { sdiWriteSignal ( rtDW . lvl5uvsvj2 . AQHandles , ssGetTaskTime ( rtS , 1
) , ( char * ) & l03sxfnt5m + 0 ) ; } } { if ( rtDW . inyhtmatu2 . AQHandles
&& ssGetLogOutput ( rtS ) ) { sdiWriteSignal ( rtDW . inyhtmatu2 . AQHandles
, ssGetTaskTime ( rtS , 1 ) , ( char * ) & rtB . nr5jzefs11 + 0 ) ; } } { if
( rtDW . ah0o3rwxbv . AQHandles && ssGetLogOutput ( rtS ) ) { sdiWriteSignal
( rtDW . ah0o3rwxbv . AQHandles , ssGetTaskTime ( rtS , 1 ) , ( char * ) &
rtB . g4otcjhaps + 0 ) ; } } { if ( rtDW . flebub5s5m . AQHandles &&
ssGetLogOutput ( rtS ) ) { sdiWriteSignal ( rtDW . flebub5s5m . AQHandles ,
ssGetTaskTime ( rtS , 1 ) , ( char * ) & rtB . c50enbqbhd + 0 ) ; } } if (
rtB . ipy2o045sf ) { rtB . efsjkrykwf = rtP . Constant5_Value ; } else { rtB
. efsjkrykwf = rtP . Constant4_Value ; } if ( lhb5brsu1h > rtP .
Switch10_Threshold ) { rtB . mciogha2ud = rtP . Constant3_Value ; } else {
rtB . mciogha2ud = rtP . Constant2_Value ; } } rtB . i2sxt22wo1 = rtB .
gvytu245ky * rtB . dztq1uxeww * rtB . efsjkrykwf * rtB . mciogha2ud ; {
real_T * pDataValues = ( real_T * ) rtDW . e0u1digqih . DataPtr ; real_T *
pTimeValues = ( real_T * ) rtDW . e0u1digqih . TimePtr ; int_T currTimeIndex
= rtDW . f4gzzk1cad . PrevIndex ; real_T t = ssGetTaskTime ( rtS , 0 ) ; int
numPoints , lastPoint ; FWksInfo * fromwksInfo = ( FWksInfo * ) rtDW .
e0u1digqih . RSimInfoPtr ; numPoints = fromwksInfo -> nDataPoints ; lastPoint
= numPoints - 1 ; if ( t <= pTimeValues [ 0 ] ) { currTimeIndex = 0 ; } else
if ( t >= pTimeValues [ lastPoint ] ) { currTimeIndex = lastPoint - 1 ; }
else { if ( t < pTimeValues [ currTimeIndex ] ) { while ( t < pTimeValues [
currTimeIndex ] ) { currTimeIndex -- ; } } else { while ( t >= pTimeValues [
currTimeIndex + 1 ] ) { currTimeIndex ++ ; } } } rtDW . f4gzzk1cad .
PrevIndex = currTimeIndex ; { real_T t1 = pTimeValues [ currTimeIndex ] ;
real_T t2 = pTimeValues [ currTimeIndex + 1 ] ; if ( t1 == t2 ) { if ( t < t1
) { nuxxem3eon = pDataValues [ currTimeIndex ] ; } else { nuxxem3eon =
pDataValues [ currTimeIndex + 1 ] ; } } else { real_T f1 = ( t2 - t ) / ( t2
- t1 ) ; real_T f2 = 1.0 - f1 ; real_T d1 ; real_T d2 ; int_T TimeIndex =
currTimeIndex ; d1 = pDataValues [ TimeIndex ] ; d2 = pDataValues [ TimeIndex
+ 1 ] ; nuxxem3eon = ( real_T ) rtInterpolate ( d1 , d2 , f1 , f2 ) ;
pDataValues += numPoints ; } } } rtB . mpecnpblvq = rtP . Gain1_Gain *
nuxxem3eon ; if ( ssIsSampleHit ( rtS , 1 , 0 ) ) { rtB . lps2tdsik3 = rtDW .
iecjfocdpt ; rtB . jantdzvoeu = rtB . ai311bapfw * rtDW . mq4tzms12g + rtB .
ai311bapfw ; rtB . pzmuj11ybr = rtDW . pdh0ayrbq2 ; } { real_T * pDataValues
= ( real_T * ) rtDW . ddqlrilmhr . DataPtr ; real_T * pTimeValues = ( real_T
* ) rtDW . ddqlrilmhr . TimePtr ; int_T currTimeIndex = rtDW . gizzljrotf .
PrevIndex ; real_T t = ssGetTaskTime ( rtS , 0 ) ; int numPoints , lastPoint
; FWksInfo * fromwksInfo = ( FWksInfo * ) rtDW . ddqlrilmhr . RSimInfoPtr ;
numPoints = fromwksInfo -> nDataPoints ; lastPoint = numPoints - 1 ; if ( t
<= pTimeValues [ 0 ] ) { currTimeIndex = 0 ; } else if ( t >= pTimeValues [
lastPoint ] ) { currTimeIndex = lastPoint - 1 ; } else { if ( t < pTimeValues
[ currTimeIndex ] ) { while ( t < pTimeValues [ currTimeIndex ] ) {
currTimeIndex -- ; } } else { while ( t >= pTimeValues [ currTimeIndex + 1 ]
) { currTimeIndex ++ ; } } } rtDW . gizzljrotf . PrevIndex = currTimeIndex ;
{ real_T t1 = pTimeValues [ currTimeIndex ] ; real_T t2 = pTimeValues [
currTimeIndex + 1 ] ; if ( t1 == t2 ) { if ( t < t1 ) { cl1tnmdvcy =
pDataValues [ currTimeIndex ] ; } else { cl1tnmdvcy = pDataValues [
currTimeIndex + 1 ] ; } } else { real_T f1 = ( t2 - t ) / ( t2 - t1 ) ;
real_T f2 = 1.0 - f1 ; real_T d1 ; real_T d2 ; int_T TimeIndex =
currTimeIndex ; d1 = pDataValues [ TimeIndex ] ; d2 = pDataValues [ TimeIndex
+ 1 ] ; cl1tnmdvcy = ( real_T ) rtInterpolate ( d1 , d2 , f1 , f2 ) ;
pDataValues += numPoints ; } } } rtB . atjpekwwur = rtP . Gain2_Gain *
cl1tnmdvcy ; if ( ssIsSampleHit ( rtS , 1 , 0 ) ) { if ( ( ! rtB . koa2xwzkqz
) > rtP . Switch1_Threshold ) { rtB . dsy5xuerr4 = rtP . Constant6_Value ; }
else { rtB . dsy5xuerr4 = rtP . Constant1_Value ; } if ( rtB . govtsadkmh ||
( lhb5brsu1h != 0.0 ) ) { rtB . b4ykqqwob2 = rtP . Constant8_Value ; } else {
rtB . b4ykqqwob2 = rtP . Constant7_Value ; } if ( lhb5brsu1h > rtP .
Switch6_Threshold ) { rtB . ipwdgvuaap = rtP . Constant10_Value ; } else {
rtB . ipwdgvuaap = rtP . Constant9_Value ; } if ( l03sxfnt5m > rtP .
Switch4_Threshold_oqqlidhi4v ) { rtB . gs2acg4a1b = rtP . Constant11_Value ;
} else { rtB . gs2acg4a1b = rtP . Constant12_Value ; } if ( rtB . ggozffptrp
|| ( htg3s421yl != 0.0 ) ) { rtB . lgnqauvekd = rtP . Constant13_Value ; }
else { rtB . lgnqauvekd = rtP . Constant14_Value ; } rtB . fscu2cadee = rtDW
. i2jledyuxk ; } if ( ssIsSampleHit ( rtS , 3 , 0 ) ) { rtB . kzqd3pbqkr =
rtP . PA_Value * rtDW . jk5yslpya4 + rtP . PA_Value ; rtB . n1f2ld0elb = rtP
. PB_Value * rtDW . o0mql2hqjx + rtP . PB_Value ; rtB . ex4xrkfleq = rtP .
PC_Value * rtDW . o2pzpkkeul + rtP . PC_Value ; rtB . eo3aq2xcix = rtP .
PD_Value * rtDW . njvyqws1h5 + rtP . PD_Value ; rtB . dv5gz4icu0 = rtP .
PHEAT_Value * rtDW . hblnhilp5j + rtP . PHEAT_Value ; } rtB . kwz4uvuft3 [ 0
] = rtB . i2sxt22wo1 ; rtB . kwz4uvuft3 [ 1 ] = rtB . mpecnpblvq ; rtB .
kwz4uvuft3 [ 2 ] = rtP . C_Bin_Value ; rtB . kwz4uvuft3 [ 3 ] = rtB .
lps2tdsik3 ; rtB . kwz4uvuft3 [ 4 ] = rtP . C_Cin_Value ; rtB . kwz4uvuft3 [
5 ] = rtB . jantdzvoeu ; rtB . kwz4uvuft3 [ 6 ] = rtB . pzmuj11ybr ; rtB .
kwz4uvuft3 [ 7 ] = rtB . atjpekwwur ; rtB . kwz4uvuft3 [ 8 ] = rtB .
dsy5xuerr4 ; rtB . kwz4uvuft3 [ 9 ] = rtB . b4ykqqwob2 ; rtB . kwz4uvuft3 [
10 ] = rtP . Rate3_Value ; rtB . kwz4uvuft3 [ 11 ] = rtB . ipwdgvuaap ; rtB .
kwz4uvuft3 [ 12 ] = rtB . gs2acg4a1b ; rtB . kwz4uvuft3 [ 13 ] = rtB .
lgnqauvekd ; rtB . kwz4uvuft3 [ 14 ] = rtB . kzqd3pbqkr ; rtB . kwz4uvuft3 [
15 ] = rtB . n1f2ld0elb ; rtB . kwz4uvuft3 [ 16 ] = rtB . ex4xrkfleq ; rtB .
kwz4uvuft3 [ 17 ] = rtB . eo3aq2xcix ; rtB . kwz4uvuft3 [ 18 ] = rtB .
dv5gz4icu0 ; rtB . kwz4uvuft3 [ 19 ] = rtB . fscu2cadee ; { SimStruct * rts =
ssGetSFunction ( rtS , 0 ) ; sfcnOutputs ( rts , 0 ) ; } if ( ssIsSampleHit (
rtS , 1 , 0 ) ) { if ( ssGetLogOutput ( rtS ) ) { real_T u [ 2 ] ; u [ 0 ] =
ssGetTaskTime ( rtS , 1 ) ; u [ 1 ] = rtB . e0gpvxxppp [ 3 ] ;
rt_UpdateLogVar ( ( LogVar * ) rtDW . e3pcjst2gf . LoggedData , u , 0 ) ; } }
rtB . ib3grttpul = rtX . lnj4efc1py ; if ( ssIsSampleHit ( rtS , 1 , 0 ) ) {
{ if ( rtDW . j3e0f44doy . AQHandles && ssGetLogOutput ( rtS ) ) {
sdiWriteSignal ( rtDW . j3e0f44doy . AQHandles , ssGetTaskTime ( rtS , 1 ) ,
( char * ) & rtB . e0gpvxxppp [ 0 ] + 0 ) ; } } { if ( rtDW . oot0srnoki .
AQHandles && ssGetLogOutput ( rtS ) ) { sdiWriteSignal ( rtDW . oot0srnoki .
AQHandles , ssGetTaskTime ( rtS , 1 ) , ( char * ) & rtB . e0gpvxxppp [ 1 ] +
0 ) ; } } { if ( rtDW . bjz5tw4p5j . AQHandles && ssGetLogOutput ( rtS ) ) {
sdiWriteSignal ( rtDW . bjz5tw4p5j . AQHandles , ssGetTaskTime ( rtS , 1 ) ,
( char * ) & rtB . e0gpvxxppp [ 2 ] + 0 ) ; } } { if ( rtDW . mljkjloakr .
AQHandles && ssGetLogOutput ( rtS ) ) { sdiWriteSignal ( rtDW . mljkjloakr .
AQHandles , ssGetTaskTime ( rtS , 1 ) , ( char * ) & rtB . e0gpvxxppp [ 3 ] +
0 ) ; } } { if ( rtDW . l4vlioxbgl . AQHandles && ssGetLogOutput ( rtS ) ) {
sdiWriteSignal ( rtDW . l4vlioxbgl . AQHandles , ssGetTaskTime ( rtS , 1 ) ,
( char * ) & rtB . e0gpvxxppp [ 4 ] + 0 ) ; } } { if ( rtDW . kkblxpcw3m .
AQHandles && ssGetLogOutput ( rtS ) ) { sdiWriteSignal ( rtDW . kkblxpcw3m .
AQHandles , ssGetTaskTime ( rtS , 1 ) , ( char * ) & rtB . e0gpvxxppp [ 5 ] +
0 ) ; } } { if ( rtDW . h3jcwnop0g . AQHandles && ssGetLogOutput ( rtS ) ) {
sdiWriteSignal ( rtDW . h3jcwnop0g . AQHandles , ssGetTaskTime ( rtS , 1 ) ,
( char * ) & rtB . e0gpvxxppp [ 6 ] + 0 ) ; } } { if ( rtDW . mjxkrhmtfj .
AQHandles && ssGetLogOutput ( rtS ) ) { sdiWriteSignal ( rtDW . mjxkrhmtfj .
AQHandles , ssGetTaskTime ( rtS , 1 ) , ( char * ) & rtB . e0gpvxxppp [ 7 ] +
0 ) ; } } { if ( rtDW . beunqpbxj1 . AQHandles && ssGetLogOutput ( rtS ) ) {
sdiWriteSignal ( rtDW . beunqpbxj1 . AQHandles , ssGetTaskTime ( rtS , 1 ) ,
( char * ) & rtB . e0gpvxxppp [ 8 ] + 0 ) ; } } { if ( rtDW . jvhbaaoh3e .
AQHandles && ssGetLogOutput ( rtS ) ) { sdiWriteSignal ( rtDW . jvhbaaoh3e .
AQHandles , ssGetTaskTime ( rtS , 1 ) , ( char * ) & rtB . ai311bapfw + 0 ) ;
} } { if ( rtDW . ctwshmhpdz . AQHandles && ssGetLogOutput ( rtS ) ) {
sdiWriteSignal ( rtDW . ctwshmhpdz . AQHandles , ssGetTaskTime ( rtS , 1 ) ,
( char * ) & rtB . mpecnpblvq + 0 ) ; } } { if ( rtDW . licnk0hmrn .
AQHandles && ssGetLogOutput ( rtS ) ) { sdiWriteSignal ( rtDW . licnk0hmrn .
AQHandles , ssGetTaskTime ( rtS , 1 ) , ( char * ) & rtB . atjpekwwur + 0 ) ;
} } { if ( rtDW . jvdos0csvi . AQHandles && ssGetLogOutput ( rtS ) ) {
sdiWriteSignal ( rtDW . jvdos0csvi . AQHandles , ssGetTaskTime ( rtS , 1 ) ,
( char * ) & rtB . i2sxt22wo1 + 0 ) ; } } if ( rtB . llcmsauyav ) { rtB .
k3jie4wym5 = rtP . Constant16_Value ; } else { rtB . k3jie4wym5 = rtP .
Constant15_Value ; } } p1hmzyi4p0 = rtP . LevelSet_Value - rtB . e0gpvxxppp [
0 ] ; rtB . czzkhzteyg = ( rtP . PIDController1_D * p1hmzyi4p0 - rtX .
korolwetpt ) * rtP . PIDController1_N ; rtB . iu3dgzsmox = ( ( rtP .
PIDController1_P * p1hmzyi4p0 + rtX . mt5ndntoey ) + rtB . czzkhzteyg ) * rtP
. Gain_Gain ; rtB . bbrn1ou5mh = rtB . mcsqmnaiu3 * rtB . k3jie4wym5 * rtB .
iu3dgzsmox ; if ( ssIsSampleHit ( rtS , 1 , 0 ) ) { { if ( rtDW . pn3nw2wp03
. AQHandles && ssGetLogOutput ( rtS ) ) { sdiWriteSignal ( rtDW . pn3nw2wp03
. AQHandles , ssGetTaskTime ( rtS , 1 ) , ( char * ) & rtB . bbrn1ou5mh + 0 )
; } } } if ( ssIsSampleHit ( rtS , 3 , 0 ) ) { { if ( rtDW . lclc5oxd1y .
AQHandles && ssGetLogOutput ( rtS ) ) { sdiWriteSignal ( rtDW . lclc5oxd1y .
AQHandles , ssGetTaskTime ( rtS , 3 ) , ( char * ) & rtB . kzqd3pbqkr + 0 ) ;
} } { if ( rtDW . k2lm4rcfbi . AQHandles && ssGetLogOutput ( rtS ) ) {
sdiWriteSignal ( rtDW . k2lm4rcfbi . AQHandles , ssGetTaskTime ( rtS , 3 ) ,
( char * ) & rtB . n1f2ld0elb + 0 ) ; } } { if ( rtDW . hcvlm25apo .
AQHandles && ssGetLogOutput ( rtS ) ) { sdiWriteSignal ( rtDW . hcvlm25apo .
AQHandles , ssGetTaskTime ( rtS , 3 ) , ( char * ) & rtB . ex4xrkfleq + 0 ) ;
} } { if ( rtDW . ku5epe2lev . AQHandles && ssGetLogOutput ( rtS ) ) {
sdiWriteSignal ( rtDW . ku5epe2lev . AQHandles , ssGetTaskTime ( rtS , 3 ) ,
( char * ) & rtB . eo3aq2xcix + 0 ) ; } } { if ( rtDW . eksra31szv .
AQHandles && ssGetLogOutput ( rtS ) ) { sdiWriteSignal ( rtDW . eksra31szv .
AQHandles , ssGetTaskTime ( rtS , 3 ) , ( char * ) & rtB . dv5gz4icu0 + 0 ) ;
} } } if ( ssIsSampleHit ( rtS , 1 , 0 ) ) { { if ( rtDW . ahr1p51zrw .
AQHandles && ssGetLogOutput ( rtS ) ) { sdiWriteSignal ( rtDW . ahr1p51zrw .
AQHandles , ssGetTaskTime ( rtS , 1 ) , ( char * ) & rtB . jantdzvoeu + 0 ) ;
} } { if ( rtDW . fwpf1vdbdo . AQHandles && ssGetLogOutput ( rtS ) ) {
sdiWriteSignal ( rtDW . fwpf1vdbdo . AQHandles , ssGetTaskTime ( rtS , 1 ) ,
( char * ) & rtB . dsy5xuerr4 + 0 ) ; } } { if ( rtDW . ciu3qjsht5 .
AQHandles && ssGetLogOutput ( rtS ) ) { sdiWriteSignal ( rtDW . ciu3qjsht5 .
AQHandles , ssGetTaskTime ( rtS , 1 ) , ( char * ) & rtB . gs2acg4a1b + 0 ) ;
} } { if ( rtDW . m2i42ofdw4 . AQHandles && ssGetLogOutput ( rtS ) ) {
sdiWriteSignal ( rtDW . m2i42ofdw4 . AQHandles , ssGetTaskTime ( rtS , 1 ) ,
( char * ) & rtB . b4ykqqwob2 + 0 ) ; } } { if ( rtDW . frknafxvto .
AQHandles && ssGetLogOutput ( rtS ) ) { sdiWriteSignal ( rtDW . frknafxvto .
AQHandles , ssGetTaskTime ( rtS , 1 ) , ( char * ) & rtB . ipwdgvuaap + 0 ) ;
} } { if ( rtDW . blapbcem3w . AQHandles && ssGetLogOutput ( rtS ) ) {
sdiWriteSignal ( rtDW . blapbcem3w . AQHandles , ssGetTaskTime ( rtS , 1 ) ,
( char * ) & rtB . lgnqauvekd + 0 ) ; } } } htg3s421yl = rtP . T_outSet_Value
- rtB . e0gpvxxppp [ 4 ] ; rtB . jkvshhuv25 = ( rtP . PIDController_D *
htg3s421yl - rtX . nbjzeco0u3 ) * rtP . PIDController_N ; rtB . ifp2xzx5cj =
( rtP . PIDController_P * htg3s421yl + rtX . indcayvth4 ) + rtB . jkvshhuv25
; if ( rtP . Constant_Value > rtP . Switch_Threshold ) { rtB . jxqv3hrimg =
rtB . bzuganxdf2 * rtB . ifp2xzx5cj ; } else { rtB . jxqv3hrimg = rtB .
e0gpvxxppp [ 4 ] ; } if ( ssIsSampleHit ( rtS , 1 , 0 ) ) { { if ( rtDW .
ekmy53hjdg . AQHandles && ssGetLogOutput ( rtS ) ) { sdiWriteSignal ( rtDW .
ekmy53hjdg . AQHandles , ssGetTaskTime ( rtS , 1 ) , ( char * ) & rtB .
jxqv3hrimg + 0 ) ; } } ijwfmqzqly [ 0 ] = rtB . i2sxt22wo1 ; ijwfmqzqly [ 1 ]
= rtB . mpecnpblvq ; ijwfmqzqly [ 2 ] = rtP . C_Bin_Value ; ijwfmqzqly [ 3 ]
= rtB . lps2tdsik3 ; ijwfmqzqly [ 4 ] = rtP . C_Cin_Value ; ijwfmqzqly [ 5 ]
= rtB . jantdzvoeu ; ijwfmqzqly [ 6 ] = rtB . pzmuj11ybr ; ijwfmqzqly [ 7 ] =
rtB . atjpekwwur ; ijwfmqzqly [ 8 ] = rtB . dsy5xuerr4 ; ijwfmqzqly [ 9 ] =
rtB . b4ykqqwob2 ; ijwfmqzqly [ 10 ] = rtP . Rate3_Value ; ijwfmqzqly [ 11 ]
= rtB . ipwdgvuaap ; ijwfmqzqly [ 12 ] = rtB . gs2acg4a1b ; ijwfmqzqly [ 13 ]
= rtB . lgnqauvekd ; memcpy ( & ijwfmqzqly [ 14 ] , & rtB . e0gpvxxppp [ 0 ]
, sizeof ( real_T ) << 3U ) ; ijwfmqzqly [ 22 ] = rtB . ib3grttpul ; if (
ssGetLogOutput ( rtS ) ) { { const char * errMsg = ( NULL ) ; void * fp = (
void * ) rtDW . aw4of2bzto . FilePtr ; if ( fp != ( NULL ) ) { { real_T t ;
void * u ; t = ssGetTaskTime ( rtS , 1 ) ; u = ( void * ) & ijwfmqzqly [ 0 ]
; errMsg = rtwH5LoggingCollectionWrite ( 1 , fp , 0 , t , u ) ; if ( errMsg
!= ( NULL ) ) { ssSetErrorStatus ( rtS , errMsg ) ; return ; } } } } } rtB .
ggli2ppxyv = muDoubleScalarExp ( muDoubleScalarAbs ( rtB . ifp2xzx5cj - rtDW
. hdgt0peaua ) ) * rtP . PCHANGE_Value + muDoubleScalarExp (
muDoubleScalarAbs ( rtB . iu3dgzsmox - rtDW . mk4nogmrgx ) ) * rtP .
PCHANGE_Value ; } rtB . owumd2pxxx = rtP . PIDController_I * htg3s421yl ; rtB
. bmollnwf0s = rtP . PIDController1_I * p1hmzyi4p0 ; UNUSED_PARAMETER ( tid )
; } void MdlOutputsTID4 ( int_T tid ) { rtB . d5u0rvgiee = rtP .
Feed_Temperature_In_Value ; { if ( rtDW . j2ehmt2zxo . AQHandles &&
ssGetLogOutput ( rtS ) ) { sdiWriteSignal ( rtDW . j2ehmt2zxo . AQHandles ,
ssGetTaskTime ( rtS , 4 ) , ( char * ) & rtB . d5u0rvgiee + 0 ) ; } } rtB .
k3xz1ht2ij = rtP . Feed_Temperature_Out_Value ; { if ( rtDW . cue41xrxnu .
AQHandles && ssGetLogOutput ( rtS ) ) { sdiWriteSignal ( rtDW . cue41xrxnu .
AQHandles , ssGetTaskTime ( rtS , 4 ) , ( char * ) & rtB . k3xz1ht2ij + 0 ) ;
} } rtB . iorisswymh = rtP . Inlet_Flow_In_Value ; { if ( rtDW . pubxocmqc2 .
AQHandles && ssGetLogOutput ( rtS ) ) { sdiWriteSignal ( rtDW . pubxocmqc2 .
AQHandles , ssGetTaskTime ( rtS , 4 ) , ( char * ) & rtB . iorisswymh + 0 ) ;
} } rtB . l4lnonwfg2 = rtP . Inlet_Flow_Out_Value ; { if ( rtDW . f0ugwgjvhr
. AQHandles && ssGetLogOutput ( rtS ) ) { sdiWriteSignal ( rtDW . f0ugwgjvhr
. AQHandles , ssGetTaskTime ( rtS , 4 ) , ( char * ) & rtB . l4lnonwfg2 + 0 )
; } } { if ( rtDW . g53jytoip4 . AQHandles && ssGetLogOutput ( rtS ) ) {
sdiWriteSignal ( rtDW . g53jytoip4 . AQHandles , ssGetTaskTime ( rtS , 4 ) ,
( char * ) & rtP . C_Bin_Value + 0 ) ; } } { if ( rtDW . obf4siedf4 .
AQHandles && ssGetLogOutput ( rtS ) ) { sdiWriteSignal ( rtDW . obf4siedf4 .
AQHandles , ssGetTaskTime ( rtS , 4 ) , ( char * ) & rtP . C_Cin_Value + 0 )
; } } { if ( rtDW . o5jtmaqc3t . AQHandles && ssGetLogOutput ( rtS ) ) {
sdiWriteSignal ( rtDW . o5jtmaqc3t . AQHandles , ssGetTaskTime ( rtS , 4 ) ,
( char * ) & rtP . Rate3_Value + 0 ) ; } } UNUSED_PARAMETER ( tid ) ; } void
MdlUpdate ( int_T tid ) { if ( ssIsSampleHit ( rtS , 2 , 0 ) ) { rtDW .
bv534fxrfq = ( rtP . UniformRandomNumber2_Maximum - rtP .
UniformRandomNumber2_Minimum ) * rt_urand_Upu32_Yd_f_pw_snf ( & rtDW .
bmwah53if2 ) + rtP . UniformRandomNumber2_Minimum ; rtDW . bgotvck1y4 = ( rtP
. UniformRandomNumber10_Maximum - rtP . UniformRandomNumber10_Minimum ) *
rt_urand_Upu32_Yd_f_pw_snf ( & rtDW . lustmxh0ru ) + rtP .
UniformRandomNumber10_Minimum ; } if ( ssIsSampleHit ( rtS , 1 , 0 ) ) { rtDW
. i3eqa0qza0 = rtB . gfgfscs3wh ; rtDW . fudylxbq0j = rtB . pwkazhfzxj ; rtDW
. agio50d4gu = rtB . hwlkc3gph4 ; rtDW . dfulppyfs1 = rtB . bd3otgosaa ; rtDW
. g10sbzotef = rtB . ln01g2x54f ; rtDW . gymfbya0lf = rtB . fnykzau3dd ; rtDW
. mz0zdu34tn = rtB . e0gpvxxppp [ 7 ] ; rtDW . cronjwvq3j = rtB . ai311bapfw
; rtDW . dsnlclvjlf = rtB . e0gpvxxppp [ 1 ] ; rtDW . nfi0353erc = rtB .
e0gpvxxppp [ 4 ] ; rtDW . g5guutg2r4 = rtB . e0gpvxxppp [ 0 ] ; rtDW .
iecjfocdpt = rtB . jxqv3hrimg ; rtDW . mq4tzms12g = ( rtP .
UniformRandomNumber5_Maximum - rtP . UniformRandomNumber5_Minimum ) *
rt_urand_Upu32_Yd_f_pw_snf ( & rtDW . kasvnwnwfd ) + rtP .
UniformRandomNumber5_Minimum ; rtDW . pdh0ayrbq2 = rtB . bbrn1ou5mh ; } if (
ssIsSampleHit ( rtS , 2 , 0 ) ) { rtDW . o0jhm5tqhv = ( rtP .
UniformRandomNumber6_Maximum - rtP . UniformRandomNumber6_Minimum ) *
rt_urand_Upu32_Yd_f_pw_snf ( & rtDW . o5vdryefj2 ) + rtP .
UniformRandomNumber6_Minimum ; } if ( ssIsSampleHit ( rtS , 3 , 0 ) ) { rtDW
. jk5yslpya4 = ( rtP . UniformRandomNumber_Maximum - rtP .
UniformRandomNumber_Minimum ) * rt_urand_Upu32_Yd_f_pw_snf ( & rtDW .
d2hdmgi2df ) + rtP . UniformRandomNumber_Minimum ; rtDW . o0mql2hqjx = ( rtP
. UniformRandomNumber1_Maximum - rtP . UniformRandomNumber1_Minimum ) *
rt_urand_Upu32_Yd_f_pw_snf ( & rtDW . eesjxfyvk2 ) + rtP .
UniformRandomNumber1_Minimum ; rtDW . o2pzpkkeul = ( rtP .
UniformRandomNumber2_Maximum_h0hkt0qhvs - rtP .
UniformRandomNumber2_Minimum_fx5mnbvdh4 ) * rt_urand_Upu32_Yd_f_pw_snf ( &
rtDW . cdqamvzgi2 ) + rtP . UniformRandomNumber2_Minimum_fx5mnbvdh4 ; rtDW .
njvyqws1h5 = ( rtP . UniformRandomNumber3_Maximum - rtP .
UniformRandomNumber3_Minimum ) * rt_urand_Upu32_Yd_f_pw_snf ( & rtDW .
a2u1lqkyoh ) + rtP . UniformRandomNumber3_Minimum ; rtDW . hblnhilp5j = ( rtP
. UniformRandomNumber4_Maximum - rtP . UniformRandomNumber4_Minimum ) *
rt_urand_Upu32_Yd_f_pw_snf ( & rtDW . mpm2qm4ahz ) + rtP .
UniformRandomNumber4_Minimum ; } if ( ssIsSampleHit ( rtS , 1 , 0 ) ) { rtDW
. i2jledyuxk = rtB . ggli2ppxyv ; rtDW . mk4nogmrgx = rtB . iu3dgzsmox ; rtDW
. hdgt0peaua = rtB . ifp2xzx5cj ; } UNUSED_PARAMETER ( tid ) ; } void
MdlUpdateTID4 ( int_T tid ) { UNUSED_PARAMETER ( tid ) ; } void
MdlDerivatives ( void ) { XDot * _rtXdot ; _rtXdot = ( ( XDot * ) ssGetdX (
rtS ) ) ; { SimStruct * rts = ssGetSFunction ( rtS , 0 ) ; real_T * sfcndX_fx
= ( real_T * ) & ( ( XDot * ) ssGetdX ( rtS ) ) -> jedufocp2q [ 0 ] ; ssSetdX
( rts , sfcndX_fx ) ; sfcnDerivatives ( rts ) ; if ( ssGetErrorStatus ( rts )
!= ( NULL ) ) return ; } _rtXdot -> lnj4efc1py = rtB . e0gpvxxppp [ 8 ] ;
_rtXdot -> mt5ndntoey = rtB . bmollnwf0s ; _rtXdot -> korolwetpt = rtB .
czzkhzteyg ; _rtXdot -> indcayvth4 = rtB . owumd2pxxx ; _rtXdot -> nbjzeco0u3
= rtB . jkvshhuv25 ; } void MdlProjection ( void ) { } void MdlTerminate (
void ) { rt_FREE ( rtDW . e0u1digqih . RSimInfoPtr ) ; rt_FREE ( rtDW .
ddqlrilmhr . RSimInfoPtr ) ; { SimStruct * rts = ssGetSFunction ( rtS , 0 ) ;
sfcnTerminate ( rts ) ; } { const char * errMsg = ( NULL ) ; void * fp = (
void * ) rtDW . aw4of2bzto . FilePtr ; if ( fp != ( NULL ) ) { errMsg =
rtwH5LoggingCollectionDestroyInstance ( 1 , fp ) ; if ( errMsg != ( NULL ) )
{ ssSetErrorStatus ( rtS , errMsg ) ; return ; } } } { if ( rtDW . j2ehmt2zxo
. AQHandles ) { sdiTerminateStreaming ( & rtDW . j2ehmt2zxo . AQHandles ) ; }
} { if ( rtDW . cue41xrxnu . AQHandles ) { sdiTerminateStreaming ( & rtDW .
cue41xrxnu . AQHandles ) ; } } { if ( rtDW . pubxocmqc2 . AQHandles ) {
sdiTerminateStreaming ( & rtDW . pubxocmqc2 . AQHandles ) ; } } { if ( rtDW .
f0ugwgjvhr . AQHandles ) { sdiTerminateStreaming ( & rtDW . f0ugwgjvhr .
AQHandles ) ; } } { if ( rtDW . g53jytoip4 . AQHandles ) {
sdiTerminateStreaming ( & rtDW . g53jytoip4 . AQHandles ) ; } } { if ( rtDW .
obf4siedf4 . AQHandles ) { sdiTerminateStreaming ( & rtDW . obf4siedf4 .
AQHandles ) ; } } { if ( rtDW . o5jtmaqc3t . AQHandles ) {
sdiTerminateStreaming ( & rtDW . o5jtmaqc3t . AQHandles ) ; } } { if ( rtDW .
odihpq11te . AQHandles ) { sdiTerminateStreaming ( & rtDW . odihpq11te .
AQHandles ) ; } } { if ( rtDW . jsnyah43h5 . AQHandles ) {
sdiTerminateStreaming ( & rtDW . jsnyah43h5 . AQHandles ) ; } } { if ( rtDW .
ggzqve4ryn . AQHandles ) { sdiTerminateStreaming ( & rtDW . ggzqve4ryn .
AQHandles ) ; } } { if ( rtDW . ismfv5vasc . AQHandles ) {
sdiTerminateStreaming ( & rtDW . ismfv5vasc . AQHandles ) ; } } { if ( rtDW .
ns05uf10ld . AQHandles ) { sdiTerminateStreaming ( & rtDW . ns05uf10ld .
AQHandles ) ; } } { if ( rtDW . nkxcwijbwx . AQHandles ) {
sdiTerminateStreaming ( & rtDW . nkxcwijbwx . AQHandles ) ; } } { if ( rtDW .
msb5d3me1j . AQHandles ) { sdiTerminateStreaming ( & rtDW . msb5d3me1j .
AQHandles ) ; } } { if ( rtDW . lbtghvt0ml . AQHandles ) {
sdiTerminateStreaming ( & rtDW . lbtghvt0ml . AQHandles ) ; } } { if ( rtDW .
mvgtzq34qx . AQHandles ) { sdiTerminateStreaming ( & rtDW . mvgtzq34qx .
AQHandles ) ; } } { if ( rtDW . aosifnfz0v . AQHandles ) {
sdiTerminateStreaming ( & rtDW . aosifnfz0v . AQHandles ) ; } } { if ( rtDW .
lpahj2azln . AQHandles ) { sdiTerminateStreaming ( & rtDW . lpahj2azln .
AQHandles ) ; } } { if ( rtDW . pyvmjo2bqw . AQHandles ) {
sdiTerminateStreaming ( & rtDW . pyvmjo2bqw . AQHandles ) ; } } { if ( rtDW .
mcwiq2fdf3 . AQHandles ) { sdiTerminateStreaming ( & rtDW . mcwiq2fdf3 .
AQHandles ) ; } } { if ( rtDW . jarmeshqgo . AQHandles ) {
sdiTerminateStreaming ( & rtDW . jarmeshqgo . AQHandles ) ; } } { if ( rtDW .
ltulzml5oa . AQHandles ) { sdiTerminateStreaming ( & rtDW . ltulzml5oa .
AQHandles ) ; } } { if ( rtDW . lvl5uvsvj2 . AQHandles ) {
sdiTerminateStreaming ( & rtDW . lvl5uvsvj2 . AQHandles ) ; } } { if ( rtDW .
inyhtmatu2 . AQHandles ) { sdiTerminateStreaming ( & rtDW . inyhtmatu2 .
AQHandles ) ; } } { if ( rtDW . ah0o3rwxbv . AQHandles ) {
sdiTerminateStreaming ( & rtDW . ah0o3rwxbv . AQHandles ) ; } } { if ( rtDW .
flebub5s5m . AQHandles ) { sdiTerminateStreaming ( & rtDW . flebub5s5m .
AQHandles ) ; } } { if ( rtDW . j3e0f44doy . AQHandles ) {
sdiTerminateStreaming ( & rtDW . j3e0f44doy . AQHandles ) ; } } { if ( rtDW .
oot0srnoki . AQHandles ) { sdiTerminateStreaming ( & rtDW . oot0srnoki .
AQHandles ) ; } } { if ( rtDW . bjz5tw4p5j . AQHandles ) {
sdiTerminateStreaming ( & rtDW . bjz5tw4p5j . AQHandles ) ; } } { if ( rtDW .
mljkjloakr . AQHandles ) { sdiTerminateStreaming ( & rtDW . mljkjloakr .
AQHandles ) ; } } { if ( rtDW . l4vlioxbgl . AQHandles ) {
sdiTerminateStreaming ( & rtDW . l4vlioxbgl . AQHandles ) ; } } { if ( rtDW .
kkblxpcw3m . AQHandles ) { sdiTerminateStreaming ( & rtDW . kkblxpcw3m .
AQHandles ) ; } } { if ( rtDW . h3jcwnop0g . AQHandles ) {
sdiTerminateStreaming ( & rtDW . h3jcwnop0g . AQHandles ) ; } } { if ( rtDW .
mjxkrhmtfj . AQHandles ) { sdiTerminateStreaming ( & rtDW . mjxkrhmtfj .
AQHandles ) ; } } { if ( rtDW . beunqpbxj1 . AQHandles ) {
sdiTerminateStreaming ( & rtDW . beunqpbxj1 . AQHandles ) ; } } { if ( rtDW .
jvhbaaoh3e . AQHandles ) { sdiTerminateStreaming ( & rtDW . jvhbaaoh3e .
AQHandles ) ; } } { if ( rtDW . ctwshmhpdz . AQHandles ) {
sdiTerminateStreaming ( & rtDW . ctwshmhpdz . AQHandles ) ; } } { if ( rtDW .
licnk0hmrn . AQHandles ) { sdiTerminateStreaming ( & rtDW . licnk0hmrn .
AQHandles ) ; } } { if ( rtDW . jvdos0csvi . AQHandles ) {
sdiTerminateStreaming ( & rtDW . jvdos0csvi . AQHandles ) ; } } { if ( rtDW .
pn3nw2wp03 . AQHandles ) { sdiTerminateStreaming ( & rtDW . pn3nw2wp03 .
AQHandles ) ; } } { if ( rtDW . lclc5oxd1y . AQHandles ) {
sdiTerminateStreaming ( & rtDW . lclc5oxd1y . AQHandles ) ; } } { if ( rtDW .
k2lm4rcfbi . AQHandles ) { sdiTerminateStreaming ( & rtDW . k2lm4rcfbi .
AQHandles ) ; } } { if ( rtDW . hcvlm25apo . AQHandles ) {
sdiTerminateStreaming ( & rtDW . hcvlm25apo . AQHandles ) ; } } { if ( rtDW .
ku5epe2lev . AQHandles ) { sdiTerminateStreaming ( & rtDW . ku5epe2lev .
AQHandles ) ; } } { if ( rtDW . eksra31szv . AQHandles ) {
sdiTerminateStreaming ( & rtDW . eksra31szv . AQHandles ) ; } } { if ( rtDW .
ahr1p51zrw . AQHandles ) { sdiTerminateStreaming ( & rtDW . ahr1p51zrw .
AQHandles ) ; } } { if ( rtDW . fwpf1vdbdo . AQHandles ) {
sdiTerminateStreaming ( & rtDW . fwpf1vdbdo . AQHandles ) ; } } { if ( rtDW .
ciu3qjsht5 . AQHandles ) { sdiTerminateStreaming ( & rtDW . ciu3qjsht5 .
AQHandles ) ; } } { if ( rtDW . m2i42ofdw4 . AQHandles ) {
sdiTerminateStreaming ( & rtDW . m2i42ofdw4 . AQHandles ) ; } } { if ( rtDW .
frknafxvto . AQHandles ) { sdiTerminateStreaming ( & rtDW . frknafxvto .
AQHandles ) ; } } { if ( rtDW . blapbcem3w . AQHandles ) {
sdiTerminateStreaming ( & rtDW . blapbcem3w . AQHandles ) ; } } { if ( rtDW .
ekmy53hjdg . AQHandles ) { sdiTerminateStreaming ( & rtDW . ekmy53hjdg .
AQHandles ) ; } } } static void mr_cstr_simulationEnv_cacheDataAsMxArray (
mxArray * destArray , mwIndex i , int j , const void * srcData , size_t
numBytes ) ; static void mr_cstr_simulationEnv_cacheDataAsMxArray ( mxArray *
destArray , mwIndex i , int j , const void * srcData , size_t numBytes ) {
mxArray * newArray = mxCreateUninitNumericMatrix ( ( size_t ) 1 , numBytes ,
mxUINT8_CLASS , mxREAL ) ; memcpy ( ( uint8_T * ) mxGetData ( newArray ) , (
const uint8_T * ) srcData , numBytes ) ; mxSetFieldByNumber ( destArray , i ,
j , newArray ) ; } static void mr_cstr_simulationEnv_restoreDataFromMxArray (
void * destData , const mxArray * srcArray , mwIndex i , int j , size_t
numBytes ) ; static void mr_cstr_simulationEnv_restoreDataFromMxArray ( void
* destData , const mxArray * srcArray , mwIndex i , int j , size_t numBytes )
{ memcpy ( ( uint8_T * ) destData , ( const uint8_T * ) mxGetData (
mxGetFieldByNumber ( srcArray , i , j ) ) , numBytes ) ; } static void
mr_cstr_simulationEnv_cacheBitFieldToMxArray ( mxArray * destArray , mwIndex
i , int j , uint_T bitVal ) ; static void
mr_cstr_simulationEnv_cacheBitFieldToMxArray ( mxArray * destArray , mwIndex
i , int j , uint_T bitVal ) { mxSetFieldByNumber ( destArray , i , j ,
mxCreateDoubleScalar ( ( double ) bitVal ) ) ; } static uint_T
mr_cstr_simulationEnv_extractBitFieldFromMxArray ( const mxArray * srcArray ,
mwIndex i , int j , uint_T numBits ) ; static uint_T
mr_cstr_simulationEnv_extractBitFieldFromMxArray ( const mxArray * srcArray ,
mwIndex i , int j , uint_T numBits ) { const uint_T varVal = ( uint_T )
mxGetScalar ( mxGetFieldByNumber ( srcArray , i , j ) ) ; return varVal & ( (
1u << numBits ) - 1u ) ; } static void
mr_cstr_simulationEnv_cacheDataToMxArrayWithOffset ( mxArray * destArray ,
mwIndex i , int j , mwIndex offset , const void * srcData , size_t numBytes )
; static void mr_cstr_simulationEnv_cacheDataToMxArrayWithOffset ( mxArray *
destArray , mwIndex i , int j , mwIndex offset , const void * srcData ,
size_t numBytes ) { uint8_T * varData = ( uint8_T * ) mxGetData (
mxGetFieldByNumber ( destArray , i , j ) ) ; memcpy ( ( uint8_T * ) & varData
[ offset * numBytes ] , ( const uint8_T * ) srcData , numBytes ) ; } static
void mr_cstr_simulationEnv_restoreDataFromMxArrayWithOffset ( void * destData
, const mxArray * srcArray , mwIndex i , int j , mwIndex offset , size_t
numBytes ) ; static void
mr_cstr_simulationEnv_restoreDataFromMxArrayWithOffset ( void * destData ,
const mxArray * srcArray , mwIndex i , int j , mwIndex offset , size_t
numBytes ) { const uint8_T * varData = ( const uint8_T * ) mxGetData (
mxGetFieldByNumber ( srcArray , i , j ) ) ; memcpy ( ( uint8_T * ) destData ,
( const uint8_T * ) & varData [ offset * numBytes ] , numBytes ) ; } static
void mr_cstr_simulationEnv_cacheBitFieldToCellArrayWithOffset ( mxArray *
destArray , mwIndex i , int j , mwIndex offset , uint_T fieldVal ) ; static
void mr_cstr_simulationEnv_cacheBitFieldToCellArrayWithOffset ( mxArray *
destArray , mwIndex i , int j , mwIndex offset , uint_T fieldVal ) {
mxSetCell ( mxGetFieldByNumber ( destArray , i , j ) , offset ,
mxCreateDoubleScalar ( ( double ) fieldVal ) ) ; } static uint_T
mr_cstr_simulationEnv_extractBitFieldFromCellArrayWithOffset ( const mxArray
* srcArray , mwIndex i , int j , mwIndex offset , uint_T numBits ) ; static
uint_T mr_cstr_simulationEnv_extractBitFieldFromCellArrayWithOffset ( const
mxArray * srcArray , mwIndex i , int j , mwIndex offset , uint_T numBits ) {
const uint_T fieldVal = ( uint_T ) mxGetScalar ( mxGetCell (
mxGetFieldByNumber ( srcArray , i , j ) , offset ) ) ; return fieldVal & ( (
1u << numBits ) - 1u ) ; } mxArray * mr_cstr_simulationEnv_GetDWork ( ) {
static const char * ssDWFieldNames [ 3 ] = { "rtB" , "rtDW" , "NULL_PrevZCX"
, } ; mxArray * ssDW = mxCreateStructMatrix ( 1 , 1 , 3 , ssDWFieldNames ) ;
mr_cstr_simulationEnv_cacheDataAsMxArray ( ssDW , 0 , 0 , ( const void * ) &
( rtB ) , sizeof ( rtB ) ) ; { static const char * rtdwDataFieldNames [ 75 ]
= { "rtDW.mz0zdu34tn" , "rtDW.cronjwvq3j" , "rtDW.dsnlclvjlf" ,
"rtDW.nfi0353erc" , "rtDW.g5guutg2r4" , "rtDW.iecjfocdpt" , "rtDW.pdh0ayrbq2"
, "rtDW.i2jledyuxk" , "rtDW.mk4nogmrgx" , "rtDW.hdgt0peaua" ,
"rtDW.bv534fxrfq" , "rtDW.fudylxbq0j" , "rtDW.bgotvck1y4" , "rtDW.dfulppyfs1"
, "rtDW.o0jhm5tqhv" , "rtDW.gymfbya0lf" , "rtDW.mq4tzms12g" ,
"rtDW.jk5yslpya4" , "rtDW.o0mql2hqjx" , "rtDW.o2pzpkkeul" , "rtDW.njvyqws1h5"
, "rtDW.hblnhilp5j" , "rtDW.dx0psck2g2" , "rtDW.bv5o5ntfep" ,
"rtDW.bmwah53if2" , "rtDW.lustmxh0ru" , "rtDW.o5vdryefj2" , "rtDW.kasvnwnwfd"
, "rtDW.d2hdmgi2df" , "rtDW.eesjxfyvk2" , "rtDW.cdqamvzgi2" ,
"rtDW.a2u1lqkyoh" , "rtDW.mpm2qm4ahz" , "rtDW.arjuzvir0v" , "rtDW.a3naafic3w"
, "rtDW.g0pte1h22i" , "rtDW.ksqmuzqxoq" , "rtDW.cnphnmyixz" ,
"rtDW.lyrzf3l331" , "rtDW.o5lpscgpim" , "rtDW.i33gdokzps" , "rtDW.puvxpdyspy"
, "rtDW.hvipzkfxby" , "rtDW.b2oh0gakei" , "rtDW.j4xo2d0p0j" ,
"rtDW.en0wsgm2d2" , "rtDW.htl3ck05k3" , "rtDW.kf3zpzee4j" , "rtDW.m5g4cvi2wi"
, "rtDW.ifylc1ayya" , "rtDW.f4gzzk1cad" , "rtDW.gizzljrotf" ,
"rtDW.bttm2sqgp0" , "rtDW.csce1vtaiv" , "rtDW.i3eqa0qza0" , "rtDW.agio50d4gu"
, "rtDW.g10sbzotef" , "rtDW.jraid5zlrs" , "rtDW.hjgrew42b2" ,
"rtDW.ntbs21hax4" , "rtDW.eyqkltgelg" , "rtDW.il0ohwuds5" , "rtDW.cuxelkmbzn"
, "rtDW.b0xpqic30u" , "rtDW.iu2ulpoww0" , "rtDW.l4htxomgyb" ,
"rtDW.hhdj03gcse" , "rtDW.e54eqryqod" , "rtDW.ek03o5d0zn" , "rtDW.ouoju14cbw"
, "rtDW.k20nitrd4l" , "rtDW.e5i1gkys053.iaiukld4k4" ,
"rtDW.o0l0tlmums2.nmoh1fygpu" , "rtDW.lsul0j3thv5.b0jtmkqrl5" ,
"rtDW.lvdmxslirzu.ec3xwiqauu" , } ; mxArray * rtdwData = mxCreateStructMatrix
( 1 , 1 , 75 , rtdwDataFieldNames ) ;
mr_cstr_simulationEnv_cacheDataAsMxArray ( rtdwData , 0 , 0 , ( const void *
) & ( rtDW . mz0zdu34tn ) , sizeof ( rtDW . mz0zdu34tn ) ) ;
mr_cstr_simulationEnv_cacheDataAsMxArray ( rtdwData , 0 , 1 , ( const void *
) & ( rtDW . cronjwvq3j ) , sizeof ( rtDW . cronjwvq3j ) ) ;
mr_cstr_simulationEnv_cacheDataAsMxArray ( rtdwData , 0 , 2 , ( const void *
) & ( rtDW . dsnlclvjlf ) , sizeof ( rtDW . dsnlclvjlf ) ) ;
mr_cstr_simulationEnv_cacheDataAsMxArray ( rtdwData , 0 , 3 , ( const void *
) & ( rtDW . nfi0353erc ) , sizeof ( rtDW . nfi0353erc ) ) ;
mr_cstr_simulationEnv_cacheDataAsMxArray ( rtdwData , 0 , 4 , ( const void *
) & ( rtDW . g5guutg2r4 ) , sizeof ( rtDW . g5guutg2r4 ) ) ;
mr_cstr_simulationEnv_cacheDataAsMxArray ( rtdwData , 0 , 5 , ( const void *
) & ( rtDW . iecjfocdpt ) , sizeof ( rtDW . iecjfocdpt ) ) ;
mr_cstr_simulationEnv_cacheDataAsMxArray ( rtdwData , 0 , 6 , ( const void *
) & ( rtDW . pdh0ayrbq2 ) , sizeof ( rtDW . pdh0ayrbq2 ) ) ;
mr_cstr_simulationEnv_cacheDataAsMxArray ( rtdwData , 0 , 7 , ( const void *
) & ( rtDW . i2jledyuxk ) , sizeof ( rtDW . i2jledyuxk ) ) ;
mr_cstr_simulationEnv_cacheDataAsMxArray ( rtdwData , 0 , 8 , ( const void *
) & ( rtDW . mk4nogmrgx ) , sizeof ( rtDW . mk4nogmrgx ) ) ;
mr_cstr_simulationEnv_cacheDataAsMxArray ( rtdwData , 0 , 9 , ( const void *
) & ( rtDW . hdgt0peaua ) , sizeof ( rtDW . hdgt0peaua ) ) ;
mr_cstr_simulationEnv_cacheDataAsMxArray ( rtdwData , 0 , 10 , ( const void *
) & ( rtDW . bv534fxrfq ) , sizeof ( rtDW . bv534fxrfq ) ) ;
mr_cstr_simulationEnv_cacheDataAsMxArray ( rtdwData , 0 , 11 , ( const void *
) & ( rtDW . fudylxbq0j ) , sizeof ( rtDW . fudylxbq0j ) ) ;
mr_cstr_simulationEnv_cacheDataAsMxArray ( rtdwData , 0 , 12 , ( const void *
) & ( rtDW . bgotvck1y4 ) , sizeof ( rtDW . bgotvck1y4 ) ) ;
mr_cstr_simulationEnv_cacheDataAsMxArray ( rtdwData , 0 , 13 , ( const void *
) & ( rtDW . dfulppyfs1 ) , sizeof ( rtDW . dfulppyfs1 ) ) ;
mr_cstr_simulationEnv_cacheDataAsMxArray ( rtdwData , 0 , 14 , ( const void *
) & ( rtDW . o0jhm5tqhv ) , sizeof ( rtDW . o0jhm5tqhv ) ) ;
mr_cstr_simulationEnv_cacheDataAsMxArray ( rtdwData , 0 , 15 , ( const void *
) & ( rtDW . gymfbya0lf ) , sizeof ( rtDW . gymfbya0lf ) ) ;
mr_cstr_simulationEnv_cacheDataAsMxArray ( rtdwData , 0 , 16 , ( const void *
) & ( rtDW . mq4tzms12g ) , sizeof ( rtDW . mq4tzms12g ) ) ;
mr_cstr_simulationEnv_cacheDataAsMxArray ( rtdwData , 0 , 17 , ( const void *
) & ( rtDW . jk5yslpya4 ) , sizeof ( rtDW . jk5yslpya4 ) ) ;
mr_cstr_simulationEnv_cacheDataAsMxArray ( rtdwData , 0 , 18 , ( const void *
) & ( rtDW . o0mql2hqjx ) , sizeof ( rtDW . o0mql2hqjx ) ) ;
mr_cstr_simulationEnv_cacheDataAsMxArray ( rtdwData , 0 , 19 , ( const void *
) & ( rtDW . o2pzpkkeul ) , sizeof ( rtDW . o2pzpkkeul ) ) ;
mr_cstr_simulationEnv_cacheDataAsMxArray ( rtdwData , 0 , 20 , ( const void *
) & ( rtDW . njvyqws1h5 ) , sizeof ( rtDW . njvyqws1h5 ) ) ;
mr_cstr_simulationEnv_cacheDataAsMxArray ( rtdwData , 0 , 21 , ( const void *
) & ( rtDW . hblnhilp5j ) , sizeof ( rtDW . hblnhilp5j ) ) ;
mr_cstr_simulationEnv_cacheDataAsMxArray ( rtdwData , 0 , 22 , ( const void *
) & ( rtDW . dx0psck2g2 ) , sizeof ( rtDW . dx0psck2g2 ) ) ;
mr_cstr_simulationEnv_cacheDataAsMxArray ( rtdwData , 0 , 23 , ( const void *
) & ( rtDW . bv5o5ntfep ) , sizeof ( rtDW . bv5o5ntfep ) ) ;
mr_cstr_simulationEnv_cacheDataAsMxArray ( rtdwData , 0 , 24 , ( const void *
) & ( rtDW . bmwah53if2 ) , sizeof ( rtDW . bmwah53if2 ) ) ;
mr_cstr_simulationEnv_cacheDataAsMxArray ( rtdwData , 0 , 25 , ( const void *
) & ( rtDW . lustmxh0ru ) , sizeof ( rtDW . lustmxh0ru ) ) ;
mr_cstr_simulationEnv_cacheDataAsMxArray ( rtdwData , 0 , 26 , ( const void *
) & ( rtDW . o5vdryefj2 ) , sizeof ( rtDW . o5vdryefj2 ) ) ;
mr_cstr_simulationEnv_cacheDataAsMxArray ( rtdwData , 0 , 27 , ( const void *
) & ( rtDW . kasvnwnwfd ) , sizeof ( rtDW . kasvnwnwfd ) ) ;
mr_cstr_simulationEnv_cacheDataAsMxArray ( rtdwData , 0 , 28 , ( const void *
) & ( rtDW . d2hdmgi2df ) , sizeof ( rtDW . d2hdmgi2df ) ) ;
mr_cstr_simulationEnv_cacheDataAsMxArray ( rtdwData , 0 , 29 , ( const void *
) & ( rtDW . eesjxfyvk2 ) , sizeof ( rtDW . eesjxfyvk2 ) ) ;
mr_cstr_simulationEnv_cacheDataAsMxArray ( rtdwData , 0 , 30 , ( const void *
) & ( rtDW . cdqamvzgi2 ) , sizeof ( rtDW . cdqamvzgi2 ) ) ;
mr_cstr_simulationEnv_cacheDataAsMxArray ( rtdwData , 0 , 31 , ( const void *
) & ( rtDW . a2u1lqkyoh ) , sizeof ( rtDW . a2u1lqkyoh ) ) ;
mr_cstr_simulationEnv_cacheDataAsMxArray ( rtdwData , 0 , 32 , ( const void *
) & ( rtDW . mpm2qm4ahz ) , sizeof ( rtDW . mpm2qm4ahz ) ) ;
mr_cstr_simulationEnv_cacheDataAsMxArray ( rtdwData , 0 , 33 , ( const void *
) & ( rtDW . arjuzvir0v ) , sizeof ( rtDW . arjuzvir0v ) ) ;
mr_cstr_simulationEnv_cacheDataAsMxArray ( rtdwData , 0 , 34 , ( const void *
) & ( rtDW . a3naafic3w ) , sizeof ( rtDW . a3naafic3w ) ) ;
mr_cstr_simulationEnv_cacheDataAsMxArray ( rtdwData , 0 , 35 , ( const void *
) & ( rtDW . g0pte1h22i ) , sizeof ( rtDW . g0pte1h22i ) ) ;
mr_cstr_simulationEnv_cacheDataAsMxArray ( rtdwData , 0 , 36 , ( const void *
) & ( rtDW . ksqmuzqxoq ) , sizeof ( rtDW . ksqmuzqxoq ) ) ;
mr_cstr_simulationEnv_cacheDataAsMxArray ( rtdwData , 0 , 37 , ( const void *
) & ( rtDW . cnphnmyixz ) , sizeof ( rtDW . cnphnmyixz ) ) ;
mr_cstr_simulationEnv_cacheDataAsMxArray ( rtdwData , 0 , 38 , ( const void *
) & ( rtDW . lyrzf3l331 ) , sizeof ( rtDW . lyrzf3l331 ) ) ;
mr_cstr_simulationEnv_cacheDataAsMxArray ( rtdwData , 0 , 39 , ( const void *
) & ( rtDW . o5lpscgpim ) , sizeof ( rtDW . o5lpscgpim ) ) ;
mr_cstr_simulationEnv_cacheDataAsMxArray ( rtdwData , 0 , 40 , ( const void *
) & ( rtDW . i33gdokzps ) , sizeof ( rtDW . i33gdokzps ) ) ;
mr_cstr_simulationEnv_cacheDataAsMxArray ( rtdwData , 0 , 41 , ( const void *
) & ( rtDW . puvxpdyspy ) , sizeof ( rtDW . puvxpdyspy ) ) ;
mr_cstr_simulationEnv_cacheDataAsMxArray ( rtdwData , 0 , 42 , ( const void *
) & ( rtDW . hvipzkfxby ) , sizeof ( rtDW . hvipzkfxby ) ) ;
mr_cstr_simulationEnv_cacheDataAsMxArray ( rtdwData , 0 , 43 , ( const void *
) & ( rtDW . b2oh0gakei ) , sizeof ( rtDW . b2oh0gakei ) ) ;
mr_cstr_simulationEnv_cacheDataAsMxArray ( rtdwData , 0 , 44 , ( const void *
) & ( rtDW . j4xo2d0p0j ) , sizeof ( rtDW . j4xo2d0p0j ) ) ;
mr_cstr_simulationEnv_cacheDataAsMxArray ( rtdwData , 0 , 45 , ( const void *
) & ( rtDW . en0wsgm2d2 ) , sizeof ( rtDW . en0wsgm2d2 ) ) ;
mr_cstr_simulationEnv_cacheDataAsMxArray ( rtdwData , 0 , 46 , ( const void *
) & ( rtDW . htl3ck05k3 ) , sizeof ( rtDW . htl3ck05k3 ) ) ;
mr_cstr_simulationEnv_cacheDataAsMxArray ( rtdwData , 0 , 47 , ( const void *
) & ( rtDW . kf3zpzee4j ) , sizeof ( rtDW . kf3zpzee4j ) ) ;
mr_cstr_simulationEnv_cacheDataAsMxArray ( rtdwData , 0 , 48 , ( const void *
) & ( rtDW . m5g4cvi2wi ) , sizeof ( rtDW . m5g4cvi2wi ) ) ;
mr_cstr_simulationEnv_cacheDataAsMxArray ( rtdwData , 0 , 49 , ( const void *
) & ( rtDW . ifylc1ayya ) , sizeof ( rtDW . ifylc1ayya ) ) ;
mr_cstr_simulationEnv_cacheDataAsMxArray ( rtdwData , 0 , 50 , ( const void *
) & ( rtDW . f4gzzk1cad ) , sizeof ( rtDW . f4gzzk1cad ) ) ;
mr_cstr_simulationEnv_cacheDataAsMxArray ( rtdwData , 0 , 51 , ( const void *
) & ( rtDW . gizzljrotf ) , sizeof ( rtDW . gizzljrotf ) ) ;
mr_cstr_simulationEnv_cacheDataAsMxArray ( rtdwData , 0 , 52 , ( const void *
) & ( rtDW . bttm2sqgp0 ) , sizeof ( rtDW . bttm2sqgp0 ) ) ;
mr_cstr_simulationEnv_cacheDataAsMxArray ( rtdwData , 0 , 53 , ( const void *
) & ( rtDW . csce1vtaiv ) , sizeof ( rtDW . csce1vtaiv ) ) ;
mr_cstr_simulationEnv_cacheDataAsMxArray ( rtdwData , 0 , 54 , ( const void *
) & ( rtDW . i3eqa0qza0 ) , sizeof ( rtDW . i3eqa0qza0 ) ) ;
mr_cstr_simulationEnv_cacheDataAsMxArray ( rtdwData , 0 , 55 , ( const void *
) & ( rtDW . agio50d4gu ) , sizeof ( rtDW . agio50d4gu ) ) ;
mr_cstr_simulationEnv_cacheDataAsMxArray ( rtdwData , 0 , 56 , ( const void *
) & ( rtDW . g10sbzotef ) , sizeof ( rtDW . g10sbzotef ) ) ;
mr_cstr_simulationEnv_cacheDataAsMxArray ( rtdwData , 0 , 57 , ( const void *
) & ( rtDW . jraid5zlrs ) , sizeof ( rtDW . jraid5zlrs ) ) ;
mr_cstr_simulationEnv_cacheDataAsMxArray ( rtdwData , 0 , 58 , ( const void *
) & ( rtDW . hjgrew42b2 ) , sizeof ( rtDW . hjgrew42b2 ) ) ;
mr_cstr_simulationEnv_cacheDataAsMxArray ( rtdwData , 0 , 59 , ( const void *
) & ( rtDW . ntbs21hax4 ) , sizeof ( rtDW . ntbs21hax4 ) ) ;
mr_cstr_simulationEnv_cacheDataAsMxArray ( rtdwData , 0 , 60 , ( const void *
) & ( rtDW . eyqkltgelg ) , sizeof ( rtDW . eyqkltgelg ) ) ;
mr_cstr_simulationEnv_cacheDataAsMxArray ( rtdwData , 0 , 61 , ( const void *
) & ( rtDW . il0ohwuds5 ) , sizeof ( rtDW . il0ohwuds5 ) ) ;
mr_cstr_simulationEnv_cacheDataAsMxArray ( rtdwData , 0 , 62 , ( const void *
) & ( rtDW . cuxelkmbzn ) , sizeof ( rtDW . cuxelkmbzn ) ) ;
mr_cstr_simulationEnv_cacheDataAsMxArray ( rtdwData , 0 , 63 , ( const void *
) & ( rtDW . b0xpqic30u ) , sizeof ( rtDW . b0xpqic30u ) ) ;
mr_cstr_simulationEnv_cacheDataAsMxArray ( rtdwData , 0 , 64 , ( const void *
) & ( rtDW . iu2ulpoww0 ) , sizeof ( rtDW . iu2ulpoww0 ) ) ;
mr_cstr_simulationEnv_cacheDataAsMxArray ( rtdwData , 0 , 65 , ( const void *
) & ( rtDW . l4htxomgyb ) , sizeof ( rtDW . l4htxomgyb ) ) ;
mr_cstr_simulationEnv_cacheDataAsMxArray ( rtdwData , 0 , 66 , ( const void *
) & ( rtDW . hhdj03gcse ) , sizeof ( rtDW . hhdj03gcse ) ) ;
mr_cstr_simulationEnv_cacheDataAsMxArray ( rtdwData , 0 , 67 , ( const void *
) & ( rtDW . e54eqryqod ) , sizeof ( rtDW . e54eqryqod ) ) ;
mr_cstr_simulationEnv_cacheDataAsMxArray ( rtdwData , 0 , 68 , ( const void *
) & ( rtDW . ek03o5d0zn ) , sizeof ( rtDW . ek03o5d0zn ) ) ;
mr_cstr_simulationEnv_cacheDataAsMxArray ( rtdwData , 0 , 69 , ( const void *
) & ( rtDW . ouoju14cbw ) , sizeof ( rtDW . ouoju14cbw ) ) ;
mr_cstr_simulationEnv_cacheDataAsMxArray ( rtdwData , 0 , 70 , ( const void *
) & ( rtDW . k20nitrd4l ) , sizeof ( rtDW . k20nitrd4l ) ) ;
mr_cstr_simulationEnv_cacheDataAsMxArray ( rtdwData , 0 , 71 , ( const void *
) & ( rtDW . e5i1gkys053 . iaiukld4k4 ) , sizeof ( rtDW . e5i1gkys053 .
iaiukld4k4 ) ) ; mr_cstr_simulationEnv_cacheDataAsMxArray ( rtdwData , 0 , 72
, ( const void * ) & ( rtDW . o0l0tlmums2 . nmoh1fygpu ) , sizeof ( rtDW .
o0l0tlmums2 . nmoh1fygpu ) ) ; mr_cstr_simulationEnv_cacheDataAsMxArray (
rtdwData , 0 , 73 , ( const void * ) & ( rtDW . lsul0j3thv5 . b0jtmkqrl5 ) ,
sizeof ( rtDW . lsul0j3thv5 . b0jtmkqrl5 ) ) ;
mr_cstr_simulationEnv_cacheDataAsMxArray ( rtdwData , 0 , 74 , ( const void *
) & ( rtDW . lvdmxslirzu . ec3xwiqauu ) , sizeof ( rtDW . lvdmxslirzu .
ec3xwiqauu ) ) ; mxSetFieldByNumber ( ssDW , 0 , 1 , rtdwData ) ; } return
ssDW ; } void mr_cstr_simulationEnv_SetDWork ( const mxArray * ssDW ) { (
void ) ssDW ; mr_cstr_simulationEnv_restoreDataFromMxArray ( ( void * ) & (
rtB ) , ssDW , 0 , 0 , sizeof ( rtB ) ) ; { const mxArray * rtdwData =
mxGetFieldByNumber ( ssDW , 0 , 1 ) ;
mr_cstr_simulationEnv_restoreDataFromMxArray ( ( void * ) & ( rtDW .
mz0zdu34tn ) , rtdwData , 0 , 0 , sizeof ( rtDW . mz0zdu34tn ) ) ;
mr_cstr_simulationEnv_restoreDataFromMxArray ( ( void * ) & ( rtDW .
cronjwvq3j ) , rtdwData , 0 , 1 , sizeof ( rtDW . cronjwvq3j ) ) ;
mr_cstr_simulationEnv_restoreDataFromMxArray ( ( void * ) & ( rtDW .
dsnlclvjlf ) , rtdwData , 0 , 2 , sizeof ( rtDW . dsnlclvjlf ) ) ;
mr_cstr_simulationEnv_restoreDataFromMxArray ( ( void * ) & ( rtDW .
nfi0353erc ) , rtdwData , 0 , 3 , sizeof ( rtDW . nfi0353erc ) ) ;
mr_cstr_simulationEnv_restoreDataFromMxArray ( ( void * ) & ( rtDW .
g5guutg2r4 ) , rtdwData , 0 , 4 , sizeof ( rtDW . g5guutg2r4 ) ) ;
mr_cstr_simulationEnv_restoreDataFromMxArray ( ( void * ) & ( rtDW .
iecjfocdpt ) , rtdwData , 0 , 5 , sizeof ( rtDW . iecjfocdpt ) ) ;
mr_cstr_simulationEnv_restoreDataFromMxArray ( ( void * ) & ( rtDW .
pdh0ayrbq2 ) , rtdwData , 0 , 6 , sizeof ( rtDW . pdh0ayrbq2 ) ) ;
mr_cstr_simulationEnv_restoreDataFromMxArray ( ( void * ) & ( rtDW .
i2jledyuxk ) , rtdwData , 0 , 7 , sizeof ( rtDW . i2jledyuxk ) ) ;
mr_cstr_simulationEnv_restoreDataFromMxArray ( ( void * ) & ( rtDW .
mk4nogmrgx ) , rtdwData , 0 , 8 , sizeof ( rtDW . mk4nogmrgx ) ) ;
mr_cstr_simulationEnv_restoreDataFromMxArray ( ( void * ) & ( rtDW .
hdgt0peaua ) , rtdwData , 0 , 9 , sizeof ( rtDW . hdgt0peaua ) ) ;
mr_cstr_simulationEnv_restoreDataFromMxArray ( ( void * ) & ( rtDW .
bv534fxrfq ) , rtdwData , 0 , 10 , sizeof ( rtDW . bv534fxrfq ) ) ;
mr_cstr_simulationEnv_restoreDataFromMxArray ( ( void * ) & ( rtDW .
fudylxbq0j ) , rtdwData , 0 , 11 , sizeof ( rtDW . fudylxbq0j ) ) ;
mr_cstr_simulationEnv_restoreDataFromMxArray ( ( void * ) & ( rtDW .
bgotvck1y4 ) , rtdwData , 0 , 12 , sizeof ( rtDW . bgotvck1y4 ) ) ;
mr_cstr_simulationEnv_restoreDataFromMxArray ( ( void * ) & ( rtDW .
dfulppyfs1 ) , rtdwData , 0 , 13 , sizeof ( rtDW . dfulppyfs1 ) ) ;
mr_cstr_simulationEnv_restoreDataFromMxArray ( ( void * ) & ( rtDW .
o0jhm5tqhv ) , rtdwData , 0 , 14 , sizeof ( rtDW . o0jhm5tqhv ) ) ;
mr_cstr_simulationEnv_restoreDataFromMxArray ( ( void * ) & ( rtDW .
gymfbya0lf ) , rtdwData , 0 , 15 , sizeof ( rtDW . gymfbya0lf ) ) ;
mr_cstr_simulationEnv_restoreDataFromMxArray ( ( void * ) & ( rtDW .
mq4tzms12g ) , rtdwData , 0 , 16 , sizeof ( rtDW . mq4tzms12g ) ) ;
mr_cstr_simulationEnv_restoreDataFromMxArray ( ( void * ) & ( rtDW .
jk5yslpya4 ) , rtdwData , 0 , 17 , sizeof ( rtDW . jk5yslpya4 ) ) ;
mr_cstr_simulationEnv_restoreDataFromMxArray ( ( void * ) & ( rtDW .
o0mql2hqjx ) , rtdwData , 0 , 18 , sizeof ( rtDW . o0mql2hqjx ) ) ;
mr_cstr_simulationEnv_restoreDataFromMxArray ( ( void * ) & ( rtDW .
o2pzpkkeul ) , rtdwData , 0 , 19 , sizeof ( rtDW . o2pzpkkeul ) ) ;
mr_cstr_simulationEnv_restoreDataFromMxArray ( ( void * ) & ( rtDW .
njvyqws1h5 ) , rtdwData , 0 , 20 , sizeof ( rtDW . njvyqws1h5 ) ) ;
mr_cstr_simulationEnv_restoreDataFromMxArray ( ( void * ) & ( rtDW .
hblnhilp5j ) , rtdwData , 0 , 21 , sizeof ( rtDW . hblnhilp5j ) ) ;
mr_cstr_simulationEnv_restoreDataFromMxArray ( ( void * ) & ( rtDW .
dx0psck2g2 ) , rtdwData , 0 , 22 , sizeof ( rtDW . dx0psck2g2 ) ) ;
mr_cstr_simulationEnv_restoreDataFromMxArray ( ( void * ) & ( rtDW .
bv5o5ntfep ) , rtdwData , 0 , 23 , sizeof ( rtDW . bv5o5ntfep ) ) ;
mr_cstr_simulationEnv_restoreDataFromMxArray ( ( void * ) & ( rtDW .
bmwah53if2 ) , rtdwData , 0 , 24 , sizeof ( rtDW . bmwah53if2 ) ) ;
mr_cstr_simulationEnv_restoreDataFromMxArray ( ( void * ) & ( rtDW .
lustmxh0ru ) , rtdwData , 0 , 25 , sizeof ( rtDW . lustmxh0ru ) ) ;
mr_cstr_simulationEnv_restoreDataFromMxArray ( ( void * ) & ( rtDW .
o5vdryefj2 ) , rtdwData , 0 , 26 , sizeof ( rtDW . o5vdryefj2 ) ) ;
mr_cstr_simulationEnv_restoreDataFromMxArray ( ( void * ) & ( rtDW .
kasvnwnwfd ) , rtdwData , 0 , 27 , sizeof ( rtDW . kasvnwnwfd ) ) ;
mr_cstr_simulationEnv_restoreDataFromMxArray ( ( void * ) & ( rtDW .
d2hdmgi2df ) , rtdwData , 0 , 28 , sizeof ( rtDW . d2hdmgi2df ) ) ;
mr_cstr_simulationEnv_restoreDataFromMxArray ( ( void * ) & ( rtDW .
eesjxfyvk2 ) , rtdwData , 0 , 29 , sizeof ( rtDW . eesjxfyvk2 ) ) ;
mr_cstr_simulationEnv_restoreDataFromMxArray ( ( void * ) & ( rtDW .
cdqamvzgi2 ) , rtdwData , 0 , 30 , sizeof ( rtDW . cdqamvzgi2 ) ) ;
mr_cstr_simulationEnv_restoreDataFromMxArray ( ( void * ) & ( rtDW .
a2u1lqkyoh ) , rtdwData , 0 , 31 , sizeof ( rtDW . a2u1lqkyoh ) ) ;
mr_cstr_simulationEnv_restoreDataFromMxArray ( ( void * ) & ( rtDW .
mpm2qm4ahz ) , rtdwData , 0 , 32 , sizeof ( rtDW . mpm2qm4ahz ) ) ;
mr_cstr_simulationEnv_restoreDataFromMxArray ( ( void * ) & ( rtDW .
arjuzvir0v ) , rtdwData , 0 , 33 , sizeof ( rtDW . arjuzvir0v ) ) ;
mr_cstr_simulationEnv_restoreDataFromMxArray ( ( void * ) & ( rtDW .
a3naafic3w ) , rtdwData , 0 , 34 , sizeof ( rtDW . a3naafic3w ) ) ;
mr_cstr_simulationEnv_restoreDataFromMxArray ( ( void * ) & ( rtDW .
g0pte1h22i ) , rtdwData , 0 , 35 , sizeof ( rtDW . g0pte1h22i ) ) ;
mr_cstr_simulationEnv_restoreDataFromMxArray ( ( void * ) & ( rtDW .
ksqmuzqxoq ) , rtdwData , 0 , 36 , sizeof ( rtDW . ksqmuzqxoq ) ) ;
mr_cstr_simulationEnv_restoreDataFromMxArray ( ( void * ) & ( rtDW .
cnphnmyixz ) , rtdwData , 0 , 37 , sizeof ( rtDW . cnphnmyixz ) ) ;
mr_cstr_simulationEnv_restoreDataFromMxArray ( ( void * ) & ( rtDW .
lyrzf3l331 ) , rtdwData , 0 , 38 , sizeof ( rtDW . lyrzf3l331 ) ) ;
mr_cstr_simulationEnv_restoreDataFromMxArray ( ( void * ) & ( rtDW .
o5lpscgpim ) , rtdwData , 0 , 39 , sizeof ( rtDW . o5lpscgpim ) ) ;
mr_cstr_simulationEnv_restoreDataFromMxArray ( ( void * ) & ( rtDW .
i33gdokzps ) , rtdwData , 0 , 40 , sizeof ( rtDW . i33gdokzps ) ) ;
mr_cstr_simulationEnv_restoreDataFromMxArray ( ( void * ) & ( rtDW .
puvxpdyspy ) , rtdwData , 0 , 41 , sizeof ( rtDW . puvxpdyspy ) ) ;
mr_cstr_simulationEnv_restoreDataFromMxArray ( ( void * ) & ( rtDW .
hvipzkfxby ) , rtdwData , 0 , 42 , sizeof ( rtDW . hvipzkfxby ) ) ;
mr_cstr_simulationEnv_restoreDataFromMxArray ( ( void * ) & ( rtDW .
b2oh0gakei ) , rtdwData , 0 , 43 , sizeof ( rtDW . b2oh0gakei ) ) ;
mr_cstr_simulationEnv_restoreDataFromMxArray ( ( void * ) & ( rtDW .
j4xo2d0p0j ) , rtdwData , 0 , 44 , sizeof ( rtDW . j4xo2d0p0j ) ) ;
mr_cstr_simulationEnv_restoreDataFromMxArray ( ( void * ) & ( rtDW .
en0wsgm2d2 ) , rtdwData , 0 , 45 , sizeof ( rtDW . en0wsgm2d2 ) ) ;
mr_cstr_simulationEnv_restoreDataFromMxArray ( ( void * ) & ( rtDW .
htl3ck05k3 ) , rtdwData , 0 , 46 , sizeof ( rtDW . htl3ck05k3 ) ) ;
mr_cstr_simulationEnv_restoreDataFromMxArray ( ( void * ) & ( rtDW .
kf3zpzee4j ) , rtdwData , 0 , 47 , sizeof ( rtDW . kf3zpzee4j ) ) ;
mr_cstr_simulationEnv_restoreDataFromMxArray ( ( void * ) & ( rtDW .
m5g4cvi2wi ) , rtdwData , 0 , 48 , sizeof ( rtDW . m5g4cvi2wi ) ) ;
mr_cstr_simulationEnv_restoreDataFromMxArray ( ( void * ) & ( rtDW .
ifylc1ayya ) , rtdwData , 0 , 49 , sizeof ( rtDW . ifylc1ayya ) ) ;
mr_cstr_simulationEnv_restoreDataFromMxArray ( ( void * ) & ( rtDW .
f4gzzk1cad ) , rtdwData , 0 , 50 , sizeof ( rtDW . f4gzzk1cad ) ) ;
mr_cstr_simulationEnv_restoreDataFromMxArray ( ( void * ) & ( rtDW .
gizzljrotf ) , rtdwData , 0 , 51 , sizeof ( rtDW . gizzljrotf ) ) ;
mr_cstr_simulationEnv_restoreDataFromMxArray ( ( void * ) & ( rtDW .
bttm2sqgp0 ) , rtdwData , 0 , 52 , sizeof ( rtDW . bttm2sqgp0 ) ) ;
mr_cstr_simulationEnv_restoreDataFromMxArray ( ( void * ) & ( rtDW .
csce1vtaiv ) , rtdwData , 0 , 53 , sizeof ( rtDW . csce1vtaiv ) ) ;
mr_cstr_simulationEnv_restoreDataFromMxArray ( ( void * ) & ( rtDW .
i3eqa0qza0 ) , rtdwData , 0 , 54 , sizeof ( rtDW . i3eqa0qza0 ) ) ;
mr_cstr_simulationEnv_restoreDataFromMxArray ( ( void * ) & ( rtDW .
agio50d4gu ) , rtdwData , 0 , 55 , sizeof ( rtDW . agio50d4gu ) ) ;
mr_cstr_simulationEnv_restoreDataFromMxArray ( ( void * ) & ( rtDW .
g10sbzotef ) , rtdwData , 0 , 56 , sizeof ( rtDW . g10sbzotef ) ) ;
mr_cstr_simulationEnv_restoreDataFromMxArray ( ( void * ) & ( rtDW .
jraid5zlrs ) , rtdwData , 0 , 57 , sizeof ( rtDW . jraid5zlrs ) ) ;
mr_cstr_simulationEnv_restoreDataFromMxArray ( ( void * ) & ( rtDW .
hjgrew42b2 ) , rtdwData , 0 , 58 , sizeof ( rtDW . hjgrew42b2 ) ) ;
mr_cstr_simulationEnv_restoreDataFromMxArray ( ( void * ) & ( rtDW .
ntbs21hax4 ) , rtdwData , 0 , 59 , sizeof ( rtDW . ntbs21hax4 ) ) ;
mr_cstr_simulationEnv_restoreDataFromMxArray ( ( void * ) & ( rtDW .
eyqkltgelg ) , rtdwData , 0 , 60 , sizeof ( rtDW . eyqkltgelg ) ) ;
mr_cstr_simulationEnv_restoreDataFromMxArray ( ( void * ) & ( rtDW .
il0ohwuds5 ) , rtdwData , 0 , 61 , sizeof ( rtDW . il0ohwuds5 ) ) ;
mr_cstr_simulationEnv_restoreDataFromMxArray ( ( void * ) & ( rtDW .
cuxelkmbzn ) , rtdwData , 0 , 62 , sizeof ( rtDW . cuxelkmbzn ) ) ;
mr_cstr_simulationEnv_restoreDataFromMxArray ( ( void * ) & ( rtDW .
b0xpqic30u ) , rtdwData , 0 , 63 , sizeof ( rtDW . b0xpqic30u ) ) ;
mr_cstr_simulationEnv_restoreDataFromMxArray ( ( void * ) & ( rtDW .
iu2ulpoww0 ) , rtdwData , 0 , 64 , sizeof ( rtDW . iu2ulpoww0 ) ) ;
mr_cstr_simulationEnv_restoreDataFromMxArray ( ( void * ) & ( rtDW .
l4htxomgyb ) , rtdwData , 0 , 65 , sizeof ( rtDW . l4htxomgyb ) ) ;
mr_cstr_simulationEnv_restoreDataFromMxArray ( ( void * ) & ( rtDW .
hhdj03gcse ) , rtdwData , 0 , 66 , sizeof ( rtDW . hhdj03gcse ) ) ;
mr_cstr_simulationEnv_restoreDataFromMxArray ( ( void * ) & ( rtDW .
e54eqryqod ) , rtdwData , 0 , 67 , sizeof ( rtDW . e54eqryqod ) ) ;
mr_cstr_simulationEnv_restoreDataFromMxArray ( ( void * ) & ( rtDW .
ek03o5d0zn ) , rtdwData , 0 , 68 , sizeof ( rtDW . ek03o5d0zn ) ) ;
mr_cstr_simulationEnv_restoreDataFromMxArray ( ( void * ) & ( rtDW .
ouoju14cbw ) , rtdwData , 0 , 69 , sizeof ( rtDW . ouoju14cbw ) ) ;
mr_cstr_simulationEnv_restoreDataFromMxArray ( ( void * ) & ( rtDW .
k20nitrd4l ) , rtdwData , 0 , 70 , sizeof ( rtDW . k20nitrd4l ) ) ;
mr_cstr_simulationEnv_restoreDataFromMxArray ( ( void * ) & ( rtDW .
e5i1gkys053 . iaiukld4k4 ) , rtdwData , 0 , 71 , sizeof ( rtDW . e5i1gkys053
. iaiukld4k4 ) ) ; mr_cstr_simulationEnv_restoreDataFromMxArray ( ( void * )
& ( rtDW . o0l0tlmums2 . nmoh1fygpu ) , rtdwData , 0 , 72 , sizeof ( rtDW .
o0l0tlmums2 . nmoh1fygpu ) ) ; mr_cstr_simulationEnv_restoreDataFromMxArray (
( void * ) & ( rtDW . lsul0j3thv5 . b0jtmkqrl5 ) , rtdwData , 0 , 73 , sizeof
( rtDW . lsul0j3thv5 . b0jtmkqrl5 ) ) ;
mr_cstr_simulationEnv_restoreDataFromMxArray ( ( void * ) & ( rtDW .
lvdmxslirzu . ec3xwiqauu ) , rtdwData , 0 , 74 , sizeof ( rtDW . lvdmxslirzu
. ec3xwiqauu ) ) ; } } mxArray *
mr_cstr_simulationEnv_GetSimStateDisallowedBlocks ( ) { mxArray * data =
mxCreateCellMatrix ( 10 , 3 ) ; mwIndex subs [ 2 ] , offset ; { static const
char * blockType [ 10 ] = { "Scope" , "Scope" , "Scope" , "Scope" , "Scope" ,
"Scope" , "Scope" , "Scope" , "Scope" , "ToFile" , } ; static const char *
blockPath [ 10 ] = {
"cstr_simulationEnv/CSTR_1 Simulation Model + Regulatory Control/C_A_Display"
,
"cstr_simulationEnv/CSTR_1 Simulation Model + Regulatory Control/C_B_Display"
,
"cstr_simulationEnv/CSTR_1 Simulation Model + Regulatory Control/C_C_Display"
,
"cstr_simulationEnv/CSTR_1 Simulation Model + Regulatory Control/C_D_Display"
,
"cstr_simulationEnv/CSTR_1 Simulation Model + Regulatory Control/F_in_Display"
,
"cstr_simulationEnv/CSTR_1 Simulation Model + Regulatory Control/F_out_Display"
,
"cstr_simulationEnv/CSTR_1 Simulation Model + Regulatory Control/Level_Display"
,
"cstr_simulationEnv/CSTR_1 Simulation Model + Regulatory Control/Profit_Display"
,
"cstr_simulationEnv/CSTR_1 Simulation Model + Regulatory Control/T_out_Display"
, "cstr_simulationEnv/CSTR_1 Simulation Model + Regulatory Control/To File" ,
} ; static const int reason [ 10 ] = { 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0
, } ; for ( subs [ 0 ] = 0 ; subs [ 0 ] < 10 ; ++ ( subs [ 0 ] ) ) { subs [ 1
] = 0 ; offset = mxCalcSingleSubscript ( data , 2 , subs ) ; mxSetCell ( data
, offset , mxCreateString ( blockType [ subs [ 0 ] ] ) ) ; subs [ 1 ] = 1 ;
offset = mxCalcSingleSubscript ( data , 2 , subs ) ; mxSetCell ( data ,
offset , mxCreateString ( blockPath [ subs [ 0 ] ] ) ) ; subs [ 1 ] = 2 ;
offset = mxCalcSingleSubscript ( data , 2 , subs ) ; mxSetCell ( data ,
offset , mxCreateDoubleScalar ( ( double ) reason [ subs [ 0 ] ] ) ) ; } }
return data ; } void MdlInitializeSizes ( void ) { ssSetNumContStates ( rtS ,
11 ) ; ssSetNumPeriodicContStates ( rtS , 0 ) ; ssSetNumY ( rtS , 0 ) ;
ssSetNumU ( rtS , 0 ) ; ssSetDirectFeedThrough ( rtS , 0 ) ;
ssSetNumSampleTimes ( rtS , 4 ) ; ssSetNumBlocks ( rtS , 251 ) ;
ssSetNumBlockIO ( rtS , 74 ) ; ssSetNumBlockParams ( rtS , 20177 ) ; } void
MdlInitializeSampleTimes ( void ) { ssSetSampleTime ( rtS , 0 , 0.0 ) ;
ssSetSampleTime ( rtS , 1 , 1.0 ) ; ssSetSampleTime ( rtS , 2 , 5.0 ) ;
ssSetSampleTime ( rtS , 3 , 500.0 ) ; ssSetOffsetTime ( rtS , 0 , 0.0 ) ;
ssSetOffsetTime ( rtS , 1 , 0.0 ) ; ssSetOffsetTime ( rtS , 2 , 0.0 ) ;
ssSetOffsetTime ( rtS , 3 , 0.0 ) ; } void raccel_set_checksum ( ) {
ssSetChecksumVal ( rtS , 0 , 4260740495U ) ; ssSetChecksumVal ( rtS , 1 ,
4141272003U ) ; ssSetChecksumVal ( rtS , 2 , 4182188841U ) ; ssSetChecksumVal
( rtS , 3 , 2629175771U ) ; }
#if defined(_MSC_VER)
#pragma optimize( "", off )
#endif
SimStruct * raccel_register_model ( ssExecutionInfo * executionInfo ) {
static struct _ssMdlInfo mdlInfo ; static struct _ssBlkInfo2 blkInfo2 ;
static struct _ssBlkInfoSLSize blkInfoSLSize ; ( void ) memset ( ( char * )
rtS , 0 , sizeof ( SimStruct ) ) ; ( void ) memset ( ( char * ) & mdlInfo , 0
, sizeof ( struct _ssMdlInfo ) ) ; ( void ) memset ( ( char * ) & blkInfo2 ,
0 , sizeof ( struct _ssBlkInfo2 ) ) ; ( void ) memset ( ( char * ) &
blkInfoSLSize , 0 , sizeof ( struct _ssBlkInfoSLSize ) ) ; ssSetBlkInfo2Ptr (
rtS , & blkInfo2 ) ; ssSetBlkInfoSLSizePtr ( rtS , & blkInfoSLSize ) ;
ssSetMdlInfoPtr ( rtS , & mdlInfo ) ; ssSetExecutionInfo ( rtS ,
executionInfo ) ; slsaAllocOPModelData ( rtS ) ; { static time_T mdlPeriod [
NSAMPLE_TIMES ] ; static time_T mdlOffset [ NSAMPLE_TIMES ] ; static time_T
mdlTaskTimes [ NSAMPLE_TIMES ] ; static int_T mdlTsMap [ NSAMPLE_TIMES ] ;
static int_T mdlSampleHits [ NSAMPLE_TIMES ] ; static boolean_T
mdlTNextWasAdjustedPtr [ NSAMPLE_TIMES ] ; static int_T mdlPerTaskSampleHits
[ NSAMPLE_TIMES * NSAMPLE_TIMES ] ; static time_T mdlTimeOfNextSampleHit [
NSAMPLE_TIMES ] ; { int_T i ; for ( i = 0 ; i < NSAMPLE_TIMES ; i ++ ) {
mdlPeriod [ i ] = 0.0 ; mdlOffset [ i ] = 0.0 ; mdlTaskTimes [ i ] = 0.0 ;
mdlTsMap [ i ] = i ; mdlSampleHits [ i ] = 1 ; } } ssSetSampleTimePtr ( rtS ,
& mdlPeriod [ 0 ] ) ; ssSetOffsetTimePtr ( rtS , & mdlOffset [ 0 ] ) ;
ssSetSampleTimeTaskIDPtr ( rtS , & mdlTsMap [ 0 ] ) ; ssSetTPtr ( rtS , &
mdlTaskTimes [ 0 ] ) ; ssSetSampleHitPtr ( rtS , & mdlSampleHits [ 0 ] ) ;
ssSetTNextWasAdjustedPtr ( rtS , & mdlTNextWasAdjustedPtr [ 0 ] ) ;
ssSetPerTaskSampleHitsPtr ( rtS , & mdlPerTaskSampleHits [ 0 ] ) ;
ssSetTimeOfNextSampleHitPtr ( rtS , & mdlTimeOfNextSampleHit [ 0 ] ) ; }
ssSetSolverMode ( rtS , SOLVER_MODE_SINGLETASKING ) ; { ssSetBlockIO ( rtS ,
( ( void * ) & rtB ) ) ; ( void ) memset ( ( ( void * ) & rtB ) , 0 , sizeof
( B ) ) ; } { real_T * x = ( real_T * ) & rtX ; ssSetContStates ( rtS , x ) ;
( void ) memset ( ( void * ) x , 0 , sizeof ( X ) ) ; } { void * dwork = (
void * ) & rtDW ; ssSetRootDWork ( rtS , dwork ) ; ( void ) memset ( dwork ,
0 , sizeof ( DW ) ) ; } { static DataTypeTransInfo dtInfo ; ( void ) memset (
( char_T * ) & dtInfo , 0 , sizeof ( dtInfo ) ) ; ssSetModelMappingInfo ( rtS
, & dtInfo ) ; dtInfo . numDataTypes = 23 ; dtInfo . dataTypeSizes = &
rtDataTypeSizes [ 0 ] ; dtInfo . dataTypeNames = & rtDataTypeNames [ 0 ] ;
dtInfo . BTransTable = & rtBTransTable ; dtInfo . PTransTable = &
rtPTransTable ; dtInfo . dataTypeInfoTable = rtDataTypeInfoTable ; }
cstr_simulationEnv_InitializeDataMapInfo ( ) ; ssSetIsRapidAcceleratorActive
( rtS , true ) ; ssSetRootSS ( rtS , rtS ) ; ssSetVersion ( rtS ,
SIMSTRUCT_VERSION_LEVEL2 ) ; ssSetModelName ( rtS , "cstr_simulationEnv" ) ;
ssSetPath ( rtS , "cstr_simulationEnv" ) ; ssSetTStart ( rtS , 0.0 ) ;
ssSetTFinal ( rtS , 1000.0 ) ; ssSetStepSize ( rtS , 1.0 ) ;
ssSetFixedStepSize ( rtS , 1.0 ) ; { static RTWLogInfo rt_DataLoggingInfo ;
rt_DataLoggingInfo . loggingInterval = ( NULL ) ; ssSetRTWLogInfo ( rtS , &
rt_DataLoggingInfo ) ; } { { static int_T rt_LoggedStateWidths [ ] = { 6 , 1
, 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 } ;
static int_T rt_LoggedStateNumDimensions [ ] = { 1 , 1 , 1 , 1 , 1 , 1 , 1 ,
1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 } ; static int_T
rt_LoggedStateDimensions [ ] = { 6 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 ,
1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 } ; static boolean_T rt_LoggedStateIsVarDims [
] = { 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 ,
0 } ; static BuiltInDTypeId rt_LoggedStateDataTypeIds [ ] = { SS_DOUBLE ,
SS_DOUBLE , SS_DOUBLE , SS_DOUBLE , SS_DOUBLE , SS_DOUBLE , SS_DOUBLE ,
SS_DOUBLE , SS_DOUBLE , SS_DOUBLE , SS_DOUBLE , SS_DOUBLE , SS_DOUBLE ,
SS_DOUBLE , SS_DOUBLE , SS_DOUBLE , SS_BOOLEAN , SS_BOOLEAN , SS_BOOLEAN } ;
static int_T rt_LoggedStateComplexSignals [ ] = { 0 , 0 , 0 , 0 , 0 , 0 , 0 ,
0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 } ; static
RTWPreprocessingFcnPtr rt_LoggingStatePreprocessingFcnPtrs [ ] = { ( NULL ) ,
( NULL ) , ( NULL ) , ( NULL ) , ( NULL ) , ( NULL ) , ( NULL ) , ( NULL ) ,
( NULL ) , ( NULL ) , ( NULL ) , ( NULL ) , ( NULL ) , ( NULL ) , ( NULL ) ,
( NULL ) , ( NULL ) , ( NULL ) , ( NULL ) } ; static const char_T *
rt_LoggedStateLabels [ ] = { "CSTATE" , "CSTATE" , "CSTATE" , "CSTATE" ,
"CSTATE" , "CSTATE" , "DSTATE" , "DSTATE" , "DSTATE" , "DSTATE" , "DSTATE" ,
"DSTATE" , "DSTATE" , "DSTATE" , "DSTATE" , "DSTATE" , "DSTATE" , "DSTATE" ,
"DSTATE" } ; static const char_T * rt_LoggedStateBlockNames [ ] = {
"cstr_simulationEnv/CSTR_1\nSimulation Model + Regulatory Control/m file" ,
"cstr_simulationEnv/CSTR_1\nSimulation Model + Regulatory Control/Integrator"
,
 "cstr_simulationEnv/CSTR_1\nSimulation Model + Regulatory Control/PID Controller1/Integrator/Continuous/Integrator"
,
 "cstr_simulationEnv/CSTR_1\nSimulation Model + Regulatory Control/PID Controller1/Filter/Cont. Filter/Filter"
,
 "cstr_simulationEnv/CSTR_1\nSimulation Model + Regulatory Control/PID Controller/Integrator/Continuous/Integrator"
,
 "cstr_simulationEnv/CSTR_1\nSimulation Model + Regulatory Control/PID Controller/Filter/Cont. Filter/Filter"
, "cstr_simulationEnv/Unit Delay8" , "cstr_simulationEnv/Unit Delay1" ,
"cstr_simulationEnv/Unit Delay2" , "cstr_simulationEnv/Unit Delay6" ,
"cstr_simulationEnv/Unit Delay7" ,
"cstr_simulationEnv/CSTR_1\nSimulation Model + Regulatory Control/Unit Delay6"
,
"cstr_simulationEnv/CSTR_1\nSimulation Model + Regulatory Control/Unit Delay1"
,
"cstr_simulationEnv/CSTR_1\nSimulation Model + Regulatory Control/Unit Delay2"
,
"cstr_simulationEnv/CSTR_1\nSimulation Model + Regulatory Control/Difference/UD"
,
 "cstr_simulationEnv/CSTR_1\nSimulation Model + Regulatory Control/Difference1/UD"
, "cstr_simulationEnv/Unit Delay9" , "cstr_simulationEnv/Unit Delay10" ,
"cstr_simulationEnv/Unit Delay11" } ; static const char_T *
rt_LoggedStateNames [ ] = { "" , "" , "" , "" , "" , "" , "DSTATE" , "DSTATE"
, "DSTATE" , "DSTATE" , "DSTATE" , "DSTATE" , "DSTATE" , "DSTATE" , "DSTATE"
, "DSTATE" , "DSTATE" , "DSTATE" , "DSTATE" } ; static boolean_T
rt_LoggedStateCrossMdlRef [ ] = { 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 ,
0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 } ; static RTWLogDataTypeConvert
rt_RTWLogDataTypeConvert [ ] = { { 0 , SS_DOUBLE , SS_DOUBLE , 0 , 0 , 0 ,
1.0 , 0 , 0.0 } , { 0 , SS_DOUBLE , SS_DOUBLE , 0 , 0 , 0 , 1.0 , 0 , 0.0 } ,
{ 0 , SS_DOUBLE , SS_DOUBLE , 0 , 0 , 0 , 1.0 , 0 , 0.0 } , { 0 , SS_DOUBLE ,
SS_DOUBLE , 0 , 0 , 0 , 1.0 , 0 , 0.0 } , { 0 , SS_DOUBLE , SS_DOUBLE , 0 , 0
, 0 , 1.0 , 0 , 0.0 } , { 0 , SS_DOUBLE , SS_DOUBLE , 0 , 0 , 0 , 1.0 , 0 ,
0.0 } , { 0 , SS_DOUBLE , SS_DOUBLE , 0 , 0 , 0 , 1.0 , 0 , 0.0 } , { 0 ,
SS_DOUBLE , SS_DOUBLE , 0 , 0 , 0 , 1.0 , 0 , 0.0 } , { 0 , SS_DOUBLE ,
SS_DOUBLE , 0 , 0 , 0 , 1.0 , 0 , 0.0 } , { 0 , SS_DOUBLE , SS_DOUBLE , 0 , 0
, 0 , 1.0 , 0 , 0.0 } , { 0 , SS_DOUBLE , SS_DOUBLE , 0 , 0 , 0 , 1.0 , 0 ,
0.0 } , { 0 , SS_DOUBLE , SS_DOUBLE , 0 , 0 , 0 , 1.0 , 0 , 0.0 } , { 0 ,
SS_DOUBLE , SS_DOUBLE , 0 , 0 , 0 , 1.0 , 0 , 0.0 } , { 0 , SS_DOUBLE ,
SS_DOUBLE , 0 , 0 , 0 , 1.0 , 0 , 0.0 } , { 0 , SS_DOUBLE , SS_DOUBLE , 0 , 0
, 0 , 1.0 , 0 , 0.0 } , { 0 , SS_DOUBLE , SS_DOUBLE , 0 , 0 , 0 , 1.0 , 0 ,
0.0 } , { 0 , SS_BOOLEAN , SS_BOOLEAN , 0 , 0 , 0 , 1.0 , 0 , 0.0 } , { 0 ,
SS_BOOLEAN , SS_BOOLEAN , 0 , 0 , 0 , 1.0 , 0 , 0.0 } , { 0 , SS_BOOLEAN ,
SS_BOOLEAN , 0 , 0 , 0 , 1.0 , 0 , 0.0 } } ; static int_T
rt_LoggedStateIdxList [ ] = { 0 , 1 , 2 , 3 , 4 , 5 , 0 , 1 , 2 , 3 , 4 , 5 ,
6 , 7 , 8 , 9 , 118 , 119 , 120 } ; static RTWLogSignalInfo
rt_LoggedStateSignalInfo = { 19 , rt_LoggedStateWidths ,
rt_LoggedStateNumDimensions , rt_LoggedStateDimensions ,
rt_LoggedStateIsVarDims , ( NULL ) , ( NULL ) , rt_LoggedStateDataTypeIds ,
rt_LoggedStateComplexSignals , ( NULL ) , rt_LoggingStatePreprocessingFcnPtrs
, { rt_LoggedStateLabels } , ( NULL ) , ( NULL ) , ( NULL ) , {
rt_LoggedStateBlockNames } , { rt_LoggedStateNames } ,
rt_LoggedStateCrossMdlRef , rt_RTWLogDataTypeConvert , rt_LoggedStateIdxList
} ; static void * rt_LoggedStateSignalPtrs [ 19 ] ; rtliSetLogXSignalPtrs (
ssGetRTWLogInfo ( rtS ) , ( LogSignalPtrsType ) rt_LoggedStateSignalPtrs ) ;
rtliSetLogXSignalInfo ( ssGetRTWLogInfo ( rtS ) , & rt_LoggedStateSignalInfo
) ; rt_LoggedStateSignalPtrs [ 0 ] = ( void * ) & rtX . jedufocp2q [ 0 ] ;
rt_LoggedStateSignalPtrs [ 1 ] = ( void * ) & rtX . lnj4efc1py ;
rt_LoggedStateSignalPtrs [ 2 ] = ( void * ) & rtX . mt5ndntoey ;
rt_LoggedStateSignalPtrs [ 3 ] = ( void * ) & rtX . korolwetpt ;
rt_LoggedStateSignalPtrs [ 4 ] = ( void * ) & rtX . indcayvth4 ;
rt_LoggedStateSignalPtrs [ 5 ] = ( void * ) & rtX . nbjzeco0u3 ;
rt_LoggedStateSignalPtrs [ 6 ] = ( void * ) & rtDW . mz0zdu34tn ;
rt_LoggedStateSignalPtrs [ 7 ] = ( void * ) & rtDW . cronjwvq3j ;
rt_LoggedStateSignalPtrs [ 8 ] = ( void * ) & rtDW . dsnlclvjlf ;
rt_LoggedStateSignalPtrs [ 9 ] = ( void * ) & rtDW . nfi0353erc ;
rt_LoggedStateSignalPtrs [ 10 ] = ( void * ) & rtDW . g5guutg2r4 ;
rt_LoggedStateSignalPtrs [ 11 ] = ( void * ) & rtDW . iecjfocdpt ;
rt_LoggedStateSignalPtrs [ 12 ] = ( void * ) & rtDW . pdh0ayrbq2 ;
rt_LoggedStateSignalPtrs [ 13 ] = ( void * ) & rtDW . i2jledyuxk ;
rt_LoggedStateSignalPtrs [ 14 ] = ( void * ) & rtDW . mk4nogmrgx ;
rt_LoggedStateSignalPtrs [ 15 ] = ( void * ) & rtDW . hdgt0peaua ;
rt_LoggedStateSignalPtrs [ 16 ] = ( void * ) & rtDW . i3eqa0qza0 ;
rt_LoggedStateSignalPtrs [ 17 ] = ( void * ) & rtDW . agio50d4gu ;
rt_LoggedStateSignalPtrs [ 18 ] = ( void * ) & rtDW . g10sbzotef ; }
rtliSetLogT ( ssGetRTWLogInfo ( rtS ) , "tout" ) ; rtliSetLogX (
ssGetRTWLogInfo ( rtS ) , "" ) ; rtliSetLogXFinal ( ssGetRTWLogInfo ( rtS ) ,
"xFinal" ) ; rtliSetLogVarNameModifier ( ssGetRTWLogInfo ( rtS ) , "none" ) ;
rtliSetLogFormat ( ssGetRTWLogInfo ( rtS ) , 4 ) ; rtliSetLogMaxRows (
ssGetRTWLogInfo ( rtS ) , 0 ) ; rtliSetLogDecimation ( ssGetRTWLogInfo ( rtS
) , 1 ) ; rtliSetLogY ( ssGetRTWLogInfo ( rtS ) , "" ) ;
rtliSetLogYSignalInfo ( ssGetRTWLogInfo ( rtS ) , ( NULL ) ) ;
rtliSetLogYSignalPtrs ( ssGetRTWLogInfo ( rtS ) , ( NULL ) ) ; } { static
struct _ssStatesInfo2 statesInfo2 ; ssSetStatesInfo2 ( rtS , & statesInfo2 )
; } { static ssPeriodicStatesInfo periodicStatesInfo ;
ssSetPeriodicStatesInfo ( rtS , & periodicStatesInfo ) ; } { static
ssJacobianPerturbationBounds jacobianPerturbationBounds ;
ssSetJacobianPerturbationBounds ( rtS , & jacobianPerturbationBounds ) ; } {
static ssSolverInfo slvrInfo ; static boolean_T contStatesDisabled [ 11 ] ;
static ssNonContDerivSigInfo nonContDerivSigInfo [ 19 ] = { { 1 * sizeof (
real_T ) , ( char * ) ( & rtB . fscu2cadee ) , ( NULL ) } , { 1 * sizeof (
real_T ) , ( char * ) ( & rtB . dv5gz4icu0 ) , ( NULL ) } , { 1 * sizeof (
real_T ) , ( char * ) ( & rtB . eo3aq2xcix ) , ( NULL ) } , { 1 * sizeof (
real_T ) , ( char * ) ( & rtB . ex4xrkfleq ) , ( NULL ) } , { 1 * sizeof (
real_T ) , ( char * ) ( & rtB . n1f2ld0elb ) , ( NULL ) } , { 1 * sizeof (
real_T ) , ( char * ) ( & rtB . kzqd3pbqkr ) , ( NULL ) } , { 1 * sizeof (
real_T ) , ( char * ) ( & rtB . lgnqauvekd ) , ( NULL ) } , { 1 * sizeof (
real_T ) , ( char * ) ( & rtB . gs2acg4a1b ) , ( NULL ) } , { 1 * sizeof (
real_T ) , ( char * ) ( & rtB . ipwdgvuaap ) , ( NULL ) } , { 1 * sizeof (
real_T ) , ( char * ) ( & rtB . b4ykqqwob2 ) , ( NULL ) } , { 1 * sizeof (
real_T ) , ( char * ) ( & rtB . dsy5xuerr4 ) , ( NULL ) } , { 1 * sizeof (
real_T ) , ( char * ) ( & rtB . pzmuj11ybr ) , ( NULL ) } , { 1 * sizeof (
real_T ) , ( char * ) ( & rtB . jantdzvoeu ) , ( NULL ) } , { 1 * sizeof (
real_T ) , ( char * ) ( & rtB . lps2tdsik3 ) , ( NULL ) } , { 1 * sizeof (
real_T ) , ( char * ) ( & rtB . mciogha2ud ) , ( NULL ) } , { 1 * sizeof (
real_T ) , ( char * ) ( & rtB . efsjkrykwf ) , ( NULL ) } , { 1 * sizeof (
real_T ) , ( char * ) ( & rtB . pwkazhfzxj ) , ( NULL ) } , { 1 * sizeof (
real_T ) , ( char * ) ( & rtB . ai311bapfw ) , ( NULL ) } , { 1 * sizeof (
real_T ) , ( char * ) ( & rtB . gvytu245ky ) , ( NULL ) } } ;
ssSetNumNonContDerivSigInfos ( rtS , 19 ) ; ssSetNonContDerivSigInfos ( rtS ,
nonContDerivSigInfo ) ; ssSetSolverInfo ( rtS , & slvrInfo ) ;
ssSetSolverName ( rtS , "ode3" ) ; ssSetVariableStepSolver ( rtS , 0 ) ;
ssSetSolverConsistencyChecking ( rtS , 0 ) ; ssSetSolverAdaptiveZcDetection (
rtS , 0 ) ; ssSetSolverRobustResetMethod ( rtS , 0 ) ;
ssSetSolverStateProjection ( rtS , 0 ) ; ssSetSolverMassMatrixType ( rtS , (
ssMatrixType ) 0 ) ; ssSetSolverMassMatrixNzMax ( rtS , 0 ) ;
ssSetModelOutputs ( rtS , MdlOutputs ) ; ssSetModelUpdate ( rtS , MdlUpdate )
; ssSetModelDerivatives ( rtS , MdlDerivatives ) ; ssSetTNextTid ( rtS ,
INT_MIN ) ; ssSetTNext ( rtS , rtMinusInf ) ; ssSetSolverNeedsReset ( rtS ) ;
ssSetNumNonsampledZCs ( rtS , 0 ) ; ssSetContStateDisabled ( rtS ,
contStatesDisabled ) ; } ssSetChecksumVal ( rtS , 0 , 4260740495U ) ;
ssSetChecksumVal ( rtS , 1 , 4141272003U ) ; ssSetChecksumVal ( rtS , 2 ,
4182188841U ) ; ssSetChecksumVal ( rtS , 3 , 2629175771U ) ; { static const
sysRanDType rtAlwaysEnabled = SUBSYS_RAN_BC_ENABLE ; static RTWExtModeInfo
rt_ExtModeInfo ; static const sysRanDType * systemRan [ 12 ] ;
gblRTWExtModeInfo = & rt_ExtModeInfo ; ssSetRTWExtModeInfo ( rtS , &
rt_ExtModeInfo ) ; rteiSetSubSystemActiveVectorAddresses ( & rt_ExtModeInfo ,
systemRan ) ; systemRan [ 0 ] = & rtAlwaysEnabled ; systemRan [ 1 ] = &
rtAlwaysEnabled ; systemRan [ 2 ] = & rtAlwaysEnabled ; systemRan [ 3 ] = &
rtAlwaysEnabled ; systemRan [ 4 ] = & rtAlwaysEnabled ; systemRan [ 5 ] = &
rtAlwaysEnabled ; systemRan [ 6 ] = & rtAlwaysEnabled ; systemRan [ 7 ] = (
sysRanDType * ) & rtDW . e5i1gkys053 . iaiukld4k4 ; systemRan [ 8 ] = (
sysRanDType * ) & rtDW . o0l0tlmums2 . nmoh1fygpu ; systemRan [ 9 ] = (
sysRanDType * ) & rtDW . lsul0j3thv5 . b0jtmkqrl5 ; systemRan [ 10 ] = (
sysRanDType * ) & rtDW . lvdmxslirzu . ec3xwiqauu ; systemRan [ 11 ] = &
rtAlwaysEnabled ; rteiSetModelMappingInfoPtr ( ssGetRTWExtModeInfo ( rtS ) ,
& ssGetModelMappingInfo ( rtS ) ) ; rteiSetChecksumsPtr ( ssGetRTWExtModeInfo
( rtS ) , ssGetChecksums ( rtS ) ) ; rteiSetTPtr ( ssGetRTWExtModeInfo ( rtS
) , ssGetTPtr ( rtS ) ) ; } slsaDisallowedBlocksForSimTargetOP ( rtS ,
mr_cstr_simulationEnv_GetSimStateDisallowedBlocks ) ;
slsaGetWorkFcnForSimTargetOP ( rtS , mr_cstr_simulationEnv_GetDWork ) ;
slsaSetWorkFcnForSimTargetOP ( rtS , mr_cstr_simulationEnv_SetDWork ) ;
rt_RapidReadMatFileAndUpdateParams ( rtS ) ; if ( ssGetErrorStatus ( rtS ) )
{ return rtS ; } ssSetNumSFunctions ( rtS , 1 ) ; { static SimStruct
childSFunctions [ 1 ] ; static SimStruct * childSFunctionPtrs [ 1 ] ; ( void
) memset ( ( void * ) & childSFunctions [ 0 ] , 0 , sizeof ( childSFunctions
) ) ; ssSetSFunctions ( rtS , & childSFunctionPtrs [ 0 ] ) ; ssSetSFunction (
rtS , 0 , & childSFunctions [ 0 ] ) ; { SimStruct * rts = ssGetSFunction (
rtS , 0 ) ; static time_T sfcnPeriod [ 1 ] ; static time_T sfcnOffset [ 1 ] ;
static int_T sfcnTsMap [ 1 ] ; ( void ) memset ( ( void * ) sfcnPeriod , 0 ,
sizeof ( time_T ) * 1 ) ; ( void ) memset ( ( void * ) sfcnOffset , 0 ,
sizeof ( time_T ) * 1 ) ; ssSetSampleTimePtr ( rts , & sfcnPeriod [ 0 ] ) ;
ssSetOffsetTimePtr ( rts , & sfcnOffset [ 0 ] ) ; ssSetSampleTimeTaskIDPtr (
rts , sfcnTsMap ) ; { static struct _ssBlkInfo2 _blkInfo2 ; struct
_ssBlkInfo2 * blkInfo2 = & _blkInfo2 ; ssSetBlkInfo2Ptr ( rts , blkInfo2 ) ;
} { static struct _ssPortInfo2 _portInfo2 ; struct _ssPortInfo2 * portInfo2 =
& _portInfo2 ; _ssSetBlkInfo2PortInfo2Ptr ( rts , portInfo2 ) ; }
ssSetMdlInfoPtr ( rts , ssGetMdlInfoPtr ( rtS ) ) ; { static struct
_ssSFcnModelMethods2 methods2 ; ssSetModelMethods2 ( rts , & methods2 ) ; } {
static struct _ssSFcnModelMethods3 methods3 ; ssSetModelMethods3 ( rts , &
methods3 ) ; } { static struct _ssSFcnModelMethods4 methods4 ;
ssSetModelMethods4 ( rts , & methods4 ) ; } { static struct _ssStatesInfo2
statesInfo2 ; static ssPeriodicStatesInfo periodicStatesInfo ; static
ssJacobianPerturbationBounds jacPerturbationBounds ; ssSetStatesInfo2 ( rts ,
& statesInfo2 ) ; ssSetPeriodicStatesInfo ( rts , & periodicStatesInfo ) ;
ssSetJacobianPerturbationBounds ( rts , & jacPerturbationBounds ) ; } {
_ssSetNumInputPorts ( rts , 1 ) ; static struct _ssPortInputs inputPortInfo [
1 ] ; ssSetPortInfoForInputs ( rts , & inputPortInfo [ 0 ] ) ; { static
struct _ssInPortUnit inputPortUnits [ 1 ] ; _ssSetPortInfo2ForInputUnits (
rts , & inputPortUnits [ 0 ] ) ; } ssSetInputPortUnit ( rts , 0 , 0 ) ; {
static struct _ssInPortCoSimAttribute inputPortCoSimAttribute [ 1 ] ;
_ssSetPortInfo2ForInputCoSimAttribute ( rts , & inputPortCoSimAttribute [ 0 ]
) ; } ssSetInputPortIsContinuousQuantity ( rts , 0 , 0 ) ; { static real_T
const * sfcnUPtrs [ 20 ] ; { int_T i1 ; const real_T * u0 = rtB . kwz4uvuft3
; for ( i1 = 0 ; i1 < 20 ; i1 ++ ) { sfcnUPtrs [ i1 ] = & u0 [ i1 ] ; } }
ssSetInputPortSignalPtrs ( rts , 0 , ( InputPtrsType ) & sfcnUPtrs [ 0 ] ) ;
_ssSetInputPortNumDimensions ( rts , 0 , 1 ) ; ssSetInputPortWidthAsInt ( rts
, 0 , 20 ) ; } } { static struct _ssPortOutputs outputPortInfo [ 1 ] ;
ssSetPortInfoForOutputs ( rts , & outputPortInfo [ 0 ] ) ;
_ssSetNumOutputPorts ( rts , 1 ) ; { static struct _ssOutPortUnit
outputPortUnits [ 1 ] ; _ssSetPortInfo2ForOutputUnits ( rts , &
outputPortUnits [ 0 ] ) ; } ssSetOutputPortUnit ( rts , 0 , 0 ) ; { static
struct _ssOutPortCoSimAttribute outputPortCoSimAttribute [ 1 ] ;
_ssSetPortInfo2ForOutputCoSimAttribute ( rts , & outputPortCoSimAttribute [ 0
] ) ; } ssSetOutputPortIsContinuousQuantity ( rts , 0 , 0 ) ; {
_ssSetOutputPortNumDimensions ( rts , 0 , 1 ) ; ssSetOutputPortWidthAsInt (
rts , 0 , 9 ) ; ssSetOutputPortSignal ( rts , 0 , ( ( real_T * ) rtB .
e0gpvxxppp ) ) ; } } ssSetContStates ( rts , & rtX . jedufocp2q [ 0 ] ) ;
ssSetModelName ( rts , "m file" ) ; ssSetPath ( rts ,
"cstr_simulationEnv/CSTR_1 Simulation Model + Regulatory Control/m file" ) ;
if ( ssGetRTModel ( rtS ) == ( NULL ) ) { ssSetParentSS ( rts , rtS ) ;
ssSetRootSS ( rts , ssGetRootSS ( rtS ) ) ; } else { ssSetRTModel ( rts ,
ssGetRTModel ( rtS ) ) ; ssSetParentSS ( rts , ( NULL ) ) ; ssSetRootSS ( rts
, rts ) ; } ssSetVersion ( rts , SIMSTRUCT_VERSION_LEVEL2 ) ; { static
mxArray * sfcnParams [ 2 ] ; ssSetSFcnParamsCount ( rts , 2 ) ;
ssSetSFcnParamsPtr ( rts , & sfcnParams [ 0 ] ) ; ssSetSFcnParam ( rts , 0 ,
( mxArray * ) rtP . mfile_P1_Size ) ; ssSetSFcnParam ( rts , 1 , ( mxArray *
) rtP . mfile_P2_Size ) ; } cstrm ( rts ) ; sfcnInitializeSizes ( rts ) ;
sfcnInitializeSampleTimes ( rts ) ; ssSetSampleTime ( rts , 0 , 0.0 ) ;
ssSetOffsetTime ( rts , 0 , 0.0 ) ; sfcnTsMap [ 0 ] = 0 ;
ssSetNumNonsampledZCsAsInt ( rts , 0 ) ; _ssSetInputPortConnected ( rts , 0 ,
1 ) ; _ssSetOutputPortConnected ( rts , 0 , 1 ) ; _ssSetOutputPortBeingMerged
( rts , 0 , 0 ) ; ssSetInputPortBufferDstPort ( rts , 0 , - 1 ) ; } } return
rtS ; }
#if defined(_MSC_VER)
#pragma optimize( "", on )
#endif
const int_T gblParameterTuningTid = 4 ; void MdlOutputsParameterSampleTime (
int_T tid ) { MdlOutputsTID4 ( tid ) ; }
