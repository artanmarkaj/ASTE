#ifndef RTW_HEADER_cstr_simulationEnv_h_
#define RTW_HEADER_cstr_simulationEnv_h_
#ifndef cstr_simulationEnv_COMMON_INCLUDES_
#define cstr_simulationEnv_COMMON_INCLUDES_
#include <stdlib.h>
#include <stddef.h>
#include <time.h>
#include "sl_AsyncioQueue/AsyncioQueueCAPI.h"
#include "sl_fileio_rtw.h"
#include "simtarget/slSimTgtSlFileioRTW.h"
#include "rtwtypes.h"
#include "sigstream_rtw.h"
#include "simtarget/slSimTgtSigstreamRTW.h"
#include "simtarget/slSimTgtSlioCoreRTW.h"
#include "simtarget/slSimTgtSlioClientsRTW.h"
#include "simtarget/slSimTgtSlioSdiRTW.h"
#include "simstruc.h"
#include "fixedpoint.h"
#include "raccel.h"
#include "slsv_diagnostic_codegen_c_api.h"
#include "rt_logging_simtarget.h"
#include "dt_info.h"
#include "ext_work.h"
#endif
#include "cstr_simulationEnv_types.h"
#include "mwmathutil.h"
#include "rtGetNaN.h"
#include "rt_nonfinite.h"
#include <string.h>
#include "rtw_modelmap_simtarget.h"
#include "rtGetInf.h"
#include "rt_defines.h"
#define MODEL_NAME cstr_simulationEnv
#define NSAMPLE_TIMES (5) 
#define NINPUTS (0)       
#define NOUTPUTS (0)     
#define NBLOCKIO (74) 
#define NUM_ZC_EVENTS (0) 
#ifndef NCSTATES
#define NCSTATES (11)   
#elif NCSTATES != 11
#error Invalid specification of NCSTATES defined in compiler command
#endif
#ifndef rtmGetDataMapInfo
#define rtmGetDataMapInfo(rtm) (*rt_dataMapInfoPtr)
#endif
#ifndef rtmSetDataMapInfo
#define rtmSetDataMapInfo(rtm, val) (rt_dataMapInfoPtr = &val)
#endif
#ifndef IN_RACCEL_MAIN
#endif
typedef struct { real_T ppbrf42mvn ; } mwig44svkj ; typedef struct { int8_T
ec3xwiqauu ; } jumuk3fap1 ; typedef struct { real_T nzhrh1tkt0 ; } l0lgrgqbys
; typedef struct { int8_T b0jtmkqrl5 ; } o2f542nfiy ; typedef struct { real_T
ebzcxl42h5 ; } dunstow1lc ; typedef struct { int8_T nmoh1fygpu ; } arhl1fqxuk
; typedef struct { real_T nyju2jnyn3 ; } eoztiauie0 ; typedef struct { int8_T
iaiukld4k4 ; } hzamdoniux ; typedef struct { real_T bano4r405l ; real_T
pwkazhfzxj ; real_T dztq1uxeww ; real_T imj24wyej4 ; real_T bd3otgosaa ;
real_T mcsqmnaiu3 ; real_T cx2r4dbgvi ; real_T fnykzau3dd ; real_T bzuganxdf2
; real_T mdshgnp3xt ; real_T c1djdqayjj ; real_T h1nl0bfw4n ; real_T
oqv2owxgui ; real_T lrowya24l3 ; real_T efsjkrykwf ; real_T mciogha2ud ;
real_T i2sxt22wo1 ; real_T mpecnpblvq ; real_T lps2tdsik3 ; real_T jantdzvoeu
; real_T pzmuj11ybr ; real_T atjpekwwur ; real_T dsy5xuerr4 ; real_T
b4ykqqwob2 ; real_T ipwdgvuaap ; real_T gs2acg4a1b ; real_T lgnqauvekd ;
real_T kzqd3pbqkr ; real_T n1f2ld0elb ; real_T ex4xrkfleq ; real_T eo3aq2xcix
; real_T dv5gz4icu0 ; real_T fscu2cadee ; real_T kwz4uvuft3 [ 20 ] ; real_T
e0gpvxxppp [ 9 ] ; real_T ib3grttpul ; real_T k3jie4wym5 ; real_T czzkhzteyg
; real_T iu3dgzsmox ; real_T bbrn1ou5mh ; real_T jkvshhuv25 ; real_T
ifp2xzx5cj ; real_T jxqv3hrimg ; real_T ggli2ppxyv ; real_T owumd2pxxx ;
real_T bmollnwf0s ; real_T d5u0rvgiee ; real_T k3xz1ht2ij ; real_T iorisswymh
; real_T l4lnonwfg2 ; real_T gvytu245ky ; real_T ai311bapfw ; real_T
htmpoa25zx ; real_T nehncd51lh ; real_T ftctw2pua5 ; real_T c110xhgmn1 ;
boolean_T gnzysggnk4 ; boolean_T hdnlmp40uy ; boolean_T euqxsw55q1 ;
boolean_T nr5jzefs11 ; boolean_T g4otcjhaps ; boolean_T c50enbqbhd ;
boolean_T koa2xwzkqz ; boolean_T llcmsauyav ; boolean_T govtsadkmh ;
boolean_T gfgfscs3wh ; boolean_T hwlkc3gph4 ; boolean_T ipy2o045sf ;
boolean_T ggozffptrp ; boolean_T ln01g2x54f ; eoztiauie0 e5i1gkys053 ;
dunstow1lc o0l0tlmums2 ; l0lgrgqbys lsul0j3thv5 ; mwig44svkj lvdmxslirzu ; }
B ; typedef struct { real_T mz0zdu34tn ; real_T cronjwvq3j ; real_T
dsnlclvjlf ; real_T nfi0353erc ; real_T g5guutg2r4 ; real_T iecjfocdpt ;
real_T pdh0ayrbq2 ; real_T i2jledyuxk ; real_T mk4nogmrgx ; real_T hdgt0peaua
; real_T bv534fxrfq ; real_T fudylxbq0j ; real_T bgotvck1y4 ; real_T
dfulppyfs1 ; real_T o0jhm5tqhv ; real_T gymfbya0lf ; real_T mq4tzms12g ;
real_T jk5yslpya4 ; real_T o0mql2hqjx ; real_T o2pzpkkeul ; real_T njvyqws1h5
; real_T hblnhilp5j ; struct { void * AQHandles ; } odihpq11te ; struct {
void * AQHandles ; } jsnyah43h5 ; struct { void * AQHandles ; } ggzqve4ryn ;
struct { void * AQHandles ; } ismfv5vasc ; struct { void * AQHandles ; }
ns05uf10ld ; struct { void * AQHandles ; } nkxcwijbwx ; struct { void *
AQHandles ; } msb5d3me1j ; struct { void * AQHandles ; } lbtghvt0ml ; struct
{ void * AQHandles ; } mvgtzq34qx ; struct { void * AQHandles ; } aosifnfz0v
; struct { void * AQHandles ; } lpahj2azln ; struct { void * AQHandles ; }
pyvmjo2bqw ; struct { void * AQHandles ; } mcwiq2fdf3 ; struct { void *
AQHandles ; } jarmeshqgo ; struct { void * AQHandles ; } ltulzml5oa ; struct
{ void * AQHandles ; } lvl5uvsvj2 ; struct { void * AQHandles ; } inyhtmatu2
; struct { void * AQHandles ; } ah0o3rwxbv ; struct { void * AQHandles ; }
flebub5s5m ; struct { void * TimePtr ; void * DataPtr ; void * RSimInfoPtr ;
} e0u1digqih ; struct { void * TimePtr ; void * DataPtr ; void * RSimInfoPtr
; } ddqlrilmhr ; struct { void * LoggedData ; } liiyr4gl0x ; struct { void *
LoggedData ; } e3pcjst2gf ; struct { void * LoggedData ; } dfkwoy32wq ;
struct { void * LoggedData ; } i4p5qsx20a ; struct { void * LoggedData ; }
lqpw014zwg ; struct { void * LoggedData ; } psg34ddjdk ; struct { void *
LoggedData ; } onuyjr2ufc ; struct { void * LoggedData ; } epgqqqavhn ;
struct { void * AQHandles ; } j3e0f44doy ; struct { void * AQHandles ; }
oot0srnoki ; struct { void * AQHandles ; } bjz5tw4p5j ; struct { void *
AQHandles ; } mljkjloakr ; struct { void * AQHandles ; } l4vlioxbgl ; struct
{ void * AQHandles ; } kkblxpcw3m ; struct { void * AQHandles ; } h3jcwnop0g
; struct { void * AQHandles ; } mjxkrhmtfj ; struct { void * AQHandles ; }
beunqpbxj1 ; struct { void * AQHandles ; } jvhbaaoh3e ; struct { void *
AQHandles ; } ctwshmhpdz ; struct { void * AQHandles ; } licnk0hmrn ; struct
{ void * AQHandles ; } jvdos0csvi ; struct { void * AQHandles ; } pn3nw2wp03
; struct { void * AQHandles ; } lclc5oxd1y ; struct { void * AQHandles ; }
k2lm4rcfbi ; struct { void * AQHandles ; } hcvlm25apo ; struct { void *
AQHandles ; } ku5epe2lev ; struct { void * AQHandles ; } eksra31szv ; struct
{ void * AQHandles ; } ahr1p51zrw ; struct { void * AQHandles ; } fwpf1vdbdo
; struct { void * AQHandles ; } ciu3qjsht5 ; struct { void * AQHandles ; }
m2i42ofdw4 ; struct { void * AQHandles ; } frknafxvto ; struct { void *
AQHandles ; } blapbcem3w ; struct { void * AQHandles ; } ekmy53hjdg ; struct
{ void * LoggedData ; } go2ndgnsmr ; struct { void * FilePtr ; } aw4of2bzto ;
struct { void * AQHandles ; } j2ehmt2zxo ; struct { void * AQHandles ; }
cue41xrxnu ; struct { void * AQHandles ; } pubxocmqc2 ; struct { void *
AQHandles ; } f0ugwgjvhr ; struct { void * AQHandles ; } g53jytoip4 ; struct
{ void * AQHandles ; } obf4siedf4 ; struct { void * AQHandles ; } o5jtmaqc3t
; int32_T dx0psck2g2 ; int32_T bv5o5ntfep ; uint32_T bmwah53if2 ; uint32_T
lustmxh0ru ; uint32_T o5vdryefj2 ; uint32_T kasvnwnwfd ; uint32_T d2hdmgi2df
; uint32_T eesjxfyvk2 ; uint32_T cdqamvzgi2 ; uint32_T a2u1lqkyoh ; uint32_T
mpm2qm4ahz ; uint32_T arjuzvir0v ; uint32_T a3naafic3w ; uint32_T g0pte1h22i
; uint32_T ksqmuzqxoq ; uint32_T cnphnmyixz ; uint32_T lyrzf3l331 ; uint32_T
o5lpscgpim ; uint32_T i33gdokzps ; uint32_T puvxpdyspy ; uint32_T hvipzkfxby
; uint32_T b2oh0gakei ; uint32_T j4xo2d0p0j ; uint32_T en0wsgm2d2 ; uint32_T
htl3ck05k3 [ 625 ] ; uint32_T kf3zpzee4j [ 2 ] ; uint32_T m5g4cvi2wi ;
uint32_T ifylc1ayya ; struct { int_T PrevIndex ; } f4gzzk1cad ; struct {
int_T PrevIndex ; } gizzljrotf ; struct { int_T Count ; int_T Decimation ; }
bttm2sqgp0 ; uint16_T csce1vtaiv ; boolean_T i3eqa0qza0 ; boolean_T
agio50d4gu ; boolean_T g10sbzotef ; uint8_T jraid5zlrs ; uint8_T hjgrew42b2 ;
uint8_T ntbs21hax4 ; uint8_T eyqkltgelg ; uint8_T il0ohwuds5 ; uint8_T
cuxelkmbzn ; boolean_T b0xpqic30u ; boolean_T iu2ulpoww0 ; boolean_T
l4htxomgyb ; boolean_T hhdj03gcse ; boolean_T e54eqryqod ; boolean_T
ek03o5d0zn ; boolean_T ouoju14cbw ; boolean_T k20nitrd4l ; hzamdoniux
e5i1gkys053 ; arhl1fqxuk o0l0tlmums2 ; o2f542nfiy lsul0j3thv5 ; jumuk3fap1
lvdmxslirzu ; } DW ; typedef struct { real_T jedufocp2q [ 6 ] ; real_T
lnj4efc1py ; real_T mt5ndntoey ; real_T korolwetpt ; real_T indcayvth4 ;
real_T nbjzeco0u3 ; } X ; typedef struct { real_T jedufocp2q [ 6 ] ; real_T
lnj4efc1py ; real_T mt5ndntoey ; real_T korolwetpt ; real_T indcayvth4 ;
real_T nbjzeco0u3 ; } XDot ; typedef struct { boolean_T jedufocp2q [ 6 ] ;
boolean_T lnj4efc1py ; boolean_T mt5ndntoey ; boolean_T korolwetpt ;
boolean_T indcayvth4 ; boolean_T nbjzeco0u3 ; } XDis ; typedef struct {
rtwCAPI_ModelMappingInfo mmi ; } DataMapInfo ; struct ew3azour0i_ { real_T
Out1_Y0 ; real_T Saturation_UpperSat ; real_T Saturation_LowerSat ; real_T
Constant_Value ; } ; struct gecy0xyg43_ { real_T Out1_Y0 ; real_T
Saturation_UpperSat ; real_T Saturation_LowerSat ; real_T Constant_Value ; }
; struct n2j2mlro55_ { real_T Out1_Y0 ; real_T Saturation_UpperSat ; real_T
Saturation_LowerSat ; real_T Constant_Value ; } ; struct krn1dj51s1_ { real_T
Out1_Y0 ; real_T Saturation_UpperSat ; real_T Saturation_LowerSat ; real_T
Constant_Value ; } ; struct P_ { real_T mfile_P2_Size [ 2 ] ; real_T Xinitial
[ 6 ] ; real_T PIDController1_D ; real_T PIDController_D ; real_T
PIDController_I ; real_T PIDController1_I ; real_T Difference_ICPrevInput ;
real_T Difference1_ICPrevInput ; real_T
PIDController1_InitialConditionForFilter ; real_T
PIDController_InitialConditionForFilter ; real_T
PIDController1_InitialConditionForIntegrator ; real_T
PIDController_InitialConditionForIntegrator ; real_T Ramp_InitialOutput ;
real_T PIDController1_N ; real_T PIDController_N ; real_T PIDController1_P ;
real_T PIDController_P ; real_T Ramp_slope ; real_T Ramp_start ; real_T
Step_Y0 ; real_T UniformRandomNumber2_Minimum ; real_T
UniformRandomNumber2_Maximum ; real_T UniformRandomNumber2_Seed ; real_T
Memory_InitialCondition ; real_T Switch4_Threshold ; real_T Switch5_Threshold
; real_T Saturation_UpperSat ; real_T Saturation_LowerSat ; real_T
UniformRandomNumber10_Minimum ; real_T UniformRandomNumber10_Maximum ; real_T
UniformRandomNumber10_Seed ; real_T Memory10_InitialCondition ; real_T
Switch22_Threshold ; real_T Switch23_Threshold ; real_T
UniformRandomNumber6_Minimum ; real_T UniformRandomNumber6_Maximum ; real_T
UniformRandomNumber6_Seed ; real_T Memory6_InitialCondition ; real_T
Switch13_Threshold ; real_T Switch14_Threshold ; real_T
UnitDelay8_InitialCondition ; real_T UnitDelay1_InitialCondition ; real_T
UnitDelay2_InitialCondition ; real_T UnitDelay6_InitialCondition ; real_T
UnitDelay7_InitialCondition ; real_T Relay2_OnVal ; real_T Relay2_OffVal ;
real_T Relay2_YOn ; real_T Relay2_YOff ; real_T Relay1_OnVal ; real_T
Relay1_OffVal ; real_T Relay1_YOn ; real_T Relay1_YOff ; real_T Relay_OnVal ;
real_T Relay_OffVal ; real_T Relay_YOn ; real_T Relay_YOff ; real_T
Switch10_Threshold ; real_T FromWorkspace_Time0 [ 5001 ] ; real_T
FromWorkspace_Data0 [ 5001 ] ; real_T Gain1_Gain ; real_T
UnitDelay6_InitialCondition_m0rhsscivj ; real_T UniformRandomNumber5_Minimum
; real_T UniformRandomNumber5_Maximum ; real_T UniformRandomNumber5_Seed ;
real_T UnitDelay1_InitialCondition_fked3caosb ; real_T FromWorkspace1_Time0 [
5001 ] ; real_T FromWorkspace1_Data0 [ 5001 ] ; real_T Gain2_Gain ; real_T
Switch1_Threshold ; real_T Switch6_Threshold ; real_T
Switch4_Threshold_oqqlidhi4v ; real_T UniformRandomNumber_Minimum ; real_T
UniformRandomNumber_Maximum ; real_T UniformRandomNumber_Seed ; real_T
UniformRandomNumber1_Minimum ; real_T UniformRandomNumber1_Maximum ; real_T
UniformRandomNumber1_Seed ; real_T UniformRandomNumber2_Minimum_fx5mnbvdh4 ;
real_T UniformRandomNumber2_Maximum_h0hkt0qhvs ; real_T
UniformRandomNumber2_Seed_l3l21jyov0 ; real_T UniformRandomNumber3_Minimum ;
real_T UniformRandomNumber3_Maximum ; real_T UniformRandomNumber3_Seed ;
real_T UniformRandomNumber4_Minimum ; real_T UniformRandomNumber4_Maximum ;
real_T UniformRandomNumber4_Seed ; real_T
UnitDelay2_InitialCondition_cz3sr01ooy ; real_T mfile_P1_Size [ 2 ] ; real_T
mfile_P1 [ 10 ] ; real_T Integrator_IC ; real_T Gain_Gain ; real_T
Switch_Threshold ; real_T Feed_Temperature_In_Value ; real_T
Feed_Temperature_Out_Value ; real_T Inlet_Flow_In_Value ; real_T
Inlet_Flow_Out_Value ; real_T C_Bin_Value ; real_T C_Cin_Value ; real_T
Rate3_Value ; real_T Constant_Value ; real_T Constant1_Value ; real_T
Constant10_Value ; real_T Constant11_Value ; real_T Constant12_Value ; real_T
Constant13_Value ; real_T Constant14_Value ; real_T Constant15_Value ; real_T
Constant16_Value ; real_T Constant2_Value ; real_T Constant3_Value ; real_T
Constant4_Value ; real_T Constant5_Value ; real_T Constant6_Value ; real_T
Constant7_Value ; real_T Constant8_Value ; real_T Constant9_Value ; real_T
LevelSet_Value ; real_T PA_Value ; real_T PB_Value ; real_T PC_Value ; real_T
PCHANGE_Value ; real_T PD_Value ; real_T PHEAT_Value ; real_T T_outSet_Value
; real_T Constant_Value_lg13tpamfv ; real_T Constant11_Value_jvwwu02wty ;
real_T Constant12_Value_ce5osxgbbp ; real_T Constant13_Value_jemti03zwx ;
real_T Constant40_Value ; real_T Constant41_Value ; real_T Constant42_Value ;
real_T Constant43_Value ; real_T Constant44_Value ; real_T Constant29_Value ;
real_T Constant30_Value ; real_T Constant31_Value ; real_T Constant32_Value ;
real_T Constant33_Value ; boolean_T UnitDelay9_InitialCondition ; boolean_T
UnitDelay10_InitialCondition ; boolean_T UnitDelay11_InitialCondition ;
uint8_T ConsiderFault1_CurrentSetting ; uint8_T
ConsiderFault11_CurrentSetting ; uint8_T ConsiderFault7_CurrentSetting ;
krn1dj51s1 e5i1gkys053 ; n2j2mlro55 o0l0tlmums2 ; gecy0xyg43 lsul0j3thv5 ;
ew3azour0i lvdmxslirzu ; } ; extern const char * RT_MEMORY_ALLOCATION_ERROR ;
extern B rtB ; extern X rtX ; extern DW rtDW ; extern P rtP ; extern mxArray
* mr_cstr_simulationEnv_GetDWork ( ) ; extern void
mr_cstr_simulationEnv_SetDWork ( const mxArray * ssDW ) ; extern mxArray *
mr_cstr_simulationEnv_GetSimStateDisallowedBlocks ( ) ; extern const
rtwCAPI_ModelMappingStaticInfo * cstr_simulationEnv_GetCAPIStaticMap ( void )
; extern SimStruct * const rtS ; extern const int_T gblNumToFiles ; extern
const int_T gblNumFrFiles ; extern const int_T gblNumFrWksBlocks ; extern
rtInportTUtable * gblInportTUtables ; extern const char * gblInportFileName ;
extern const int_T gblNumRootInportBlks ; extern const int_T
gblNumModelInputs ; extern const int_T gblInportDataTypeIdx [ ] ; extern
const int_T gblInportDims [ ] ; extern const int_T gblInportComplex [ ] ;
extern const int_T gblInportInterpoFlag [ ] ; extern const int_T
gblInportContinuous [ ] ; extern const int_T gblParameterTuningTid ; extern
DataMapInfo * rt_dataMapInfoPtr ; extern rtwCAPI_ModelMappingInfo *
rt_modelMapInfoPtr ; void MdlOutputs ( int_T tid ) ; void
MdlOutputsParameterSampleTime ( int_T tid ) ; void MdlUpdate ( int_T tid ) ;
void MdlTerminate ( void ) ; void MdlInitializeSizes ( void ) ; void
MdlInitializeSampleTimes ( void ) ; SimStruct * raccel_register_model (
ssExecutionInfo * executionInfo ) ;
#endif
