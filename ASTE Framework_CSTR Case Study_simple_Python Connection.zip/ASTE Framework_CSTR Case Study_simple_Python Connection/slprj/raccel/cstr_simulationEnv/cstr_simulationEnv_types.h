#ifndef RTW_HEADER_cstr_simulationEnv_types_h_
#define RTW_HEADER_cstr_simulationEnv_types_h_
#include <time.h>
#include <time.h>
#ifndef SS_UINT64
#define SS_UINT64 17
#endif
#ifndef SS_INT64
#define SS_INT64 18
#endif
typedef struct ew3azour0i_ ew3azour0i ; typedef struct gecy0xyg43_ gecy0xyg43
; typedef struct n2j2mlro55_ n2j2mlro55 ; typedef struct krn1dj51s1_
krn1dj51s1 ; typedef struct P_ P ;
#endif
