    function targMap = targDataMap(),

    ;%***********************
    ;% Create Parameter Map *
    ;%***********************
    
        nTotData      = 0; %add to this count as we go
        nTotSects     = 7;
        sectIdxOffset = 0;

        ;%
        ;% Define dummy sections & preallocate arrays
        ;%
        dumSection.nData = -1;
        dumSection.data  = [];

        dumData.logicalSrcIdx = -1;
        dumData.dtTransOffset = -1;

        ;%
        ;% Init/prealloc paramMap
        ;%
        paramMap.nSections           = nTotSects;
        paramMap.sectIdxOffset       = sectIdxOffset;
            paramMap.sections(nTotSects) = dumSection; %prealloc
        paramMap.nTotData            = -1;

        ;%
        ;% Auto data (rtP)
        ;%
            section.nData     = 139;
            section.data(139)  = dumData; %prealloc

                    ;% rtP.mfile_P2_Size
                    section.data(1).logicalSrcIdx = 0;
                    section.data(1).dtTransOffset = 0;

                    ;% rtP.Xinitial
                    section.data(2).logicalSrcIdx = 1;
                    section.data(2).dtTransOffset = 2;

                    ;% rtP.PIDController1_D
                    section.data(3).logicalSrcIdx = 2;
                    section.data(3).dtTransOffset = 8;

                    ;% rtP.PIDController_D
                    section.data(4).logicalSrcIdx = 3;
                    section.data(4).dtTransOffset = 9;

                    ;% rtP.PIDController_I
                    section.data(5).logicalSrcIdx = 4;
                    section.data(5).dtTransOffset = 10;

                    ;% rtP.PIDController1_I
                    section.data(6).logicalSrcIdx = 5;
                    section.data(6).dtTransOffset = 11;

                    ;% rtP.Difference_ICPrevInput
                    section.data(7).logicalSrcIdx = 6;
                    section.data(7).dtTransOffset = 12;

                    ;% rtP.Difference1_ICPrevInput
                    section.data(8).logicalSrcIdx = 7;
                    section.data(8).dtTransOffset = 13;

                    ;% rtP.PIDController1_InitialConditionForFilter
                    section.data(9).logicalSrcIdx = 8;
                    section.data(9).dtTransOffset = 14;

                    ;% rtP.PIDController_InitialConditionForFilter
                    section.data(10).logicalSrcIdx = 9;
                    section.data(10).dtTransOffset = 15;

                    ;% rtP.PIDController1_InitialConditionForIntegrator
                    section.data(11).logicalSrcIdx = 10;
                    section.data(11).dtTransOffset = 16;

                    ;% rtP.PIDController_InitialConditionForIntegrator
                    section.data(12).logicalSrcIdx = 11;
                    section.data(12).dtTransOffset = 17;

                    ;% rtP.Ramp_InitialOutput
                    section.data(13).logicalSrcIdx = 12;
                    section.data(13).dtTransOffset = 18;

                    ;% rtP.PIDController1_N
                    section.data(14).logicalSrcIdx = 13;
                    section.data(14).dtTransOffset = 19;

                    ;% rtP.PIDController_N
                    section.data(15).logicalSrcIdx = 14;
                    section.data(15).dtTransOffset = 20;

                    ;% rtP.PIDController1_P
                    section.data(16).logicalSrcIdx = 15;
                    section.data(16).dtTransOffset = 21;

                    ;% rtP.PIDController_P
                    section.data(17).logicalSrcIdx = 16;
                    section.data(17).dtTransOffset = 22;

                    ;% rtP.Ramp_slope
                    section.data(18).logicalSrcIdx = 17;
                    section.data(18).dtTransOffset = 23;

                    ;% rtP.Ramp_start
                    section.data(19).logicalSrcIdx = 18;
                    section.data(19).dtTransOffset = 24;

                    ;% rtP.Step_Y0
                    section.data(20).logicalSrcIdx = 19;
                    section.data(20).dtTransOffset = 25;

                    ;% rtP.UniformRandomNumber2_Minimum
                    section.data(21).logicalSrcIdx = 20;
                    section.data(21).dtTransOffset = 26;

                    ;% rtP.UniformRandomNumber2_Maximum
                    section.data(22).logicalSrcIdx = 21;
                    section.data(22).dtTransOffset = 27;

                    ;% rtP.UniformRandomNumber2_Seed
                    section.data(23).logicalSrcIdx = 22;
                    section.data(23).dtTransOffset = 28;

                    ;% rtP.Memory_InitialCondition
                    section.data(24).logicalSrcIdx = 23;
                    section.data(24).dtTransOffset = 29;

                    ;% rtP.Switch4_Threshold
                    section.data(25).logicalSrcIdx = 24;
                    section.data(25).dtTransOffset = 30;

                    ;% rtP.Switch5_Threshold
                    section.data(26).logicalSrcIdx = 25;
                    section.data(26).dtTransOffset = 31;

                    ;% rtP.Saturation_UpperSat
                    section.data(27).logicalSrcIdx = 26;
                    section.data(27).dtTransOffset = 32;

                    ;% rtP.Saturation_LowerSat
                    section.data(28).logicalSrcIdx = 27;
                    section.data(28).dtTransOffset = 33;

                    ;% rtP.UniformRandomNumber10_Minimum
                    section.data(29).logicalSrcIdx = 28;
                    section.data(29).dtTransOffset = 34;

                    ;% rtP.UniformRandomNumber10_Maximum
                    section.data(30).logicalSrcIdx = 29;
                    section.data(30).dtTransOffset = 35;

                    ;% rtP.UniformRandomNumber10_Seed
                    section.data(31).logicalSrcIdx = 30;
                    section.data(31).dtTransOffset = 36;

                    ;% rtP.Memory10_InitialCondition
                    section.data(32).logicalSrcIdx = 31;
                    section.data(32).dtTransOffset = 37;

                    ;% rtP.Switch22_Threshold
                    section.data(33).logicalSrcIdx = 32;
                    section.data(33).dtTransOffset = 38;

                    ;% rtP.Switch23_Threshold
                    section.data(34).logicalSrcIdx = 33;
                    section.data(34).dtTransOffset = 39;

                    ;% rtP.UniformRandomNumber6_Minimum
                    section.data(35).logicalSrcIdx = 34;
                    section.data(35).dtTransOffset = 40;

                    ;% rtP.UniformRandomNumber6_Maximum
                    section.data(36).logicalSrcIdx = 35;
                    section.data(36).dtTransOffset = 41;

                    ;% rtP.UniformRandomNumber6_Seed
                    section.data(37).logicalSrcIdx = 36;
                    section.data(37).dtTransOffset = 42;

                    ;% rtP.Memory6_InitialCondition
                    section.data(38).logicalSrcIdx = 37;
                    section.data(38).dtTransOffset = 43;

                    ;% rtP.Switch13_Threshold
                    section.data(39).logicalSrcIdx = 38;
                    section.data(39).dtTransOffset = 44;

                    ;% rtP.Switch14_Threshold
                    section.data(40).logicalSrcIdx = 39;
                    section.data(40).dtTransOffset = 45;

                    ;% rtP.UnitDelay8_InitialCondition
                    section.data(41).logicalSrcIdx = 40;
                    section.data(41).dtTransOffset = 46;

                    ;% rtP.UnitDelay1_InitialCondition
                    section.data(42).logicalSrcIdx = 41;
                    section.data(42).dtTransOffset = 47;

                    ;% rtP.UnitDelay2_InitialCondition
                    section.data(43).logicalSrcIdx = 42;
                    section.data(43).dtTransOffset = 48;

                    ;% rtP.UnitDelay6_InitialCondition
                    section.data(44).logicalSrcIdx = 43;
                    section.data(44).dtTransOffset = 49;

                    ;% rtP.UnitDelay7_InitialCondition
                    section.data(45).logicalSrcIdx = 44;
                    section.data(45).dtTransOffset = 50;

                    ;% rtP.Relay2_OnVal
                    section.data(46).logicalSrcIdx = 45;
                    section.data(46).dtTransOffset = 51;

                    ;% rtP.Relay2_OffVal
                    section.data(47).logicalSrcIdx = 46;
                    section.data(47).dtTransOffset = 52;

                    ;% rtP.Relay2_YOn
                    section.data(48).logicalSrcIdx = 47;
                    section.data(48).dtTransOffset = 53;

                    ;% rtP.Relay2_YOff
                    section.data(49).logicalSrcIdx = 48;
                    section.data(49).dtTransOffset = 54;

                    ;% rtP.Relay1_OnVal
                    section.data(50).logicalSrcIdx = 49;
                    section.data(50).dtTransOffset = 55;

                    ;% rtP.Relay1_OffVal
                    section.data(51).logicalSrcIdx = 50;
                    section.data(51).dtTransOffset = 56;

                    ;% rtP.Relay1_YOn
                    section.data(52).logicalSrcIdx = 51;
                    section.data(52).dtTransOffset = 57;

                    ;% rtP.Relay1_YOff
                    section.data(53).logicalSrcIdx = 52;
                    section.data(53).dtTransOffset = 58;

                    ;% rtP.Relay_OnVal
                    section.data(54).logicalSrcIdx = 53;
                    section.data(54).dtTransOffset = 59;

                    ;% rtP.Relay_OffVal
                    section.data(55).logicalSrcIdx = 54;
                    section.data(55).dtTransOffset = 60;

                    ;% rtP.Relay_YOn
                    section.data(56).logicalSrcIdx = 55;
                    section.data(56).dtTransOffset = 61;

                    ;% rtP.Relay_YOff
                    section.data(57).logicalSrcIdx = 56;
                    section.data(57).dtTransOffset = 62;

                    ;% rtP.Switch10_Threshold
                    section.data(58).logicalSrcIdx = 57;
                    section.data(58).dtTransOffset = 63;

                    ;% rtP.FromWorkspace_Time0
                    section.data(59).logicalSrcIdx = 58;
                    section.data(59).dtTransOffset = 64;

                    ;% rtP.FromWorkspace_Data0
                    section.data(60).logicalSrcIdx = 59;
                    section.data(60).dtTransOffset = 5065;

                    ;% rtP.Gain1_Gain
                    section.data(61).logicalSrcIdx = 60;
                    section.data(61).dtTransOffset = 10066;

                    ;% rtP.UnitDelay6_InitialCondition_m0rhsscivj
                    section.data(62).logicalSrcIdx = 61;
                    section.data(62).dtTransOffset = 10067;

                    ;% rtP.UniformRandomNumber5_Minimum
                    section.data(63).logicalSrcIdx = 62;
                    section.data(63).dtTransOffset = 10068;

                    ;% rtP.UniformRandomNumber5_Maximum
                    section.data(64).logicalSrcIdx = 63;
                    section.data(64).dtTransOffset = 10069;

                    ;% rtP.UniformRandomNumber5_Seed
                    section.data(65).logicalSrcIdx = 64;
                    section.data(65).dtTransOffset = 10070;

                    ;% rtP.UnitDelay1_InitialCondition_fked3caosb
                    section.data(66).logicalSrcIdx = 65;
                    section.data(66).dtTransOffset = 10071;

                    ;% rtP.FromWorkspace1_Time0
                    section.data(67).logicalSrcIdx = 66;
                    section.data(67).dtTransOffset = 10072;

                    ;% rtP.FromWorkspace1_Data0
                    section.data(68).logicalSrcIdx = 67;
                    section.data(68).dtTransOffset = 15073;

                    ;% rtP.Gain2_Gain
                    section.data(69).logicalSrcIdx = 68;
                    section.data(69).dtTransOffset = 20074;

                    ;% rtP.Switch1_Threshold
                    section.data(70).logicalSrcIdx = 69;
                    section.data(70).dtTransOffset = 20075;

                    ;% rtP.Switch6_Threshold
                    section.data(71).logicalSrcIdx = 70;
                    section.data(71).dtTransOffset = 20076;

                    ;% rtP.Switch4_Threshold_oqqlidhi4v
                    section.data(72).logicalSrcIdx = 71;
                    section.data(72).dtTransOffset = 20077;

                    ;% rtP.UniformRandomNumber_Minimum
                    section.data(73).logicalSrcIdx = 72;
                    section.data(73).dtTransOffset = 20078;

                    ;% rtP.UniformRandomNumber_Maximum
                    section.data(74).logicalSrcIdx = 73;
                    section.data(74).dtTransOffset = 20079;

                    ;% rtP.UniformRandomNumber_Seed
                    section.data(75).logicalSrcIdx = 74;
                    section.data(75).dtTransOffset = 20080;

                    ;% rtP.UniformRandomNumber1_Minimum
                    section.data(76).logicalSrcIdx = 75;
                    section.data(76).dtTransOffset = 20081;

                    ;% rtP.UniformRandomNumber1_Maximum
                    section.data(77).logicalSrcIdx = 76;
                    section.data(77).dtTransOffset = 20082;

                    ;% rtP.UniformRandomNumber1_Seed
                    section.data(78).logicalSrcIdx = 77;
                    section.data(78).dtTransOffset = 20083;

                    ;% rtP.UniformRandomNumber2_Minimum_fx5mnbvdh4
                    section.data(79).logicalSrcIdx = 78;
                    section.data(79).dtTransOffset = 20084;

                    ;% rtP.UniformRandomNumber2_Maximum_h0hkt0qhvs
                    section.data(80).logicalSrcIdx = 79;
                    section.data(80).dtTransOffset = 20085;

                    ;% rtP.UniformRandomNumber2_Seed_l3l21jyov0
                    section.data(81).logicalSrcIdx = 80;
                    section.data(81).dtTransOffset = 20086;

                    ;% rtP.UniformRandomNumber3_Minimum
                    section.data(82).logicalSrcIdx = 81;
                    section.data(82).dtTransOffset = 20087;

                    ;% rtP.UniformRandomNumber3_Maximum
                    section.data(83).logicalSrcIdx = 82;
                    section.data(83).dtTransOffset = 20088;

                    ;% rtP.UniformRandomNumber3_Seed
                    section.data(84).logicalSrcIdx = 83;
                    section.data(84).dtTransOffset = 20089;

                    ;% rtP.UniformRandomNumber4_Minimum
                    section.data(85).logicalSrcIdx = 84;
                    section.data(85).dtTransOffset = 20090;

                    ;% rtP.UniformRandomNumber4_Maximum
                    section.data(86).logicalSrcIdx = 85;
                    section.data(86).dtTransOffset = 20091;

                    ;% rtP.UniformRandomNumber4_Seed
                    section.data(87).logicalSrcIdx = 86;
                    section.data(87).dtTransOffset = 20092;

                    ;% rtP.UnitDelay2_InitialCondition_cz3sr01ooy
                    section.data(88).logicalSrcIdx = 87;
                    section.data(88).dtTransOffset = 20093;

                    ;% rtP.mfile_P1_Size
                    section.data(89).logicalSrcIdx = 88;
                    section.data(89).dtTransOffset = 20094;

                    ;% rtP.mfile_P1
                    section.data(90).logicalSrcIdx = 89;
                    section.data(90).dtTransOffset = 20096;

                    ;% rtP.Integrator_IC
                    section.data(91).logicalSrcIdx = 90;
                    section.data(91).dtTransOffset = 20106;

                    ;% rtP.Gain_Gain
                    section.data(92).logicalSrcIdx = 91;
                    section.data(92).dtTransOffset = 20107;

                    ;% rtP.Switch_Threshold
                    section.data(93).logicalSrcIdx = 92;
                    section.data(93).dtTransOffset = 20108;

                    ;% rtP.Feed_Temperature_In_Value
                    section.data(94).logicalSrcIdx = 93;
                    section.data(94).dtTransOffset = 20109;

                    ;% rtP.Feed_Temperature_Out_Value
                    section.data(95).logicalSrcIdx = 94;
                    section.data(95).dtTransOffset = 20110;

                    ;% rtP.Inlet_Flow_In_Value
                    section.data(96).logicalSrcIdx = 95;
                    section.data(96).dtTransOffset = 20111;

                    ;% rtP.Inlet_Flow_Out_Value
                    section.data(97).logicalSrcIdx = 96;
                    section.data(97).dtTransOffset = 20112;

                    ;% rtP.C_Bin_Value
                    section.data(98).logicalSrcIdx = 97;
                    section.data(98).dtTransOffset = 20113;

                    ;% rtP.C_Cin_Value
                    section.data(99).logicalSrcIdx = 98;
                    section.data(99).dtTransOffset = 20114;

                    ;% rtP.Rate3_Value
                    section.data(100).logicalSrcIdx = 99;
                    section.data(100).dtTransOffset = 20115;

                    ;% rtP.Constant_Value
                    section.data(101).logicalSrcIdx = 100;
                    section.data(101).dtTransOffset = 20116;

                    ;% rtP.Constant1_Value
                    section.data(102).logicalSrcIdx = 101;
                    section.data(102).dtTransOffset = 20117;

                    ;% rtP.Constant10_Value
                    section.data(103).logicalSrcIdx = 102;
                    section.data(103).dtTransOffset = 20118;

                    ;% rtP.Constant11_Value
                    section.data(104).logicalSrcIdx = 103;
                    section.data(104).dtTransOffset = 20119;

                    ;% rtP.Constant12_Value
                    section.data(105).logicalSrcIdx = 104;
                    section.data(105).dtTransOffset = 20120;

                    ;% rtP.Constant13_Value
                    section.data(106).logicalSrcIdx = 105;
                    section.data(106).dtTransOffset = 20121;

                    ;% rtP.Constant14_Value
                    section.data(107).logicalSrcIdx = 106;
                    section.data(107).dtTransOffset = 20122;

                    ;% rtP.Constant15_Value
                    section.data(108).logicalSrcIdx = 107;
                    section.data(108).dtTransOffset = 20123;

                    ;% rtP.Constant16_Value
                    section.data(109).logicalSrcIdx = 108;
                    section.data(109).dtTransOffset = 20124;

                    ;% rtP.Constant2_Value
                    section.data(110).logicalSrcIdx = 109;
                    section.data(110).dtTransOffset = 20125;

                    ;% rtP.Constant3_Value
                    section.data(111).logicalSrcIdx = 110;
                    section.data(111).dtTransOffset = 20126;

                    ;% rtP.Constant4_Value
                    section.data(112).logicalSrcIdx = 111;
                    section.data(112).dtTransOffset = 20127;

                    ;% rtP.Constant5_Value
                    section.data(113).logicalSrcIdx = 112;
                    section.data(113).dtTransOffset = 20128;

                    ;% rtP.Constant6_Value
                    section.data(114).logicalSrcIdx = 113;
                    section.data(114).dtTransOffset = 20129;

                    ;% rtP.Constant7_Value
                    section.data(115).logicalSrcIdx = 114;
                    section.data(115).dtTransOffset = 20130;

                    ;% rtP.Constant8_Value
                    section.data(116).logicalSrcIdx = 115;
                    section.data(116).dtTransOffset = 20131;

                    ;% rtP.Constant9_Value
                    section.data(117).logicalSrcIdx = 116;
                    section.data(117).dtTransOffset = 20132;

                    ;% rtP.LevelSet_Value
                    section.data(118).logicalSrcIdx = 117;
                    section.data(118).dtTransOffset = 20133;

                    ;% rtP.PA_Value
                    section.data(119).logicalSrcIdx = 118;
                    section.data(119).dtTransOffset = 20134;

                    ;% rtP.PB_Value
                    section.data(120).logicalSrcIdx = 119;
                    section.data(120).dtTransOffset = 20135;

                    ;% rtP.PC_Value
                    section.data(121).logicalSrcIdx = 120;
                    section.data(121).dtTransOffset = 20136;

                    ;% rtP.PCHANGE_Value
                    section.data(122).logicalSrcIdx = 121;
                    section.data(122).dtTransOffset = 20137;

                    ;% rtP.PD_Value
                    section.data(123).logicalSrcIdx = 122;
                    section.data(123).dtTransOffset = 20138;

                    ;% rtP.PHEAT_Value
                    section.data(124).logicalSrcIdx = 123;
                    section.data(124).dtTransOffset = 20139;

                    ;% rtP.T_outSet_Value
                    section.data(125).logicalSrcIdx = 124;
                    section.data(125).dtTransOffset = 20140;

                    ;% rtP.Constant_Value_lg13tpamfv
                    section.data(126).logicalSrcIdx = 125;
                    section.data(126).dtTransOffset = 20141;

                    ;% rtP.Constant11_Value_jvwwu02wty
                    section.data(127).logicalSrcIdx = 126;
                    section.data(127).dtTransOffset = 20142;

                    ;% rtP.Constant12_Value_ce5osxgbbp
                    section.data(128).logicalSrcIdx = 127;
                    section.data(128).dtTransOffset = 20143;

                    ;% rtP.Constant13_Value_jemti03zwx
                    section.data(129).logicalSrcIdx = 128;
                    section.data(129).dtTransOffset = 20144;

                    ;% rtP.Constant40_Value
                    section.data(130).logicalSrcIdx = 129;
                    section.data(130).dtTransOffset = 20145;

                    ;% rtP.Constant41_Value
                    section.data(131).logicalSrcIdx = 130;
                    section.data(131).dtTransOffset = 20146;

                    ;% rtP.Constant42_Value
                    section.data(132).logicalSrcIdx = 131;
                    section.data(132).dtTransOffset = 20147;

                    ;% rtP.Constant43_Value
                    section.data(133).logicalSrcIdx = 132;
                    section.data(133).dtTransOffset = 20148;

                    ;% rtP.Constant44_Value
                    section.data(134).logicalSrcIdx = 133;
                    section.data(134).dtTransOffset = 20149;

                    ;% rtP.Constant29_Value
                    section.data(135).logicalSrcIdx = 134;
                    section.data(135).dtTransOffset = 20150;

                    ;% rtP.Constant30_Value
                    section.data(136).logicalSrcIdx = 135;
                    section.data(136).dtTransOffset = 20151;

                    ;% rtP.Constant31_Value
                    section.data(137).logicalSrcIdx = 136;
                    section.data(137).dtTransOffset = 20152;

                    ;% rtP.Constant32_Value
                    section.data(138).logicalSrcIdx = 137;
                    section.data(138).dtTransOffset = 20153;

                    ;% rtP.Constant33_Value
                    section.data(139).logicalSrcIdx = 138;
                    section.data(139).dtTransOffset = 20154;

            nTotData = nTotData + section.nData;
            paramMap.sections(1) = section;
            clear section

            section.nData     = 3;
            section.data(3)  = dumData; %prealloc

                    ;% rtP.UnitDelay9_InitialCondition
                    section.data(1).logicalSrcIdx = 139;
                    section.data(1).dtTransOffset = 0;

                    ;% rtP.UnitDelay10_InitialCondition
                    section.data(2).logicalSrcIdx = 140;
                    section.data(2).dtTransOffset = 1;

                    ;% rtP.UnitDelay11_InitialCondition
                    section.data(3).logicalSrcIdx = 141;
                    section.data(3).dtTransOffset = 2;

            nTotData = nTotData + section.nData;
            paramMap.sections(2) = section;
            clear section

            section.nData     = 3;
            section.data(3)  = dumData; %prealloc

                    ;% rtP.ConsiderFault1_CurrentSetting
                    section.data(1).logicalSrcIdx = 142;
                    section.data(1).dtTransOffset = 0;

                    ;% rtP.ConsiderFault11_CurrentSetting
                    section.data(2).logicalSrcIdx = 143;
                    section.data(2).dtTransOffset = 1;

                    ;% rtP.ConsiderFault7_CurrentSetting
                    section.data(3).logicalSrcIdx = 144;
                    section.data(3).dtTransOffset = 2;

            nTotData = nTotData + section.nData;
            paramMap.sections(3) = section;
            clear section

            section.nData     = 4;
            section.data(4)  = dumData; %prealloc

                    ;% rtP.e5i1gkys053.Out1_Y0
                    section.data(1).logicalSrcIdx = 145;
                    section.data(1).dtTransOffset = 0;

                    ;% rtP.e5i1gkys053.Saturation_UpperSat
                    section.data(2).logicalSrcIdx = 146;
                    section.data(2).dtTransOffset = 1;

                    ;% rtP.e5i1gkys053.Saturation_LowerSat
                    section.data(3).logicalSrcIdx = 147;
                    section.data(3).dtTransOffset = 2;

                    ;% rtP.e5i1gkys053.Constant_Value
                    section.data(4).logicalSrcIdx = 148;
                    section.data(4).dtTransOffset = 3;

            nTotData = nTotData + section.nData;
            paramMap.sections(4) = section;
            clear section

            section.nData     = 4;
            section.data(4)  = dumData; %prealloc

                    ;% rtP.o0l0tlmums2.Out1_Y0
                    section.data(1).logicalSrcIdx = 149;
                    section.data(1).dtTransOffset = 0;

                    ;% rtP.o0l0tlmums2.Saturation_UpperSat
                    section.data(2).logicalSrcIdx = 150;
                    section.data(2).dtTransOffset = 1;

                    ;% rtP.o0l0tlmums2.Saturation_LowerSat
                    section.data(3).logicalSrcIdx = 151;
                    section.data(3).dtTransOffset = 2;

                    ;% rtP.o0l0tlmums2.Constant_Value
                    section.data(4).logicalSrcIdx = 152;
                    section.data(4).dtTransOffset = 3;

            nTotData = nTotData + section.nData;
            paramMap.sections(5) = section;
            clear section

            section.nData     = 4;
            section.data(4)  = dumData; %prealloc

                    ;% rtP.lsul0j3thv5.Out1_Y0
                    section.data(1).logicalSrcIdx = 153;
                    section.data(1).dtTransOffset = 0;

                    ;% rtP.lsul0j3thv5.Saturation_UpperSat
                    section.data(2).logicalSrcIdx = 154;
                    section.data(2).dtTransOffset = 1;

                    ;% rtP.lsul0j3thv5.Saturation_LowerSat
                    section.data(3).logicalSrcIdx = 155;
                    section.data(3).dtTransOffset = 2;

                    ;% rtP.lsul0j3thv5.Constant_Value
                    section.data(4).logicalSrcIdx = 156;
                    section.data(4).dtTransOffset = 3;

            nTotData = nTotData + section.nData;
            paramMap.sections(6) = section;
            clear section

            section.nData     = 4;
            section.data(4)  = dumData; %prealloc

                    ;% rtP.lvdmxslirzu.Out1_Y0
                    section.data(1).logicalSrcIdx = 157;
                    section.data(1).dtTransOffset = 0;

                    ;% rtP.lvdmxslirzu.Saturation_UpperSat
                    section.data(2).logicalSrcIdx = 158;
                    section.data(2).dtTransOffset = 1;

                    ;% rtP.lvdmxslirzu.Saturation_LowerSat
                    section.data(3).logicalSrcIdx = 159;
                    section.data(3).dtTransOffset = 2;

                    ;% rtP.lvdmxslirzu.Constant_Value
                    section.data(4).logicalSrcIdx = 160;
                    section.data(4).dtTransOffset = 3;

            nTotData = nTotData + section.nData;
            paramMap.sections(7) = section;
            clear section


            ;%
            ;% Non-auto Data (parameter)
            ;%


        ;%
        ;% Add final counts to struct.
        ;%
        paramMap.nTotData = nTotData;



    ;%**************************
    ;% Create Block Output Map *
    ;%**************************
    
        nTotData      = 0; %add to this count as we go
        nTotSects     = 6;
        sectIdxOffset = 0;

        ;%
        ;% Define dummy sections & preallocate arrays
        ;%
        dumSection.nData = -1;
        dumSection.data  = [];

        dumData.logicalSrcIdx = -1;
        dumData.dtTransOffset = -1;

        ;%
        ;% Init/prealloc sigMap
        ;%
        sigMap.nSections           = nTotSects;
        sigMap.sectIdxOffset       = sectIdxOffset;
            sigMap.sections(nTotSects) = dumSection; %prealloc
        sigMap.nTotData            = -1;

        ;%
        ;% Auto data (rtB)
        ;%
            section.nData     = 56;
            section.data(56)  = dumData; %prealloc

                    ;% rtB.bano4r405l
                    section.data(1).logicalSrcIdx = 0;
                    section.data(1).dtTransOffset = 0;

                    ;% rtB.pwkazhfzxj
                    section.data(2).logicalSrcIdx = 1;
                    section.data(2).dtTransOffset = 1;

                    ;% rtB.dztq1uxeww
                    section.data(3).logicalSrcIdx = 2;
                    section.data(3).dtTransOffset = 2;

                    ;% rtB.imj24wyej4
                    section.data(4).logicalSrcIdx = 3;
                    section.data(4).dtTransOffset = 3;

                    ;% rtB.bd3otgosaa
                    section.data(5).logicalSrcIdx = 4;
                    section.data(5).dtTransOffset = 4;

                    ;% rtB.mcsqmnaiu3
                    section.data(6).logicalSrcIdx = 5;
                    section.data(6).dtTransOffset = 5;

                    ;% rtB.cx2r4dbgvi
                    section.data(7).logicalSrcIdx = 6;
                    section.data(7).dtTransOffset = 6;

                    ;% rtB.fnykzau3dd
                    section.data(8).logicalSrcIdx = 7;
                    section.data(8).dtTransOffset = 7;

                    ;% rtB.bzuganxdf2
                    section.data(9).logicalSrcIdx = 8;
                    section.data(9).dtTransOffset = 8;

                    ;% rtB.mdshgnp3xt
                    section.data(10).logicalSrcIdx = 9;
                    section.data(10).dtTransOffset = 9;

                    ;% rtB.c1djdqayjj
                    section.data(11).logicalSrcIdx = 10;
                    section.data(11).dtTransOffset = 10;

                    ;% rtB.h1nl0bfw4n
                    section.data(12).logicalSrcIdx = 11;
                    section.data(12).dtTransOffset = 11;

                    ;% rtB.oqv2owxgui
                    section.data(13).logicalSrcIdx = 12;
                    section.data(13).dtTransOffset = 12;

                    ;% rtB.lrowya24l3
                    section.data(14).logicalSrcIdx = 13;
                    section.data(14).dtTransOffset = 13;

                    ;% rtB.efsjkrykwf
                    section.data(15).logicalSrcIdx = 14;
                    section.data(15).dtTransOffset = 14;

                    ;% rtB.mciogha2ud
                    section.data(16).logicalSrcIdx = 15;
                    section.data(16).dtTransOffset = 15;

                    ;% rtB.i2sxt22wo1
                    section.data(17).logicalSrcIdx = 16;
                    section.data(17).dtTransOffset = 16;

                    ;% rtB.mpecnpblvq
                    section.data(18).logicalSrcIdx = 17;
                    section.data(18).dtTransOffset = 17;

                    ;% rtB.lps2tdsik3
                    section.data(19).logicalSrcIdx = 18;
                    section.data(19).dtTransOffset = 18;

                    ;% rtB.jantdzvoeu
                    section.data(20).logicalSrcIdx = 19;
                    section.data(20).dtTransOffset = 19;

                    ;% rtB.pzmuj11ybr
                    section.data(21).logicalSrcIdx = 20;
                    section.data(21).dtTransOffset = 20;

                    ;% rtB.atjpekwwur
                    section.data(22).logicalSrcIdx = 21;
                    section.data(22).dtTransOffset = 21;

                    ;% rtB.dsy5xuerr4
                    section.data(23).logicalSrcIdx = 22;
                    section.data(23).dtTransOffset = 22;

                    ;% rtB.b4ykqqwob2
                    section.data(24).logicalSrcIdx = 23;
                    section.data(24).dtTransOffset = 23;

                    ;% rtB.ipwdgvuaap
                    section.data(25).logicalSrcIdx = 24;
                    section.data(25).dtTransOffset = 24;

                    ;% rtB.gs2acg4a1b
                    section.data(26).logicalSrcIdx = 25;
                    section.data(26).dtTransOffset = 25;

                    ;% rtB.lgnqauvekd
                    section.data(27).logicalSrcIdx = 26;
                    section.data(27).dtTransOffset = 26;

                    ;% rtB.kzqd3pbqkr
                    section.data(28).logicalSrcIdx = 27;
                    section.data(28).dtTransOffset = 27;

                    ;% rtB.n1f2ld0elb
                    section.data(29).logicalSrcIdx = 28;
                    section.data(29).dtTransOffset = 28;

                    ;% rtB.ex4xrkfleq
                    section.data(30).logicalSrcIdx = 29;
                    section.data(30).dtTransOffset = 29;

                    ;% rtB.eo3aq2xcix
                    section.data(31).logicalSrcIdx = 30;
                    section.data(31).dtTransOffset = 30;

                    ;% rtB.dv5gz4icu0
                    section.data(32).logicalSrcIdx = 31;
                    section.data(32).dtTransOffset = 31;

                    ;% rtB.fscu2cadee
                    section.data(33).logicalSrcIdx = 32;
                    section.data(33).dtTransOffset = 32;

                    ;% rtB.kwz4uvuft3
                    section.data(34).logicalSrcIdx = 33;
                    section.data(34).dtTransOffset = 33;

                    ;% rtB.e0gpvxxppp
                    section.data(35).logicalSrcIdx = 34;
                    section.data(35).dtTransOffset = 53;

                    ;% rtB.ib3grttpul
                    section.data(36).logicalSrcIdx = 35;
                    section.data(36).dtTransOffset = 62;

                    ;% rtB.k3jie4wym5
                    section.data(37).logicalSrcIdx = 36;
                    section.data(37).dtTransOffset = 63;

                    ;% rtB.czzkhzteyg
                    section.data(38).logicalSrcIdx = 37;
                    section.data(38).dtTransOffset = 64;

                    ;% rtB.iu3dgzsmox
                    section.data(39).logicalSrcIdx = 38;
                    section.data(39).dtTransOffset = 65;

                    ;% rtB.bbrn1ou5mh
                    section.data(40).logicalSrcIdx = 39;
                    section.data(40).dtTransOffset = 66;

                    ;% rtB.jkvshhuv25
                    section.data(41).logicalSrcIdx = 40;
                    section.data(41).dtTransOffset = 67;

                    ;% rtB.ifp2xzx5cj
                    section.data(42).logicalSrcIdx = 41;
                    section.data(42).dtTransOffset = 68;

                    ;% rtB.jxqv3hrimg
                    section.data(43).logicalSrcIdx = 42;
                    section.data(43).dtTransOffset = 69;

                    ;% rtB.ggli2ppxyv
                    section.data(44).logicalSrcIdx = 43;
                    section.data(44).dtTransOffset = 70;

                    ;% rtB.owumd2pxxx
                    section.data(45).logicalSrcIdx = 44;
                    section.data(45).dtTransOffset = 71;

                    ;% rtB.bmollnwf0s
                    section.data(46).logicalSrcIdx = 45;
                    section.data(46).dtTransOffset = 72;

                    ;% rtB.d5u0rvgiee
                    section.data(47).logicalSrcIdx = 46;
                    section.data(47).dtTransOffset = 73;

                    ;% rtB.k3xz1ht2ij
                    section.data(48).logicalSrcIdx = 47;
                    section.data(48).dtTransOffset = 74;

                    ;% rtB.iorisswymh
                    section.data(49).logicalSrcIdx = 48;
                    section.data(49).dtTransOffset = 75;

                    ;% rtB.l4lnonwfg2
                    section.data(50).logicalSrcIdx = 49;
                    section.data(50).dtTransOffset = 76;

                    ;% rtB.gvytu245ky
                    section.data(51).logicalSrcIdx = 50;
                    section.data(51).dtTransOffset = 77;

                    ;% rtB.ai311bapfw
                    section.data(52).logicalSrcIdx = 51;
                    section.data(52).dtTransOffset = 78;

                    ;% rtB.htmpoa25zx
                    section.data(53).logicalSrcIdx = 52;
                    section.data(53).dtTransOffset = 79;

                    ;% rtB.nehncd51lh
                    section.data(54).logicalSrcIdx = 53;
                    section.data(54).dtTransOffset = 80;

                    ;% rtB.ftctw2pua5
                    section.data(55).logicalSrcIdx = 54;
                    section.data(55).dtTransOffset = 81;

                    ;% rtB.c110xhgmn1
                    section.data(56).logicalSrcIdx = 55;
                    section.data(56).dtTransOffset = 82;

            nTotData = nTotData + section.nData;
            sigMap.sections(1) = section;
            clear section

            section.nData     = 14;
            section.data(14)  = dumData; %prealloc

                    ;% rtB.gnzysggnk4
                    section.data(1).logicalSrcIdx = 56;
                    section.data(1).dtTransOffset = 0;

                    ;% rtB.hdnlmp40uy
                    section.data(2).logicalSrcIdx = 57;
                    section.data(2).dtTransOffset = 1;

                    ;% rtB.euqxsw55q1
                    section.data(3).logicalSrcIdx = 58;
                    section.data(3).dtTransOffset = 2;

                    ;% rtB.nr5jzefs11
                    section.data(4).logicalSrcIdx = 59;
                    section.data(4).dtTransOffset = 3;

                    ;% rtB.g4otcjhaps
                    section.data(5).logicalSrcIdx = 60;
                    section.data(5).dtTransOffset = 4;

                    ;% rtB.c50enbqbhd
                    section.data(6).logicalSrcIdx = 61;
                    section.data(6).dtTransOffset = 5;

                    ;% rtB.koa2xwzkqz
                    section.data(7).logicalSrcIdx = 62;
                    section.data(7).dtTransOffset = 6;

                    ;% rtB.llcmsauyav
                    section.data(8).logicalSrcIdx = 63;
                    section.data(8).dtTransOffset = 7;

                    ;% rtB.govtsadkmh
                    section.data(9).logicalSrcIdx = 64;
                    section.data(9).dtTransOffset = 8;

                    ;% rtB.gfgfscs3wh
                    section.data(10).logicalSrcIdx = 65;
                    section.data(10).dtTransOffset = 9;

                    ;% rtB.hwlkc3gph4
                    section.data(11).logicalSrcIdx = 66;
                    section.data(11).dtTransOffset = 10;

                    ;% rtB.ipy2o045sf
                    section.data(12).logicalSrcIdx = 67;
                    section.data(12).dtTransOffset = 11;

                    ;% rtB.ggozffptrp
                    section.data(13).logicalSrcIdx = 68;
                    section.data(13).dtTransOffset = 12;

                    ;% rtB.ln01g2x54f
                    section.data(14).logicalSrcIdx = 69;
                    section.data(14).dtTransOffset = 13;

            nTotData = nTotData + section.nData;
            sigMap.sections(2) = section;
            clear section

            section.nData     = 1;
            section.data(1)  = dumData; %prealloc

                    ;% rtB.e5i1gkys053.nyju2jnyn3
                    section.data(1).logicalSrcIdx = 70;
                    section.data(1).dtTransOffset = 0;

            nTotData = nTotData + section.nData;
            sigMap.sections(3) = section;
            clear section

            section.nData     = 1;
            section.data(1)  = dumData; %prealloc

                    ;% rtB.o0l0tlmums2.ebzcxl42h5
                    section.data(1).logicalSrcIdx = 71;
                    section.data(1).dtTransOffset = 0;

            nTotData = nTotData + section.nData;
            sigMap.sections(4) = section;
            clear section

            section.nData     = 1;
            section.data(1)  = dumData; %prealloc

                    ;% rtB.lsul0j3thv5.nzhrh1tkt0
                    section.data(1).logicalSrcIdx = 72;
                    section.data(1).dtTransOffset = 0;

            nTotData = nTotData + section.nData;
            sigMap.sections(5) = section;
            clear section

            section.nData     = 1;
            section.data(1)  = dumData; %prealloc

                    ;% rtB.lvdmxslirzu.ppbrf42mvn
                    section.data(1).logicalSrcIdx = 73;
                    section.data(1).dtTransOffset = 0;

            nTotData = nTotData + section.nData;
            sigMap.sections(6) = section;
            clear section


            ;%
            ;% Non-auto Data (signal)
            ;%


        ;%
        ;% Add final counts to struct.
        ;%
        sigMap.nTotData = nTotData;



    ;%*******************
    ;% Create DWork Map *
    ;%*******************
    
        nTotData      = 0; %add to this count as we go
        nTotSects     = 13;
        sectIdxOffset = 6;

        ;%
        ;% Define dummy sections & preallocate arrays
        ;%
        dumSection.nData = -1;
        dumSection.data  = [];

        dumData.logicalSrcIdx = -1;
        dumData.dtTransOffset = -1;

        ;%
        ;% Init/prealloc dworkMap
        ;%
        dworkMap.nSections           = nTotSects;
        dworkMap.sectIdxOffset       = sectIdxOffset;
            dworkMap.sections(nTotSects) = dumSection; %prealloc
        dworkMap.nTotData            = -1;

        ;%
        ;% Auto data (rtDW)
        ;%
            section.nData     = 22;
            section.data(22)  = dumData; %prealloc

                    ;% rtDW.mz0zdu34tn
                    section.data(1).logicalSrcIdx = 0;
                    section.data(1).dtTransOffset = 0;

                    ;% rtDW.cronjwvq3j
                    section.data(2).logicalSrcIdx = 1;
                    section.data(2).dtTransOffset = 1;

                    ;% rtDW.dsnlclvjlf
                    section.data(3).logicalSrcIdx = 2;
                    section.data(3).dtTransOffset = 2;

                    ;% rtDW.nfi0353erc
                    section.data(4).logicalSrcIdx = 3;
                    section.data(4).dtTransOffset = 3;

                    ;% rtDW.g5guutg2r4
                    section.data(5).logicalSrcIdx = 4;
                    section.data(5).dtTransOffset = 4;

                    ;% rtDW.iecjfocdpt
                    section.data(6).logicalSrcIdx = 5;
                    section.data(6).dtTransOffset = 5;

                    ;% rtDW.pdh0ayrbq2
                    section.data(7).logicalSrcIdx = 6;
                    section.data(7).dtTransOffset = 6;

                    ;% rtDW.i2jledyuxk
                    section.data(8).logicalSrcIdx = 7;
                    section.data(8).dtTransOffset = 7;

                    ;% rtDW.mk4nogmrgx
                    section.data(9).logicalSrcIdx = 8;
                    section.data(9).dtTransOffset = 8;

                    ;% rtDW.hdgt0peaua
                    section.data(10).logicalSrcIdx = 9;
                    section.data(10).dtTransOffset = 9;

                    ;% rtDW.bv534fxrfq
                    section.data(11).logicalSrcIdx = 10;
                    section.data(11).dtTransOffset = 10;

                    ;% rtDW.fudylxbq0j
                    section.data(12).logicalSrcIdx = 11;
                    section.data(12).dtTransOffset = 11;

                    ;% rtDW.bgotvck1y4
                    section.data(13).logicalSrcIdx = 12;
                    section.data(13).dtTransOffset = 12;

                    ;% rtDW.dfulppyfs1
                    section.data(14).logicalSrcIdx = 13;
                    section.data(14).dtTransOffset = 13;

                    ;% rtDW.o0jhm5tqhv
                    section.data(15).logicalSrcIdx = 14;
                    section.data(15).dtTransOffset = 14;

                    ;% rtDW.gymfbya0lf
                    section.data(16).logicalSrcIdx = 15;
                    section.data(16).dtTransOffset = 15;

                    ;% rtDW.mq4tzms12g
                    section.data(17).logicalSrcIdx = 16;
                    section.data(17).dtTransOffset = 16;

                    ;% rtDW.jk5yslpya4
                    section.data(18).logicalSrcIdx = 17;
                    section.data(18).dtTransOffset = 17;

                    ;% rtDW.o0mql2hqjx
                    section.data(19).logicalSrcIdx = 18;
                    section.data(19).dtTransOffset = 18;

                    ;% rtDW.o2pzpkkeul
                    section.data(20).logicalSrcIdx = 19;
                    section.data(20).dtTransOffset = 19;

                    ;% rtDW.njvyqws1h5
                    section.data(21).logicalSrcIdx = 20;
                    section.data(21).dtTransOffset = 20;

                    ;% rtDW.hblnhilp5j
                    section.data(22).logicalSrcIdx = 21;
                    section.data(22).dtTransOffset = 21;

            nTotData = nTotData + section.nData;
            dworkMap.sections(1) = section;
            clear section

            section.nData     = 64;
            section.data(64)  = dumData; %prealloc

                    ;% rtDW.odihpq11te.AQHandles
                    section.data(1).logicalSrcIdx = 22;
                    section.data(1).dtTransOffset = 0;

                    ;% rtDW.jsnyah43h5.AQHandles
                    section.data(2).logicalSrcIdx = 23;
                    section.data(2).dtTransOffset = 1;

                    ;% rtDW.ggzqve4ryn.AQHandles
                    section.data(3).logicalSrcIdx = 24;
                    section.data(3).dtTransOffset = 2;

                    ;% rtDW.ismfv5vasc.AQHandles
                    section.data(4).logicalSrcIdx = 25;
                    section.data(4).dtTransOffset = 3;

                    ;% rtDW.ns05uf10ld.AQHandles
                    section.data(5).logicalSrcIdx = 26;
                    section.data(5).dtTransOffset = 4;

                    ;% rtDW.nkxcwijbwx.AQHandles
                    section.data(6).logicalSrcIdx = 27;
                    section.data(6).dtTransOffset = 5;

                    ;% rtDW.msb5d3me1j.AQHandles
                    section.data(7).logicalSrcIdx = 28;
                    section.data(7).dtTransOffset = 6;

                    ;% rtDW.lbtghvt0ml.AQHandles
                    section.data(8).logicalSrcIdx = 29;
                    section.data(8).dtTransOffset = 7;

                    ;% rtDW.mvgtzq34qx.AQHandles
                    section.data(9).logicalSrcIdx = 30;
                    section.data(9).dtTransOffset = 8;

                    ;% rtDW.aosifnfz0v.AQHandles
                    section.data(10).logicalSrcIdx = 31;
                    section.data(10).dtTransOffset = 9;

                    ;% rtDW.lpahj2azln.AQHandles
                    section.data(11).logicalSrcIdx = 32;
                    section.data(11).dtTransOffset = 10;

                    ;% rtDW.pyvmjo2bqw.AQHandles
                    section.data(12).logicalSrcIdx = 33;
                    section.data(12).dtTransOffset = 11;

                    ;% rtDW.mcwiq2fdf3.AQHandles
                    section.data(13).logicalSrcIdx = 34;
                    section.data(13).dtTransOffset = 12;

                    ;% rtDW.jarmeshqgo.AQHandles
                    section.data(14).logicalSrcIdx = 35;
                    section.data(14).dtTransOffset = 13;

                    ;% rtDW.ltulzml5oa.AQHandles
                    section.data(15).logicalSrcIdx = 36;
                    section.data(15).dtTransOffset = 14;

                    ;% rtDW.lvl5uvsvj2.AQHandles
                    section.data(16).logicalSrcIdx = 37;
                    section.data(16).dtTransOffset = 15;

                    ;% rtDW.inyhtmatu2.AQHandles
                    section.data(17).logicalSrcIdx = 38;
                    section.data(17).dtTransOffset = 16;

                    ;% rtDW.ah0o3rwxbv.AQHandles
                    section.data(18).logicalSrcIdx = 39;
                    section.data(18).dtTransOffset = 17;

                    ;% rtDW.flebub5s5m.AQHandles
                    section.data(19).logicalSrcIdx = 40;
                    section.data(19).dtTransOffset = 18;

                    ;% rtDW.e0u1digqih.TimePtr
                    section.data(20).logicalSrcIdx = 41;
                    section.data(20).dtTransOffset = 19;

                    ;% rtDW.ddqlrilmhr.TimePtr
                    section.data(21).logicalSrcIdx = 42;
                    section.data(21).dtTransOffset = 20;

                    ;% rtDW.liiyr4gl0x.LoggedData
                    section.data(22).logicalSrcIdx = 43;
                    section.data(22).dtTransOffset = 21;

                    ;% rtDW.e3pcjst2gf.LoggedData
                    section.data(23).logicalSrcIdx = 44;
                    section.data(23).dtTransOffset = 22;

                    ;% rtDW.dfkwoy32wq.LoggedData
                    section.data(24).logicalSrcIdx = 45;
                    section.data(24).dtTransOffset = 23;

                    ;% rtDW.i4p5qsx20a.LoggedData
                    section.data(25).logicalSrcIdx = 46;
                    section.data(25).dtTransOffset = 24;

                    ;% rtDW.lqpw014zwg.LoggedData
                    section.data(26).logicalSrcIdx = 47;
                    section.data(26).dtTransOffset = 25;

                    ;% rtDW.psg34ddjdk.LoggedData
                    section.data(27).logicalSrcIdx = 48;
                    section.data(27).dtTransOffset = 26;

                    ;% rtDW.onuyjr2ufc.LoggedData
                    section.data(28).logicalSrcIdx = 49;
                    section.data(28).dtTransOffset = 27;

                    ;% rtDW.epgqqqavhn.LoggedData
                    section.data(29).logicalSrcIdx = 50;
                    section.data(29).dtTransOffset = 28;

                    ;% rtDW.j3e0f44doy.AQHandles
                    section.data(30).logicalSrcIdx = 51;
                    section.data(30).dtTransOffset = 29;

                    ;% rtDW.oot0srnoki.AQHandles
                    section.data(31).logicalSrcIdx = 52;
                    section.data(31).dtTransOffset = 30;

                    ;% rtDW.bjz5tw4p5j.AQHandles
                    section.data(32).logicalSrcIdx = 53;
                    section.data(32).dtTransOffset = 31;

                    ;% rtDW.mljkjloakr.AQHandles
                    section.data(33).logicalSrcIdx = 54;
                    section.data(33).dtTransOffset = 32;

                    ;% rtDW.l4vlioxbgl.AQHandles
                    section.data(34).logicalSrcIdx = 55;
                    section.data(34).dtTransOffset = 33;

                    ;% rtDW.kkblxpcw3m.AQHandles
                    section.data(35).logicalSrcIdx = 56;
                    section.data(35).dtTransOffset = 34;

                    ;% rtDW.h3jcwnop0g.AQHandles
                    section.data(36).logicalSrcIdx = 57;
                    section.data(36).dtTransOffset = 35;

                    ;% rtDW.mjxkrhmtfj.AQHandles
                    section.data(37).logicalSrcIdx = 58;
                    section.data(37).dtTransOffset = 36;

                    ;% rtDW.beunqpbxj1.AQHandles
                    section.data(38).logicalSrcIdx = 59;
                    section.data(38).dtTransOffset = 37;

                    ;% rtDW.jvhbaaoh3e.AQHandles
                    section.data(39).logicalSrcIdx = 60;
                    section.data(39).dtTransOffset = 38;

                    ;% rtDW.ctwshmhpdz.AQHandles
                    section.data(40).logicalSrcIdx = 61;
                    section.data(40).dtTransOffset = 39;

                    ;% rtDW.licnk0hmrn.AQHandles
                    section.data(41).logicalSrcIdx = 62;
                    section.data(41).dtTransOffset = 40;

                    ;% rtDW.jvdos0csvi.AQHandles
                    section.data(42).logicalSrcIdx = 63;
                    section.data(42).dtTransOffset = 41;

                    ;% rtDW.pn3nw2wp03.AQHandles
                    section.data(43).logicalSrcIdx = 64;
                    section.data(43).dtTransOffset = 42;

                    ;% rtDW.lclc5oxd1y.AQHandles
                    section.data(44).logicalSrcIdx = 65;
                    section.data(44).dtTransOffset = 43;

                    ;% rtDW.k2lm4rcfbi.AQHandles
                    section.data(45).logicalSrcIdx = 66;
                    section.data(45).dtTransOffset = 44;

                    ;% rtDW.hcvlm25apo.AQHandles
                    section.data(46).logicalSrcIdx = 67;
                    section.data(46).dtTransOffset = 45;

                    ;% rtDW.ku5epe2lev.AQHandles
                    section.data(47).logicalSrcIdx = 68;
                    section.data(47).dtTransOffset = 46;

                    ;% rtDW.eksra31szv.AQHandles
                    section.data(48).logicalSrcIdx = 69;
                    section.data(48).dtTransOffset = 47;

                    ;% rtDW.ahr1p51zrw.AQHandles
                    section.data(49).logicalSrcIdx = 70;
                    section.data(49).dtTransOffset = 48;

                    ;% rtDW.fwpf1vdbdo.AQHandles
                    section.data(50).logicalSrcIdx = 71;
                    section.data(50).dtTransOffset = 49;

                    ;% rtDW.ciu3qjsht5.AQHandles
                    section.data(51).logicalSrcIdx = 72;
                    section.data(51).dtTransOffset = 50;

                    ;% rtDW.m2i42ofdw4.AQHandles
                    section.data(52).logicalSrcIdx = 73;
                    section.data(52).dtTransOffset = 51;

                    ;% rtDW.frknafxvto.AQHandles
                    section.data(53).logicalSrcIdx = 74;
                    section.data(53).dtTransOffset = 52;

                    ;% rtDW.blapbcem3w.AQHandles
                    section.data(54).logicalSrcIdx = 75;
                    section.data(54).dtTransOffset = 53;

                    ;% rtDW.ekmy53hjdg.AQHandles
                    section.data(55).logicalSrcIdx = 76;
                    section.data(55).dtTransOffset = 54;

                    ;% rtDW.go2ndgnsmr.LoggedData
                    section.data(56).logicalSrcIdx = 77;
                    section.data(56).dtTransOffset = 55;

                    ;% rtDW.aw4of2bzto.FilePtr
                    section.data(57).logicalSrcIdx = 78;
                    section.data(57).dtTransOffset = 56;

                    ;% rtDW.j2ehmt2zxo.AQHandles
                    section.data(58).logicalSrcIdx = 79;
                    section.data(58).dtTransOffset = 57;

                    ;% rtDW.cue41xrxnu.AQHandles
                    section.data(59).logicalSrcIdx = 80;
                    section.data(59).dtTransOffset = 58;

                    ;% rtDW.pubxocmqc2.AQHandles
                    section.data(60).logicalSrcIdx = 81;
                    section.data(60).dtTransOffset = 59;

                    ;% rtDW.f0ugwgjvhr.AQHandles
                    section.data(61).logicalSrcIdx = 82;
                    section.data(61).dtTransOffset = 60;

                    ;% rtDW.g53jytoip4.AQHandles
                    section.data(62).logicalSrcIdx = 83;
                    section.data(62).dtTransOffset = 61;

                    ;% rtDW.obf4siedf4.AQHandles
                    section.data(63).logicalSrcIdx = 84;
                    section.data(63).dtTransOffset = 62;

                    ;% rtDW.o5jtmaqc3t.AQHandles
                    section.data(64).logicalSrcIdx = 85;
                    section.data(64).dtTransOffset = 63;

            nTotData = nTotData + section.nData;
            dworkMap.sections(2) = section;
            clear section

            section.nData     = 2;
            section.data(2)  = dumData; %prealloc

                    ;% rtDW.dx0psck2g2
                    section.data(1).logicalSrcIdx = 86;
                    section.data(1).dtTransOffset = 0;

                    ;% rtDW.bv5o5ntfep
                    section.data(2).logicalSrcIdx = 87;
                    section.data(2).dtTransOffset = 1;

            nTotData = nTotData + section.nData;
            dworkMap.sections(3) = section;
            clear section

            section.nData     = 26;
            section.data(26)  = dumData; %prealloc

                    ;% rtDW.bmwah53if2
                    section.data(1).logicalSrcIdx = 88;
                    section.data(1).dtTransOffset = 0;

                    ;% rtDW.lustmxh0ru
                    section.data(2).logicalSrcIdx = 89;
                    section.data(2).dtTransOffset = 1;

                    ;% rtDW.o5vdryefj2
                    section.data(3).logicalSrcIdx = 90;
                    section.data(3).dtTransOffset = 2;

                    ;% rtDW.kasvnwnwfd
                    section.data(4).logicalSrcIdx = 91;
                    section.data(4).dtTransOffset = 3;

                    ;% rtDW.d2hdmgi2df
                    section.data(5).logicalSrcIdx = 92;
                    section.data(5).dtTransOffset = 4;

                    ;% rtDW.eesjxfyvk2
                    section.data(6).logicalSrcIdx = 93;
                    section.data(6).dtTransOffset = 5;

                    ;% rtDW.cdqamvzgi2
                    section.data(7).logicalSrcIdx = 94;
                    section.data(7).dtTransOffset = 6;

                    ;% rtDW.a2u1lqkyoh
                    section.data(8).logicalSrcIdx = 95;
                    section.data(8).dtTransOffset = 7;

                    ;% rtDW.mpm2qm4ahz
                    section.data(9).logicalSrcIdx = 96;
                    section.data(9).dtTransOffset = 8;

                    ;% rtDW.arjuzvir0v
                    section.data(10).logicalSrcIdx = 97;
                    section.data(10).dtTransOffset = 9;

                    ;% rtDW.a3naafic3w
                    section.data(11).logicalSrcIdx = 98;
                    section.data(11).dtTransOffset = 10;

                    ;% rtDW.g0pte1h22i
                    section.data(12).logicalSrcIdx = 99;
                    section.data(12).dtTransOffset = 11;

                    ;% rtDW.ksqmuzqxoq
                    section.data(13).logicalSrcIdx = 100;
                    section.data(13).dtTransOffset = 12;

                    ;% rtDW.cnphnmyixz
                    section.data(14).logicalSrcIdx = 101;
                    section.data(14).dtTransOffset = 13;

                    ;% rtDW.lyrzf3l331
                    section.data(15).logicalSrcIdx = 102;
                    section.data(15).dtTransOffset = 14;

                    ;% rtDW.o5lpscgpim
                    section.data(16).logicalSrcIdx = 103;
                    section.data(16).dtTransOffset = 15;

                    ;% rtDW.i33gdokzps
                    section.data(17).logicalSrcIdx = 104;
                    section.data(17).dtTransOffset = 16;

                    ;% rtDW.puvxpdyspy
                    section.data(18).logicalSrcIdx = 105;
                    section.data(18).dtTransOffset = 17;

                    ;% rtDW.hvipzkfxby
                    section.data(19).logicalSrcIdx = 106;
                    section.data(19).dtTransOffset = 18;

                    ;% rtDW.b2oh0gakei
                    section.data(20).logicalSrcIdx = 107;
                    section.data(20).dtTransOffset = 19;

                    ;% rtDW.j4xo2d0p0j
                    section.data(21).logicalSrcIdx = 108;
                    section.data(21).dtTransOffset = 20;

                    ;% rtDW.en0wsgm2d2
                    section.data(22).logicalSrcIdx = 109;
                    section.data(22).dtTransOffset = 21;

                    ;% rtDW.htl3ck05k3
                    section.data(23).logicalSrcIdx = 110;
                    section.data(23).dtTransOffset = 22;

                    ;% rtDW.kf3zpzee4j
                    section.data(24).logicalSrcIdx = 111;
                    section.data(24).dtTransOffset = 647;

                    ;% rtDW.m5g4cvi2wi
                    section.data(25).logicalSrcIdx = 112;
                    section.data(25).dtTransOffset = 649;

                    ;% rtDW.ifylc1ayya
                    section.data(26).logicalSrcIdx = 113;
                    section.data(26).dtTransOffset = 650;

            nTotData = nTotData + section.nData;
            dworkMap.sections(4) = section;
            clear section

            section.nData     = 3;
            section.data(3)  = dumData; %prealloc

                    ;% rtDW.f4gzzk1cad.PrevIndex
                    section.data(1).logicalSrcIdx = 114;
                    section.data(1).dtTransOffset = 0;

                    ;% rtDW.gizzljrotf.PrevIndex
                    section.data(2).logicalSrcIdx = 115;
                    section.data(2).dtTransOffset = 1;

                    ;% rtDW.bttm2sqgp0.Count
                    section.data(3).logicalSrcIdx = 116;
                    section.data(3).dtTransOffset = 2;

            nTotData = nTotData + section.nData;
            dworkMap.sections(5) = section;
            clear section

            section.nData     = 1;
            section.data(1)  = dumData; %prealloc

                    ;% rtDW.csce1vtaiv
                    section.data(1).logicalSrcIdx = 117;
                    section.data(1).dtTransOffset = 0;

            nTotData = nTotData + section.nData;
            dworkMap.sections(6) = section;
            clear section

            section.nData     = 3;
            section.data(3)  = dumData; %prealloc

                    ;% rtDW.i3eqa0qza0
                    section.data(1).logicalSrcIdx = 118;
                    section.data(1).dtTransOffset = 0;

                    ;% rtDW.agio50d4gu
                    section.data(2).logicalSrcIdx = 119;
                    section.data(2).dtTransOffset = 1;

                    ;% rtDW.g10sbzotef
                    section.data(3).logicalSrcIdx = 120;
                    section.data(3).dtTransOffset = 2;

            nTotData = nTotData + section.nData;
            dworkMap.sections(7) = section;
            clear section

            section.nData     = 6;
            section.data(6)  = dumData; %prealloc

                    ;% rtDW.jraid5zlrs
                    section.data(1).logicalSrcIdx = 121;
                    section.data(1).dtTransOffset = 0;

                    ;% rtDW.hjgrew42b2
                    section.data(2).logicalSrcIdx = 122;
                    section.data(2).dtTransOffset = 1;

                    ;% rtDW.ntbs21hax4
                    section.data(3).logicalSrcIdx = 123;
                    section.data(3).dtTransOffset = 2;

                    ;% rtDW.eyqkltgelg
                    section.data(4).logicalSrcIdx = 124;
                    section.data(4).dtTransOffset = 3;

                    ;% rtDW.il0ohwuds5
                    section.data(5).logicalSrcIdx = 125;
                    section.data(5).dtTransOffset = 4;

                    ;% rtDW.cuxelkmbzn
                    section.data(6).logicalSrcIdx = 126;
                    section.data(6).dtTransOffset = 5;

            nTotData = nTotData + section.nData;
            dworkMap.sections(8) = section;
            clear section

            section.nData     = 8;
            section.data(8)  = dumData; %prealloc

                    ;% rtDW.b0xpqic30u
                    section.data(1).logicalSrcIdx = 127;
                    section.data(1).dtTransOffset = 0;

                    ;% rtDW.iu2ulpoww0
                    section.data(2).logicalSrcIdx = 128;
                    section.data(2).dtTransOffset = 1;

                    ;% rtDW.l4htxomgyb
                    section.data(3).logicalSrcIdx = 129;
                    section.data(3).dtTransOffset = 2;

                    ;% rtDW.hhdj03gcse
                    section.data(4).logicalSrcIdx = 130;
                    section.data(4).dtTransOffset = 3;

                    ;% rtDW.e54eqryqod
                    section.data(5).logicalSrcIdx = 131;
                    section.data(5).dtTransOffset = 4;

                    ;% rtDW.ek03o5d0zn
                    section.data(6).logicalSrcIdx = 132;
                    section.data(6).dtTransOffset = 5;

                    ;% rtDW.ouoju14cbw
                    section.data(7).logicalSrcIdx = 133;
                    section.data(7).dtTransOffset = 6;

                    ;% rtDW.k20nitrd4l
                    section.data(8).logicalSrcIdx = 134;
                    section.data(8).dtTransOffset = 7;

            nTotData = nTotData + section.nData;
            dworkMap.sections(9) = section;
            clear section

            section.nData     = 1;
            section.data(1)  = dumData; %prealloc

                    ;% rtDW.e5i1gkys053.iaiukld4k4
                    section.data(1).logicalSrcIdx = 135;
                    section.data(1).dtTransOffset = 0;

            nTotData = nTotData + section.nData;
            dworkMap.sections(10) = section;
            clear section

            section.nData     = 1;
            section.data(1)  = dumData; %prealloc

                    ;% rtDW.o0l0tlmums2.nmoh1fygpu
                    section.data(1).logicalSrcIdx = 136;
                    section.data(1).dtTransOffset = 0;

            nTotData = nTotData + section.nData;
            dworkMap.sections(11) = section;
            clear section

            section.nData     = 1;
            section.data(1)  = dumData; %prealloc

                    ;% rtDW.lsul0j3thv5.b0jtmkqrl5
                    section.data(1).logicalSrcIdx = 137;
                    section.data(1).dtTransOffset = 0;

            nTotData = nTotData + section.nData;
            dworkMap.sections(12) = section;
            clear section

            section.nData     = 1;
            section.data(1)  = dumData; %prealloc

                    ;% rtDW.lvdmxslirzu.ec3xwiqauu
                    section.data(1).logicalSrcIdx = 138;
                    section.data(1).dtTransOffset = 0;

            nTotData = nTotData + section.nData;
            dworkMap.sections(13) = section;
            clear section


            ;%
            ;% Non-auto Data (dwork)
            ;%


        ;%
        ;% Add final counts to struct.
        ;%
        dworkMap.nTotData = nTotData;



    ;%
    ;% Add individual maps to base struct.
    ;%

    targMap.paramMap  = paramMap;
    targMap.signalMap = sigMap;
    targMap.dworkMap  = dworkMap;

    ;%
    ;% Add checksums to base struct.
    ;%


    targMap.checksum0 = 4260740495;
    targMap.checksum1 = 4141272003;
    targMap.checksum2 = 4182188841;
    targMap.checksum3 = 2629175771;

