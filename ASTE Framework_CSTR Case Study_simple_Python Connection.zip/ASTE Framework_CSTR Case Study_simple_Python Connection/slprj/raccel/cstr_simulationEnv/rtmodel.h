#ifndef RTW_HEADER_rtmodel_h_
#define RTW_HEADER_rtmodel_h_
#include "cstr_simulationEnv.h"
#define GRTINTERFACE 1
#endif
