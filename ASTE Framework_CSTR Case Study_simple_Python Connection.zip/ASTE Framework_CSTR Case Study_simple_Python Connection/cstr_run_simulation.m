function res = cstr_run_simulation(args)
    % cstr_run_simulation loads data, runs the Simulink model, and plots results.
    %
    % Ensure the required data files, model, and script are in the same folder.

    arguments
        args.StopTime (1,1) double = nan
        args.TunableParameters = []
    end

    %% Create the SimulationInput object
    % Note that the name of the model is hard-coded to 'the_model'
    si = Simulink.SimulationInput('cstr_simulationEnv');

    %% Load the StopTime into the SimulationInput object
    if ~isnan(args.StopTime)
        si = si.setModelParameter('StopTime', num2str(args.StopTime));
    end

    %% Load the specified tunable parameters into the simulation input object
    if isstruct(args.TunableParameters) 
        tpNames = fieldnames(args.TunableParameters);
        for itp = 1:numel(tpNames)
            tpn = tpNames{itp};
            tpv = args.TunableParameters.(tpn);
            si = si.setVariable(tpn, tpv);
        end
    end

    %% Configure for deployment
    si = simulink.compiler.configureForDeployment(si);
    
    %% Call sim
    so = sim(si);

end
