load out_data.mat

% Inputs
time  = cstr(1,:);
flow_in = cstr(2,:);
conc_A_pre = cstr(3,:);
conc_B_pre = cstr(4,:);
temp_jacket  = cstr(5,:);
conc_C_pre = cstr(6,:);
feed_temp = cstr(7,:);
flow_out_pre = cstr(8,:);
conc_D_pre = cstr(9,:);
rate = cstr(10,:);

% Outputs
level  = cstr(16,:);
flow_out_post = cstr(17,:);
conc_A_post = cstr(18,:);
conc_B_post = cstr(19,:);
temp_out = cstr(20,:);
conc_C_post = cstr(21,:);
conc_D_post = cstr(22,:);
flow_in_post = cstr(23,:);
profit = cstr(24,:);

figure(1)
hold off

% Concentration Plot A
subplot(4,1,1)
hold off
plot(time,conc_A_pre,'b:','LineWidth',2) 
hold on
plot(time,conc_A_post,'r:','LineWidth',2)
legend('Cocentration A-pre', 'Concentration A-post');
axis([min(time) max(time) -1 2]);
ylabel('Conc (mol/m^3)')

% Concentration Plot B
subplot(4,1,2)
hold off
plot(time,conc_B_pre,'b:','LineWidth',2)
hold on
plot(time,conc_B_post,'r:','LineWidth',2)
legend('Cocentration B-pre', 'Concentration B-post');
axis([min(time) max(time) -1 2]);
ylabel('Conc (mol/m^3)')

% Concentration Plot C
subplot(4,1,3)
hold off
plot(time,conc_C_pre,'b:','LineWidth',2)
hold on
plot(time,conc_C_post,'r:','LineWidth',2)
legend('Cocentration C-pre', 'Concentration C-post');
axis([min(time) max(time) -1 2]);
ylabel('Conc (mol/m^3)')

% Concentration Plot D
subplot(4,1,4)
hold off
plot(time,conc_D_pre,'b:','LineWidth',2)
hold on
plot(time,conc_D_post,'r:','LineWidth',2)
legend('Cocentration D-pre', 'Concentration D-post');
axis([min(time) max(time) -1 2]);
ylabel('Conc (mol/m^3)')
xlabel('Time (sec)')
saveas(gcf,'Diagram_Concentration.pdf')

figure(2)
hold off

% Level Plot
yyaxis left;
plot(time,flow_in_post,'b:','LineWidth',2)
hold on
plot(time,flow_out_post,'r:','LineWidth',2)
hold on
axis([min(time) max(time) 0 10]);
ylabel('Flow (m^3/s)')
yyaxis right;
plot(time,level,'g:','LineWidth',2)
legend('Flow In', 'Flow Out', 'Level');
axis([min(time) max(time) 0 200]);
ylabel('Level (cm)')
xlabel('Time (sec)')
saveas(gcf,'Diagram_Level.pdf')

figure(3)
hold off

% Temperature Plot
plot(time,feed_temp,'b:','LineWidth',2)
hold on
plot(time,temp_jacket,'r:','LineWidth',2)
hold on
plot(time,temp_out,'g:','LineWidth',2)
legend('Feed Temp', 'Jacket Temp', 'Reactor Temp');
axis([min(time) max(time) -200 600]);
ylabel('Temp (°C)')
xlabel('Time (sec)')
saveas(gcf,'Diagram_Temperature.pdf')

figure(4)
hold off

% Profit Plot
plot(profit,'b:','LineWidth',2)
legend('Cumulated Profit');
axis([min(time) max(time) 0 20000]);
ylabel('Cumulated Profit ($)');
xlabel('Time (sec)')
saveas(gcf,'Diagram_Profit.pdf')

% save data to text file
data = cstr';

save -ascii 'data.txt' data

