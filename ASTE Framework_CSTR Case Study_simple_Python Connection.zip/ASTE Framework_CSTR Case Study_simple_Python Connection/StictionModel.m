function y=StictionModel(x)
%function y=StictionModel(x)
%This function simulates the two parameter data driven stiction model
%developed by M. A. A. Shoukat Choudhury. When using this model, the
%following reference should be cited
%*************************************************************************
%Choudhury, M. A. A. S., Thornhill, N. F., Shah, S. L.,(2005), 'Modelling
%Valve Stiction', Control Engineering Practice, 13, 641�658.
%*************************************************************************
%The model given below is a modified version of what appeared in the above 
%cited CEP paper. This model can now simulate assymetric stiction, i.e., 
%different amounts of stiction in the upward and downward 
%directions of the valve. To get the same amount of stiction (i.e., symmetric stiction) in both 
%directions simply use SD = SU (Line 30). Alternatively you can use the 
%original symmetric stiction model of our CEP paper as given at the bottom of this file.
%  x   - [yk xss xk xk1 vel_old];Input to the stiction model
%  y   - [yk1 xss vel_new]; the output of the model, the valve output
%  yk1 - the valve output at time k
%  xk1 - the controller output at time k
%  yk  - yk1 at time k-1
%  xk  - xk1 at time k-1
%  xss - the controller output at the point of where the valve gets stuck


%*******Specify the following parameters of the model**********************
SU=0;    	% stickband/stiction in the upward direction (opening) of valve travel as a percentage of valve travel
SD=10;       % stickband/stiction in the downward direction (closing) of valve travel as a percentage of valve travel
%SD=SU;     % For simulating SYMMETRIC Stiction (uncomment this line, this will set SD=SU)
jump=0;	% magnitude of slip-jump
% jump=0; use it for pure deadband
% jump<stickband; use it for undershoot case with jump
% jump=stickband for no offset case                   
% jump>stickband; use it for overshoot case 
%**************************************************************************
delta_t=0.1; %delta_t is the sampling interval, assuming here 1
ind=0;
%m=1;
yk=x(1);xss=x(2); xk=x(3); xk1=x(4);vel_old=x(5);
vel_new=(xk1-xk)/delta_t; %calculating the slope of the controller output signal at time k

if xk1>100                  %check the saturation
   yk1=100;
   xss=100;
else
   if xk1<-100                 %check the saturation
      yk1=-100;
      xss=-100;
   else

       if (sign(vel_old)~=sign(vel_new));  %check if the valve changes its direction
             if sign(vel_new)~=0   %check whether the valve gets stuck while 
             %travelling in the same direction          
             xss=xk;
    	     yk1=yk; 
             else
             xss=xk;
    	     yk1=yk;
             ind=1;
             end
         else
    	       if ind~=1  
                    direction=sign(vel_new); %checking the direction of valve travel
                    if direction==1          %Is the valve travelling in the upward direction?
                        if abs(xk1-xss)>SU
                        yk1=xk1-sign(vel_new)*SU/2+sign(vel_new)*jump/2; 
                        %corresponds to the upward direction silp of the valve 
                        else
                        yk1=yk; %valve remains stuck
                        end 
                    else
                        if abs(xk1-xss)>SD %The valve is travelling in the downward direction?
                        yk1=xk1-sign(vel_new)*SD/2+sign(vel_new)*jump/2;  
                        %corresponds to the upward direction silp of the valve 
                        else
                        yk1=yk; %valve remain stuck
                        end
                    end
               else
                    if abs(xk1-xss)>jump   
                        %Valve slips from the stuck position while 
                        %travelling in the same direction travel
                        yk1=xk1-sign(vel_new)*S/2+sign(vel_new)*jump/2;  
                        ind=0;
                    else
                        yk1=yk;
                    end
               end
		 end
    end
end
y=[yk1 xss vel_new];

%Original Model as in CEP paper
%*************************************************************************
%Choudhury, M. A. A. S., Thornhill, N. F., Shah, S. L.,(2004), 'Modelling
%Valve Stiction', Control Engineering Practice, In Press.
%*************************************************************************
%Simulates the stiction model as in the CEP paper. For using this
%version uncomment the following section and 'comment' the above part.
%%This model simulates SYMMETRIC stiction.
%**************************************************************************
%
% delta_t=1;%delta_t is the sampling interval
% ind=0;
% m=1;
% S=3;    	% stickband as a percentage of valve travel
% jump=S;	% magnitude of slip-jump
% % jump=0; use it for pure deadband
% % jump<stickband; use it for undershoot case with jump
% % jump=stickband for no offset case                   
% % jump>stickband; use it for overshoot case 
% 
% yk=x(1);xss=x(2); xk=x(3); xk1=x(4);vel_old=x(5);
% vel_new=(xk1-xk)/delta_t;
% 
% if xk1>100                  %check the saturation
%    yk1=100;
%    xss=100;
% else
%    if xk1<0                 %check the saturation
%       yk1=0;
%       xss=0;
%    else
% 	     if (sign(vel_old)~=sign(vel_new)); 
%     	 %if vel_old*vel_new<=10^-3;
%              if sign(vel_new)~=0
%              xss=xk;
%     	     yk1=yk;
%             else
%              xss=xk;
%     	     yk1=yk;
%              ind=1;
%             end
%          else
%     	     if ind~=1
%              
%                     if abs(xk1-xss)>S
%    		            yk1=xk1-sign(vel_new)*S/2+sign(vel_new)*jump/2;  
%                     else
%                  
%                     yk1=yk;
%                     
%                     end   
%                else
%                     if abs(xk1-xss)>jump
%                         yk1=xk1-sign(vel_new)*S/2+sign(vel_new)*jump/2;  
%                         ind=0;
%                     else
%                         yk1=yk;
%                     end
%                 end
% 		 end
%     end
% end
% y=[yk1 xss vel_new];











